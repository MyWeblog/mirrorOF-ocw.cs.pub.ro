//===- Cpl.cpp - LLVM Pass for the CPL analysis homework ------------------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//
//
// This file implements the entry point of the Cpl pass used for the CPL hw
//
//===----------------------------------------------------------------------===//

#include "llvm/ADT/Statistic.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/Module.h"
#include "llvm/Pass.h"
#include "llvm/Support/raw_ostream.h"


using namespace llvm;

#define DEBUG_TYPE "cpl"

// TODO: statistic that counts the score

// TODO: score file parameter

namespace {

  struct CplStatic : public FunctionPass {
    static char ID;

    CplStatic() : FunctionPass(ID) {}

    bool runOnFunction(Function &F) override {
      // TODO: Cpl Static Score Analysis

      return false;
    }
  };
}

char CplStatic::ID = 0;
static RegisterPass<CplStatic> X("cpl-static", "CPL Static Analysis Pass");

namespace {

  struct CplDynamic : public ModulePass {
    static char ID;

    CplDynamic() : ModulePass(ID) {}

    bool runOnModule(Module &M) override {
      // TODO: Cpl Dynamic Score Analysis

      return false;
    }

  };
}

char CplDynamic::ID = 0;
static RegisterPass<CplDynamic> Y("cpl-dynamic", "CPL Dynamic Analysis Pass");

