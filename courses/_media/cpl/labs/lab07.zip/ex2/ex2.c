
int printf(const char *, ...);

int sum(int *a, int n);

int gv[] = {
	1,2,3,4,5,6,7,8,9,10
};

__attribute__((noinline))
void check(int tid, int v, int ref) {
	printf("%d -- %s ref:%3d val:%3d\n", tid, v == ref ? "PASS" : "FAIL", ref, v);
}

int main() {
	check(1, sum(gv, 10),    55);
	check(2, sum(gv, 0),     0);
	check(3, sum(gv + 3, 1), 4);
	check(4, sum(gv + 3, 3), 15);
	check(5, sum(gv + 2, 7), 42);
	return 0;
}

