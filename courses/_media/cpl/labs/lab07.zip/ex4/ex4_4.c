#include <stdio.h>
#include <limits.h>

int second(int a, int b);

__attribute__((noinline))
void check(int tid, int v, int ref) {
    printf("%d -- %s ref:%3d val:%3d\n", tid, v == ref ? "PASS" : "FAIL", ref, v);
}

int main() {
    check(1, second(0, INT_MIN), INT_MIN);
    check(2, second(0, 0),       0);
    check(3, second(0, INT_MAX), INT_MAX);
    return 0;
}