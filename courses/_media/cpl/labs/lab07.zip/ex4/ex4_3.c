#include <stdio.h>

int or(int a, int b);

__attribute__((noinline))
void check(int tid, int v, int ref) {
    printf("%d -- %s ref:%3d val:%3d\n", tid, v == ref ? "PASS" : "FAIL", ref, v);
}

int main() {
    check(1, or(0, 0), 0);
    check(2, or(0, 1), 1);
    check(3, or(1, 0), 1);
    check(4, or(1, 1), 1);
    return 0;
}