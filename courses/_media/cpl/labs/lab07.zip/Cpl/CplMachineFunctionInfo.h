//=- CplMachineFunctionInfo.h - Cpl machine function info ---------*- C++ -*-=//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//

#ifndef LLVM_LIB_TARGET_Cpl_CplMACHINEFUNCTIONINFO_H
#define LLVM_LIB_TARGET_Cpl_CplMACHINEFUNCTIONINFO_H

#include "llvm/CodeGen/MachineFunction.h"
#include <map>

namespace llvm {

/// Cpl target-specific information for each MachineFunction.
class CplMachineFunctionInfo : public MachineFunctionInfo {
  // SRetReturnReg - Some subtargets require that sret lowering includes
  // returning the value of the returned struct in a register. This field
  // holds the virtual register into which the sret argument is passed.
  virtual void anchor();

  unsigned RA;

public:
  CplMachineFunctionInfo() {}

  CplMachineFunctionInfo(MachineFunction &MF) {}

  void setRA(unsigned R) {
    RA = R;
  }

  unsigned getRA() const {
    return RA;
  }

};

} // End llvm namespace

#endif
