//===-- CplRegisterInfo.cpp - Cpl Register Information --------------------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//
//
// This file contains the Cpl implementation of the TargetRegisterInfo
// class.
//
//===----------------------------------------------------------------------===//

#include "CplRegisterInfo.h"
#include "Cpl.h"
#include "CplMachineFunctionInfo.h"
#include "CplSubtarget.h"
#include "CplTargetMachine.h"

#include "llvm/ADT/BitVector.h"
#include "llvm/ADT/STLExtras.h"
#include "llvm/CodeGen/MachineFrameInfo.h"
#include "llvm/CodeGen/MachineFunction.h"
#include "llvm/CodeGen/MachineFunctionPass.h"
#include "llvm/CodeGen/MachineInstrBuilder.h"
#include "llvm/CodeGen/MachineRegisterInfo.h"
#include "llvm/CodeGen/PseudoSourceValue.h"
#include "llvm/CodeGen/RegisterScavenging.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/Type.h"
#include "llvm/MC/MachineLocation.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/Support/ErrorHandling.h"
#include "llvm/Target/TargetInstrInfo.h"
#include "llvm/Target/TargetMachine.h"
#include "llvm/Target/TargetOptions.h"

#define GET_REGINFO_TARGET_DESC
#include "CplGenRegisterInfo.inc"

using namespace llvm;

CplRegisterInfo::CplRegisterInfo(CplSubtarget &st)
  : CplGenRegisterInfo(Cpl::R14, 0, 0, Cpl::R15),
    Subtarget(st) {
}

const MCPhysReg *CplRegisterInfo::getCalleeSavedRegs(const MachineFunction *MF)
  const {
  return CSR_Cpl_SaveList;
}

const uint32_t *CplRegisterInfo::getCallPreservedMask(const MachineFunction &MF,CallingConv::ID) const {
  return CSR_Cpl_RegMask;
}

BitVector CplRegisterInfo::getReservedRegs(const MachineFunction &MF)
  const {
  BitVector Reserved(getNumRegs());
  return Reserved;
}

void CplRegisterInfo::eliminateFrameIndex(MachineBasicBlock::iterator II,
                                              int SPAdj, unsigned FIOperandNum,
                                              RegScavenger *RS) const {
  assert(SPAdj == 0 && "Unexpected");
}

unsigned CplRegisterInfo::getFrameRegister(const MachineFunction
                                               &MF) const {
  return 0;
}

unsigned CplRegisterInfo::getFrameRegister() const {
  return 0;
}

unsigned CplRegisterInfo::getStackRegister() const {
  return 0;
}
