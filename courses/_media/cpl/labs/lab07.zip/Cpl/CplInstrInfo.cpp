//===-- CplInstrInfo.cpp - Cpl Instruction Information --------------------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//
//
// This file contains the Cpl implementation of the TargetInstrInfo class.
//
//===----------------------------------------------------------------------===//

#include "CplInstrInfo.h"
#include "Cpl.h"
#include "CplRegisterInfo.h"
#include "CplSubtarget.h"

#include "llvm/ADT/STLExtras.h"
#include "llvm/ADT/SmallVector.h"
#include "llvm/CodeGen/DFAPacketizer.h"
#include "llvm/CodeGen/MachineFrameInfo.h"
#include "llvm/CodeGen/MachineInstrBuilder.h"
#include "llvm/CodeGen/MachineMemOperand.h"
#include "llvm/CodeGen/MachineRegisterInfo.h"
#include "llvm/CodeGen/PseudoSourceValue.h"
#include "llvm/Support/Debug.h"
#include "llvm/Support/MathExtras.h"
#include "llvm/Support/raw_ostream.h"

using namespace llvm;

#define DEBUG_TYPE "Cpl-instrinfo"

#define GET_INSTRINFO_CTOR_DTOR
#define GET_INSTRMAP_INFO
#include "CplGenInstrInfo.inc"
#include "CplGenDFAPacketizer.inc"

// Pin the vtable to this file.
void CplInstrInfo::anchor() {}

CplInstrInfo::CplInstrInfo(CplSubtarget &ST)
  : CplGenInstrInfo(Cpl::ADJCALLSTACKDOWN, Cpl::ADJCALLSTACKUP),
    RI(ST), Subtarget(ST) {
}

void CplInstrInfo::copyPhysReg(MachineBasicBlock &MBB,
                               MachineBasicBlock::iterator I, DebugLoc DL,
                               unsigned DestReg, unsigned SrcReg,
                               bool KillSrc) const {
  // TODO 4.4: Build OR instruction that moves source to destination.
  // Hint: Use BuildMI.

  llvm_unreachable("Unimplemented");
}

void CplInstrInfo::
storeRegToStackSlot(MachineBasicBlock &MBB, MachineBasicBlock::iterator I,
                    unsigned SrcReg, bool isKill, int FI,
                    const TargetRegisterClass *RC,
                    const TargetRegisterInfo *TRI) const {
  llvm_unreachable("Unimplemented");
}


void CplInstrInfo::
loadRegFromStackSlot(MachineBasicBlock &MBB, MachineBasicBlock::iterator I,
                     unsigned DestReg, int FI,
                     const TargetRegisterClass *RC,
                     const TargetRegisterInfo *TRI) const {
    llvm_unreachable("Can't store this register to stack slot");
}

bool CplInstrInfo::
expandPostRAPseudo(MachineBasicBlock::iterator MI) const {
  return false;
}


