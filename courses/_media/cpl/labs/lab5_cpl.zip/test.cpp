#include <iostream>

#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/Module.h>

#include <llvm/Support/raw_ostream.h>
#include <llvm/Support/Path.h>
#include <llvm/Support/FileSystem.h>

using namespace llvm;

Module* makeLLVMModule();

int main(int argc, char** argv) {
	Module* Mod = makeLLVMModule();
	std::error_code err;
	// Create output stream
	llvm::raw_fd_ostream output(Mod->getName(), err, llvm::sys::fs::F_Text);
	// Print .ll file
	Mod->print(output, nullptr);
	return 0;

}

Module* makeLLVMModule() {
	//Create Module and Builder
	Module* Mod = new Module("test.ll", getGlobalContext()); 
	IRBuilder<> Builder(getGlobalContext());
	Mod->setDataLayout("e-m:e-p:32:32-f64:32:64-f80:32-n8:16:32-S128");
 	Mod->setTargetTriple("i386-pc-linux-gnu");

	//Create IntType
	auto IntType = llvm::IntegerType::getInt32Ty(getGlobalContext());

	//Create sum's function prototype	
	std::vector<Type*> sum_args = { IntType, IntType };
	FunctionType* sum_func_type = FunctionType::get(
	/*Return Type*/ IntType, 
	/*Params*/ sum_args, 
	/*isVarArg*/ false);

	//Declare sum
	Function* sum_func = llvm::cast<llvm::Function>(Mod->getOrInsertFunction("sum", sum_func_type));;
	sum_func->setCallingConv(CallingConv::C);
	
	Function::arg_iterator args = sum_func->arg_begin();
	Argument* int32_x = &(*args++);
	int32_x->setName("x");
	Argument* int32_y = &(*args++);
	int32_y->setName("y");
	
	//Create sum's body
	BasicBlock* entry = BasicBlock::Create(getGlobalContext(), "entry", sum_func);
	Builder.SetInsertPoint(entry);
	//Reserve space on the stack for the arguments
	AllocaInst* x_ptr = Builder.CreateAlloca(IntType, nullptr, "x_ptr");
	x_ptr->setAlignment(4);
	AllocaInst* y_ptr = Builder.CreateAlloca(IntType, nullptr, "y_ptr");
	y_ptr->setAlignment(4);

	//Store the arguments on the stack
	Builder.CreateStore(int32_x, x_ptr);
	Builder.CreateStore(int32_y, y_ptr);

	//Load the values from the stack
	LoadInst* x_val = Builder.CreateLoad(x_ptr, "x_val");
	x_val->setAlignment(4);
	LoadInst* y_val = Builder.CreateLoad(y_ptr, "y_val");
	y_val->setAlignment(4);

	//Compute the sum
	Value* sum = Builder.CreateAdd(x_val, y_val, "sum");

	//Return sum's value
	Builder.CreateRet(sum);
	return Mod;
}
