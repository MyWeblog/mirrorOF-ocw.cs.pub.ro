#!/bin/bash

EXE=calc
test_files="add-mul-test div-sub-test variables-test bonus-test"

make
echo -e "[CPL] Lab2 Test script\n"

for file in $test_files; do
	echo "--- $file ---"
	./$EXE $file
	
	if [ $? -ne 0 ]; then
		echo "Test failed"
		exit 1
	fi

	echo ""

done
