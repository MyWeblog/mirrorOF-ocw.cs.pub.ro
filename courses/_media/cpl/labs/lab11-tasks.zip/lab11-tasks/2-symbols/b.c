#include "header.h"
#include <stdio.h>

int function(void)
{
	printf("Hello from libB.so\n");

	return 0;
}
