#include "header.h"
#include <stdio.h>

int function(void)
{
	printf("Hello from c.c. No dynamic library involved.\n");

	return 0;
}
