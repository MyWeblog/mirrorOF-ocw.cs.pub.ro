#include "header.h"

int main(void)
{
	function();

	return 0;
}
