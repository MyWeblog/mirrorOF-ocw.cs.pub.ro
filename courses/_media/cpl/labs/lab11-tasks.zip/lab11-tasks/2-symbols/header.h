#ifndef __HEADER_SYMBOLS_H
#define __HEADER_SYMBOLS_H

extern int function(void);

#endif // __HEADER_SYMBOLS_H
