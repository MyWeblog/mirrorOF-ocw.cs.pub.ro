#include "header.h"
#include <stdio.h>

int function(void)
{
	printf("Hello from libA.so\n");

	return 0;
}
