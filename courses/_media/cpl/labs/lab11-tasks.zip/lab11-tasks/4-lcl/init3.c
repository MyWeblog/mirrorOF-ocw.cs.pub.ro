#include "def.h"


static int init3(int x)
{
  printf("\t init3:: called with %d \n", x);
}

MODULE_INIT(init3);

