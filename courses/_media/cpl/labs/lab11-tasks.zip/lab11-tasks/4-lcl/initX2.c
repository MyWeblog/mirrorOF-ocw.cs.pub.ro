#include "def.h"


// se defineste un simbol identic cu cel din
// initX1.c
static int initX(int x)
{
  printf("\t initX2:: called with %d \n", x);
}

MODULE_INIT(initX);

