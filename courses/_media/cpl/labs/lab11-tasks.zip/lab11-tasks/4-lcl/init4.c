#include "def.h"


static int init4(int x)
{
  printf("\t init4:: called with %d \n", x);
}

MODULE_INIT(init4);

