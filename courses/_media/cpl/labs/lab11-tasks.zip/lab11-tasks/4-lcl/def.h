#ifndef DEF_H__
#define DEF_H__
#include <stdio.h>


// definim un pointer catre parametrul X
// si impunem ca acest pointer sa fie pus
// in sectiunea ".cpl"

// deoarece variabila __ptr_init_cpl_X este
// statica, pot exista mai multe variabile
// cu acelasi nume, fiecare avand vizibilitate
// doar in modulul in care este definita

#define MODULE_INIT(X) \
  static void * __ptr_init_cpl_##X __attribute__ ((section (".cpl"))) = &X;



#endif//DEF_H__
