#include "def.h"


static int init5(int x)
{
  printf("\t init5:: called with %d \n", x);
}

MODULE_INIT(init5);

