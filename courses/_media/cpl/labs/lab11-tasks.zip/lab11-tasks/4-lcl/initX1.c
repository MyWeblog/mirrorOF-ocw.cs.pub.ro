#include "def.h"

// se defineste un simbol identic cu cel din
// initX2.c

static int initX(int x)
{
  printf("\t initX1:: called with %d \n", x);
}

MODULE_INIT(initX);

