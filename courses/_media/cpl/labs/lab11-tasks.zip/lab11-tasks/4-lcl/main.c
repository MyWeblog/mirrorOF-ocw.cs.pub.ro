#include <stdio.h>

extern void * __cpl_start, * __cpl_stop;
typedef int (*int_func_t) (int);

int main(void)
{
	int_func_t * ptr;
	printf("main:: begin\n");

	// TODO: iterate through all pointers from .cpl section
	// and call the functions

	printf("main:: end\n");

	return 0;
}

