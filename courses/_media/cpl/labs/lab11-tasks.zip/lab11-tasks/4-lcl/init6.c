#include "def.h"


static int init6(int x)
{
  printf("\t init6:: called with %d \n", x);
}

MODULE_INIT(init6);

