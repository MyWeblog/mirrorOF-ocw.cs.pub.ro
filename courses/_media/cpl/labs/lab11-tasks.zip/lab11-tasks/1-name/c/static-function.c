static int one_static(int a, char b, float c)
{
	return 0;
}

int main(void)
{
	one_static(1, 'a', 1.0);

	return 0;
}
