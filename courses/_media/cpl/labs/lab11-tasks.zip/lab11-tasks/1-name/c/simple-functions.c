int one(int a, char b, float c)
{
	return a;
}

int main(void)
{
	one(1, 'a', 1.0);

	return 0;
}

int two(int a, int b, float c)
{
	return 0;
}

int three(int a, int b, int c)
{
	return 0;
}

int four(float a, float b, float c)
{
	return 0;
}
