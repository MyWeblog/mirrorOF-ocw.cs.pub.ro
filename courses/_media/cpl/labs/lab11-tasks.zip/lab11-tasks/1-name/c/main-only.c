int main(void)
{
	printf("The answer is %d\n", 42);

	return 0;
}
