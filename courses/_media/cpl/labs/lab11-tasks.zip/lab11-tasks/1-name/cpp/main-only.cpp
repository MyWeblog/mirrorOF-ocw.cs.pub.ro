#include <iostream>
using std::cout;

int main(void)
{
	return 0;
}
