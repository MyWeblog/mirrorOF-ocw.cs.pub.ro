#ifndef __MY_CLASS_HPP
#define __MY_CLASS_HPP

class myClass {
public:
	int f;

	myClass(void);
	int method(int name);
};

#endif // __MY_CLASS_HPP
