#include "myClass.hpp"

int use_class(myClass c)
{
	return 0;
}

int main(void)
{
	return 0;
}
