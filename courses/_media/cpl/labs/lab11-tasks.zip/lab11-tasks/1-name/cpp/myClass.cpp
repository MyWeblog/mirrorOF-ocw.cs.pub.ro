#include "myClass.hpp"

myClass::myClass(void) {
	f = 1;
}

int myClass::method(int name) {
	return 0;
}
