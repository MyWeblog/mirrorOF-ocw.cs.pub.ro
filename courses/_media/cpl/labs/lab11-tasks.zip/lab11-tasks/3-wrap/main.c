#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>

#define MSGSTR  "Important message here!\n"

int main(void)
{
	int fd;

	fd = open("/bad/path", O_WRONLY | O_CREAT | O_TRUNC, 0664);
	if (fd < 0) {
		perror("cannot open `/bad/path`");
		exit(EXIT_FAILURE);
	}

	write(fd, MSGSTR, strlen(MSGSTR));

	close(fd);

	printf("Success!\n");

	return 0;
}
