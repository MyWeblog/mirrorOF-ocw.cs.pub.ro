#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>

// TODO:
// implement the wrapping function
// the signature of the 'open' function is the following:
// int open(const char *path, int oflag, mode_t perm)
