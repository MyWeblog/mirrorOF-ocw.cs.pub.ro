//===- Hello.cpp - Example code from "Writing an LLVM Pass" ---------------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//
//
// This file implements two versions of the LLVM "Hello World" pass described
// in docs/WritingAnLLVMPass.html
//
//===----------------------------------------------------------------------===//

#define DEBUG_TYPE "hello"
#include "llvm/Pass.h"
#include "llvm/IR/Function.h"
#include "llvm/ADT/Statistic.h"
#include "llvm/Support/Debug.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/InstIterator.h"
#include "llvm/IR/Instruction.h"
#include "llvm/Analysis/ConstantFolding.h"
#include <set>

using namespace llvm;
STATISTIC(HelloCounter, "Counts number of functions greeted");

namespace {
// Hello - The first implementation, without getAnalysisUsage.
struct Hello: public FunctionPass {
	static char ID; // Pass identification, replacement for typeid
	Hello() :
		FunctionPass(ID) {
	}

	virtual bool runOnFunction(Function &F) {
		++HelloCounter;
		DEBUG(dbgs() << "Hello : ");
		DEBUG(dbgs().write_escaped(F.getName()) << '\n');

		// func is a pointer to a Function instance
		for (Function::iterator blk = F.begin(), exit = F.end(); blk != exit; ++blk) {
			// Print out the name of the basic block if it has one, and then the
			// number of instructions that it contains
			DEBUG(dbgs() << "Basic block (name=" << blk->getName() << ") has " << blk->size() << " instructions.\n");
			// blk is a pointer to a BasicBlock instance
			for (BasicBlock::iterator i = blk->begin(), e = blk->end(); i != e; ++i)
				// The next statement works since operator<<(ostream&,...)
				// is overloaded for Instruction&
				DEBUG(dbgs() << *i << "\n");

		}

		std::set<Instruction*> WorkList;

		for (inst_iterator I = inst_begin(F), E = inst_end(F); I != E; ++I)
			WorkList.insert(&*I);

		bool Changed = false;

		while (!WorkList.empty()) {
			Instruction *I = *WorkList.begin();
			WorkList.erase(WorkList.begin()); // Get an element from the worklist...
			DEBUG(dbgs() << "A fost extrasa din lista \n");
			DEBUG(dbgs() << *I << "\n");

			if (!I->use_empty()) // Don't muck with dead instructions...
				if (Constant *C = ConstantFoldInstruction(I)) {
					DEBUG(dbgs() << "S-a efectuat constant folding \n");
					// Add all of the users of this instruction to the worklist, they might
					// be constant propagatable now...
					for (Value::use_iterator UI = I->use_begin(), UE =
							I->use_end(); UI != UE; ++UI) {
						Instruction *i = cast<Instruction> (*UI);
						DEBUG(dbgs() << "A fost introdusa in lista \n");
						DEBUG(dbgs() << *i << "\n");
						WorkList.insert(cast<Instruction> (*UI));
					}

					// Replace all of the uses of a variable with uses of the constant.
					I->replaceAllUsesWith(C);

					// Remove the dead instruction.
					WorkList.erase(I);
					I->eraseFromParent();

					// We made a change to the function...
					Changed = true;
				}
		}
		return Changed;
	}

	virtual void getAnalysisUsage(AnalysisUsage &AU) const {
		AU.setPreservesCFG();
	}

};
}

char Hello::ID = 0;
static RegisterPass<Hello> X("hello", "Hello World Pass");



