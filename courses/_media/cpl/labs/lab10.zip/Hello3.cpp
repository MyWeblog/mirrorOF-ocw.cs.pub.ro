//===- Hello.cpp - Example code from "Writing an LLVM Pass" ---------------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//
//
// This file implements two versions of the LLVM "Hello World" pass described
// in docs/WritingAnLLVMPass.html
//
//===----------------------------------------------------------------------===//

#define DEBUG_TYPE "hello"
#include "llvm/Pass.h"
#include "llvm/IR/Function.h"
#include "llvm/ADT/Statistic.h"
#include "llvm/Support/Debug.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/InstIterator.h"
#include "llvm/IR/Instruction.h"
#include "llvm/IR/Instructions.h"
#include "llvm/Analysis/ConstantFolding.h"
#include "llvm/ADT/BitVector.h"
#include "llvm/IR/ValueMap.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/CFG.h"
#include "llvm/ADT/SmallVector.h"

using namespace llvm;
STATISTIC(HelloCounter, "Counts number of functions greeted");

namespace {
// Hello - The first implementation, without getAnalysisUsage.
struct Hello: public FunctionPass {
	static char ID; // Pass identification, replacement for typeid
	Hello() :
		FunctionPass(ID) {
	}

	virtual bool runOnFunction(Function &F) {
		++HelloCounter;
		DEBUG(dbgs() << "Hello : ");
		DEBUG(dbgs().write_escaped(F.getName()) << '\n');

		int index = 0;

		// fiecare basic block are asociat un index, folosit mai jos pentru matricea mask
		ValueMap<BasicBlock *, int> indexBB;

		// func is a pointer to a Function instance
		for (Function::iterator blk = F.begin(), exit = F.end(); blk != exit; ++blk) {
			// Print out the name of the basic block if it has one, and then the
			// number of instructions that it contains
			DEBUG(dbgs() << "Basic block (name=" << blk->getName() << ") has " << blk->size() << " instructions.\n");
			DEBUG(dbgs() << "---------------------------\n");

			// blk is a pointer to a BasicBlock instance
			for (BasicBlock::iterator i = blk->begin(), e = blk->end(); i != e; ++i) {
				// The next statement works since operator<<(ostream&,...)
				// is overloaded for Instruction&
				DEBUG(dbgs() << *i << "\n");

				for (User::op_iterator ui = i->op_begin(), ue = i->op_end(); ui
						!= ue; ++ui) {
					Value *v = *ui;
					DEBUG(dbgs() << " used value in instruction:\n");
					DEBUG(dbgs() << *v << "\n");
				}

				for (Value::use_iterator vi = i->use_begin(), ve = i->use_end(); vi
						!= ve; ++vi)
					if (Instruction *Inst = dyn_cast<Instruction>(*vi)) {
						DEBUG(dbgs() << " is used in instruction:\n");
						DEBUG(dbgs() << *Inst << " from basic block " << (Inst->getParent()->getName()) << "\n");

					}
				DEBUG(dbgs() << "---------------------------\n");
			}

			BasicBlock * bb = (&*blk);
			indexBB.insert(std::make_pair(bb, index));
			index++;
		}

		// fiecare variabila are asociata un index, folosit mai jos pentru accesarea bitilor corespunzatori pozitiilor din vectorii de biti
		ValueMap<Value *, int> indexBits;
		index = 0;

		for (inst_iterator I = inst_begin(F), E = inst_end(F); I != E; ++I) {
			Value * v = (Value *) ((Instruction *) (&*I));
			// TODO: 1.1  - completati structura indexBits. Utilizati std::make_pair pentru a crea o pereche

		}

		// se parcurg basic block-urile din functie
		for (Function::iterator blk = F.begin(), exit = F.end(); blk != exit; ++blk) {
			// se parcurg instructiunile din block-uri
			for (BasicBlock::iterator i = blk->begin(), e = blk->end(); i != e; ++i) {
				Instruction * insn = &*i;
				for (User::op_iterator OI = insn->op_begin(), OE =
						insn->op_end(); OI != OE; ++OI) {
					// daca operandul este un argument al functiei
					if (Argument *Arg = dyn_cast<Argument>(*OI)) {
						// se considera argumentul ca o variabila definita in entry
						Value * v = (Value *) (Arg);

						// TODO: 1.2 La fel si aici
					}
				}
			}
		}

		ValueMap<BasicBlock *, BitVector *> useMap;
		ValueMap<BasicBlock *, BitVector *> defMap;
		ValueMap<BasicBlock *, BitVector *> inMap;
		ValueMap<BasicBlock *, BitVector *> outMap;

		// func is a pointer to a Function instance
		for (Function::iterator blk = F.begin(), exit = F.end(); blk != exit; ++blk) {
			BitVector *use = new BitVector();
			BitVector *def = new BitVector();
			BitVector *in = new BitVector();
			BitVector *out = new BitVector();

			// in, out, use si def sunt initializate cu 0
			use->resize(index);
			def->resize(index);
			in->resize(index);
			out->resize(index);

			useMap.insert(std::make_pair((BasicBlock *) (&*blk), use));
			defMap.insert(std::make_pair((BasicBlock *) (&*blk), def));
			inMap.insert(std::make_pair((BasicBlock *) (&*blk), in));
			outMap.insert(std::make_pair((BasicBlock *) (&*blk), out));
		}

		// matricea mask este folosita in cadrul algoritmului pentru a trata cazurile speciale
		// ale nodurilor phi
		// de exemplu z = phi(z_if, z_else)
		// z_else nu va fi live pe partea de if
		// acest lucru va fi marcat cu un 0 pe pozitia lui z_else intr-un vector de biti

		BitVector * mask[100][100];

		for (Function::iterator blk1 = F.begin(), exit1 = F.end(); blk1
				!= exit1; ++blk1) {
			BasicBlock * pB1 = (&*blk1);
			for (Function::iterator blk2 = F.begin(), exit2 = F.end(); blk2
					!= exit2; ++blk2) {
				BasicBlock * pB2 = (&*blk2);

				if (pB1 != pB2) {
					BitVector *tmp = new BitVector();
					// mask este initializata cu biti de 1
					tmp->resize(index, true);
					int indB1, indB2;
					ValueMap<BasicBlock *, int>::iterator itind;
					itind = indexBB.find(pB1);
					indB1 = (int) (itind->second);
					itind = indexBB.find(pB2);
					indB2 = (int) (itind->second);
					mask[indB1][indB2] = tmp;
				}
			}
		}

		// se calculeaza def
		for (inst_iterator i = inst_begin(F), e = inst_end(F); i != e; ++i) {
			Value * v = (Value *) ((Instruction *) (&*i));
			BasicBlock * BBDef = i->getParent();

			// TODO: 2 - v este in def pentru BBDef
			// TODO: 2.1 - gaseste blocul
			ValueMap<BasicBlock *, BitVector*>::iterator itBB;

			// TODO: 2.2 - gaseste bitul corespunzator lui v
			ValueMap<Value *, int>::iterator itind;

			// TODO: 2.3 - seteaza bitul itind->second in bit-setul itBB->second
		}

		// se considera argumentele functiei definite in entry
		// se cauta argumente ale functiei in toate instructiunile
		// se parcurg basic block-urile din functie
		for (Function::iterator blk = F.begin(), exit = F.end(); blk != exit; ++blk) {

			BasicBlock * entry = &*F.begin();

			// se parcurg instructiunile din block-uri
			for (BasicBlock::iterator i = blk->begin(), e = blk->end(); i != e; ++i) {

				Instruction * insn = &*i;

				// se parcurg operanzii din instructiune
				for (User::op_iterator OI = insn->op_begin(), OE =
						insn->op_end(); OI != OE; ++OI) {
					// daca operandul este un argument al functiei
					if (Argument *Arg = dyn_cast<Argument>(*OI)) {

						// se considera argumentul ca o variabila definita in entry
						Value * v = (Value *) (Arg);
						BasicBlock * BBDef = entry;

						// TODO 2.4  - v este in def pentru blocul BBDef
					}
				}
			}
		}

		// se calculeaza use
		for (inst_iterator i = inst_begin(F), e = inst_end(F); i != e; ++i) {
			Value *v = (Value *) ((Instruction *) (&*i));
			BasicBlock * BBDef = i->getParent();

			for (Function::iterator blk = F.begin(), exit = F.end(); blk
					!= exit; ++blk) {
				BasicBlock * pB = (&*blk);
				if (pB != BBDef) {
					if (v->isUsedInBasicBlock(pB)) {
						// TODO: 3.1 - seteaza in multimea use a blocului pB bitul corespunzator instructiunii v
					}
				}
			}
		}

		// se parcurg basic block-urile din functie
		for (Function::iterator blk = F.begin(), exit = F.end(); blk != exit; ++blk) {
			BasicBlock * entry = &*F.begin();

			// se parcurg instructiunile din block-uri
			for (BasicBlock::iterator i = blk->begin(), e = blk->end(); i != e; ++i) {
				Instruction * insn = &*i;

				// se parcurg operanzii din instructiune

				for (User::op_iterator OI = insn->op_begin(), OE =
						insn->op_end(); OI != OE; ++OI) {
					// daca operandul este un argument al functiei
					if (Argument *Arg = dyn_cast<Argument>(*OI)) {
						Value * v = (Value *) (Arg);

						for (Function::iterator blkArg = F.begin(), exitArg = F.end(); blkArg
								!= exitArg; ++blkArg) {
							BasicBlock * pB = (&*blkArg);
							if (pB != entry) {
								// daca argumentul este folosit in alt basic block decat entry
								if (v->isUsedInBasicBlock(pB)) {
									// marcam folosirea argumentului in blkArg
									// pentru ca si argumentele trebuie sa ramana live

									// TODO: 3.2 -  seteaza in multimea use a blocului pB bitul corespunzator instructiunii v
								}
							}
						}
					}
				}
			}
		}

		// se calculeaza mask
		for (inst_iterator i = inst_begin(F), e = inst_end(F); i != e; ++i) {
			Value *insn = (Value *) ((Instruction *) &*i);
			// daca am un nod phi
			if (isa<PHINode> (insn)) {
				PHINode *PN = dyn_cast<PHINode> (insn);
				BasicBlock * bbPhi = i->getParent();

				for (unsigned int j = 0; j < PN->getNumIncomingValues(); j++) {
					BasicBlock * bb = PN->getIncomingBlock(j);
					int indbbPhi, indbb;
					ValueMap<BasicBlock *, int>::iterator itindBB;
					itindBB = indexBB.find(bbPhi);
					indbbPhi = (int) (itindBB->second);
					itindBB = indexBB.find(bb);
					indbb = (int) (itindBB->second);
					ValueMap<Value *, int>::iterator itind;

					for (unsigned int k = 0; k < PN->getNumIncomingValues(); k++) {
						Value * v = PN->getIncomingValue(k);
						if (j != k) {
							itind = indexBits.find(v);
							index = (int) (itind->second);
							mask[indbbPhi][indbb]->reset(index);
						}
					}
				}
			}
		}

		// afisarea def si use
		for (Function::iterator blk = F.begin(), exit = F.end(); blk != exit; ++blk) {
			BitVector use, def;
			ValueMap<BasicBlock *, BitVector *>::iterator itBB;
			itBB = defMap.find(&*blk);
			def = *(itBB->second);
			itBB = useMap.find(&*blk);
			use = *(itBB->second);

			DEBUG(dbgs() << "---------------------------\n");
			DEBUG(dbgs() << "Basic block " << blk->getName() << "\n");

			DEBUG(dbgs() << "Def:" << def.count() << "\n");
			for (unsigned int i = 0; i < def.size(); i++) {
				if (def.test(i)) {
					DEBUG(dbgs() << 1);
				} else {
					DEBUG(dbgs() << 0);
				}
			}
			DEBUG(dbgs() << "\n");

			DEBUG(dbgs() << "Use:" << use.count() << "\n");
			for (unsigned int i = 0; i < use.size(); i++) {
				if (use.test(i)) {
					DEBUG(dbgs() << 1);
				} else {
					DEBUG(dbgs() << 0);
				}
			}
			DEBUG(dbgs() << "\n");

			DEBUG(dbgs() << "---------------------------\n");

		}

		bool Changed = true;

		// algoritmul este iterativ
		// TODO: 4.1 completati conditia de oprire si eventualele initializari de la inceputul buclei
		while (0) {
			// pentru fiecare basic block se calculeaza in si out
			//
			// out[bb] = reuniune de (in[succ] & mask[succ][bb]), unde succ este succesor al lui bb,
			// iar mask[succ][bb] este un vector de biti care are 0 pe pozitia corespunzatoare unei variabile din succ
			// care este folosita intr-un nod phi ca argument, dar nu este definita in bb
			// in[bb] = use[bb] reunit cu (out[bb] - def[bb])
			for (Function::iterator blk = F.begin(), exit = F.end(); blk
					!= exit; ++blk) {
				BitVector oldin;

				ValueMap<BasicBlock *, BitVector *>::iterator ituseBB, itdefBB,
						itinBB, itoutBB;

				itdefBB = defMap.find(&*blk);
				ituseBB = useMap.find(&*blk);
				itinBB = inMap.find(&*blk);
				itoutBB = outMap.find(&*blk);

				oldin = *(itinBB->second);

				BasicBlock * pB = (&*blk);

				DEBUG(dbgs() << "---------------------------\n");

				DEBUG(dbgs() << pB->getName() << ":\n");

				for (succ_iterator SI = succ_begin(pB), E = succ_end(pB); SI
						!= E; ++SI) {
					BasicBlock *Succ = *SI;
					DEBUG(dbgs() << Succ->getName() << " ");

					// TODO: 4.2 - calculati itinSuccBB
					ValueMap<BasicBlock *, BitVector *>::iterator itinSuccBB;
					// itinSuccBB = 

					DEBUG(dbgs() << "\n");

					int indSucc, indpB;

					ValueMap<BasicBlock *, int>::iterator itindBB;
					itindBB = indexBB.find(Succ);
					indSucc = (int) (itindBB->second);
					itindBB = indexBB.find(pB);

					indpB = (int) (itindBB->second);

					// out[bb] = reuniune de (in[succ] & mask[succ][bb])
					// TODO 4.3 - implementati operatia
					// Utilizati (*(itoutBB->second)), (*(itinSuccBB->second)) si (*(mask[indSucc][indpB]))
				}

				DEBUG(dbgs() << "---------------------------\n");
				DEBUG(dbgs() << "\n");

				BitVector tmp1, tmp2, tmp3;
				// TODO 4.4 - implementati formula
				// in[bb] = use[bb] reunit cu (out[bb] - def[bb])

				// se va itera pana cand in-urile de la toate basic block-urile nu se mai schimba
				// TODO 4.5 - conditia de oprire
				if (oldin != (*(itinBB->second))) {

				}

			}
		}

		// afisarea in si out
		for (Function::iterator blk = F.begin(), exit = F.end(); blk != exit; ++blk) {
			BitVector in, out;
			ValueMap<BasicBlock *, BitVector *>::iterator itBB;
			itBB = inMap.find(&*blk);
			in = *(itBB->second);
			itBB = outMap.find(&*blk);
			out = *(itBB->second);
			DEBUG(dbgs() << "---------------------------\n");
			DEBUG(dbgs() << "Basic block " << blk->getName() << "\n");

			DEBUG(dbgs() << "In:" << in.count() << "\n");
			for (unsigned int i = 0; i < in.size(); i++) {
				if (in.test(i)) {
					DEBUG(dbgs() << 1);
				} else {
					DEBUG(dbgs() << 0);
				}
			}
			DEBUG(dbgs() << "\n");

			DEBUG(dbgs() << "Out:" << out.count() << "\n");
			for (unsigned int i = 0; i < out.size(); i++) {
				if (out.test(i)) {
					DEBUG(dbgs() << 1);
				} else {
					DEBUG(dbgs() << 0);
				}
			}
			DEBUG(dbgs() << "\n");

			DEBUG(dbgs() << "---------------------------\n");

		}

		return false;
	}

	virtual void getAnalysisUsage(AnalysisUsage &AU) const {
		AU.setPreservesCFG();
	}

};
}

char Hello::ID = 0;
static RegisterPass<Hello> Hello("hello", "Hello World Pass");
