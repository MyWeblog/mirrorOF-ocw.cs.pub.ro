#include <stdio.h>

//return 1 if architecture is little endian,
//       0                    big endian
int is_little_endian();


// print the string and then decompose the float in sign, exponent, mantisa
void print_float(char * str, float f);



int main()
{
    float f;

    printf("byte ordering: %s\n", is_little_endian()?"little": "big");

    f = 0.0;
    print_float("0.0", f);
    f = -0.0;
    print_float("-0.0", f);

    f = 1.0/0.0;
    print_float("1.0/0.0", f);
    f = -1.0/0.0;
    print_float("-1.0/0.0", f);

    f = 0.0/0.0;
    print_float(" 0.0/0.0", f);
    f = -0.0/0.0;
    print_float(" -0.0/0.0", f);

    return 0;
}
