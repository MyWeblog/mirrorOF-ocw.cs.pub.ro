#include <string.h>

struct bigstruct_t {
    int c [1024];
};

struct bigstruct_t make_blank()
{
    struct bigstruct_t s;
    return s;
}

int get_n(struct bigstruct_t s)
{
    return 0;
}

int despartior_debugging()
{
    return 0;
}

int main()
{
    struct bigstruct_t s;
    despartior_debugging();
    s = make_blank();
    despartior_debugging();
    get_n(s);
    despartior_debugging();
    return 0;
}
