#include <stdio.h>

int v[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
int size = sizeof(v)/sizeof(v[0]);

int vec_sum();
int ptr_sum();

int main()
{
    printf("vec: %d\n", vec_sum()); fflush(stdout);
    printf("ptr: %d\n", ptr_sum()); fflush(stdout);
    return 0;
}
