#include <iostream>

class Class1 {};

class Class2 : public Class1 {};

int main(void) {
	Class1* p1;
	Class2* p2 = new Class2();
	
	p1 = p2;

	std::cout<< ((void*)p1 == (void*)p2 ? "same" : "different") << std::endl;
	return 0;
}
