extern int size;
extern int v[];

int vec_sum()
{
    int i, acc = 0;
    for (i = 0; i < size; i++)
        acc += v[i];
    return acc;
}
