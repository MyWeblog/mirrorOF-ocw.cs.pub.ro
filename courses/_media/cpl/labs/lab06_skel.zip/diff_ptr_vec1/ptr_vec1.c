#include <stdio.h>

#define VEC_SIZE 5
extern int* v;

int main() {
	int i;
	for(i = 0; i < VEC_SIZE; i++) {
		printf("%d\n", v[i]);
	}
	return 0;
}
