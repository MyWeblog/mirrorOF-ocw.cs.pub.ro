#include <stdio.h>
int f(int n)
{
    int v[n];
    printf("sizeof v = %d\n", sizeof(v));
    printf("n        = %d\n", n);
    return 1;
}

int main()
{
    int n;
    scanf("%d", &n);
    f(n);
    return 0;
}
