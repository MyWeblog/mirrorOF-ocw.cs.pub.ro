#include <stdio.h>

static char pc1[] = "Hello1";
static const char pc2[] = "Hello2";

void f(char *pc, char x)
{
  *pc = x;
}

int main(int argc, char ** argv)
{
  printf("%s %s \n",pc1, pc2);
  f(pc1,'C');
  printf("%s %s \n",pc1, pc2);
  f((char *)pc2,'B');
  printf("%s %s \n",pc1, pc2);
}
