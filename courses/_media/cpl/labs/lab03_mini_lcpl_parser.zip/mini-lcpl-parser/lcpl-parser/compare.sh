#!/bin/sh

if [ "$#" -ne "1" ]
then
    echo "Usage: $0 <test_name|all>"
    echo "example: $0 basic"
    exit 1
fi

run_test() {
    rm -f $3
    ./lcpl-parser $2
    res=$?

    diff $3 $4

    if [ "$?" -eq "1" -o $res -eq "1" ]
    then
        printf "%-50s %s\n" $1 "Failed"
    else
        printf "%-50s %s\n" $1 "Passed"
    fi   
}

if [ "$1" = "all" ]
then
    for i in tests/*.lcpl
    do
        test_name=`basename $i`
        test_out=$i".ast"
        test_ref="refs/"$test_name".ast.ref"
        run_test $test_name $i $test_out $test_ref
    done
else
    test_loc="tests/"$1".lcpl"
    test_out="tests/"$1".lcpl.ast"
    test_ref="refs/"$1".lcpl.ast.ref"

    run_test $1 $test_loc $test_out $test_ref
fi
