struct Triple {
  int a, b, c;
};

class A {
protected:
  Triple t;

public:
  A(const Triple &triple) : t(triple) {}

  int f() { return t.a; }
};

class B : public A {
  int x[12];

public:
  B(const Triple &triple) : A(triple), x() {}

  //int f() { return t.b; }

  int g() { return t.b; }
  int g(int x) { return t.b + x; }
};

int f(A *a, B *b) {
  return a->f() + b->f() + b->g() + b->g(42);
}
