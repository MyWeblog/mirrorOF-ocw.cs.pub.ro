struct data {
  int a, b, c;
};

extern void init(struct data *, int);

int f(int seed) {
  struct data x;
  init(&x, seed);
  return x.a + x.b * x.c;
}
