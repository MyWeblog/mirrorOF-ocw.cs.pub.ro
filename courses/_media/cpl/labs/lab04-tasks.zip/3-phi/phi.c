#define NULL 0 // don't do this at home

int *nonsense(int *x, int n, int p, int q) {
  int a = 0;
  int b = p;
  int c = p + q;
  int *r = NULL;

  for (int i = 0; i < n; i++) {
    if (x[i] < p) {
      a++;

      if (x[i] < c) {
        b--;
      }
    }

    if (b * c > x[i]) {
      r = &x[i];
      c--;
    } else {
      c++;
    }
  }

  return r;
}
