struct Triple {
  int a, b, c;
};

class A {
protected:
  Triple t;

public:
  virtual int f() { return t.a; }
  int g() { return t.a; }
};

class B : public A {
  int x[12];

public:
  virtual int f() { return t.c; }
  int g() { return t.c; }
};

int val(A a, B b) {
  return a.f() + a.g() + b.f() + b.g();
}

int ref(A *a, B *b) {
  return a->f() + a->g() + b->f() + b->g();
}

#ifndef SIMPLE
A *factory() {
  return new B();
}
#endif
