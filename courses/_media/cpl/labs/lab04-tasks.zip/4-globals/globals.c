int g;

int f(int a) {
  int x = 0;

  if (a < g) {
    x++;
    g++;
  }

  return g + x;
}
