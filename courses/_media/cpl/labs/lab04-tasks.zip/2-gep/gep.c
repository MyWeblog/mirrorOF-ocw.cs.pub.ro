struct triple {
  int a, b, c;
};

struct convoluted {
  int my_int;
  struct triple my_static_triples[200];
  struct triple *my_dynamic_triples;
};

int get1(struct convoluted *conv) {
  return conv->my_int;
}

int get2(struct convoluted *conv, int i) {
  return conv->my_static_triples[i].a;
}

int get3(struct convoluted *conv, int i) {
  return conv->my_dynamic_triples[i].a;
}
