void simple(char *str) {
  for (char *p = str; *p; ++p) {
    if (*p >= 'a' && *p <= 'z') {
      *p += 'A' - 'a';
    }
  }
}
