#include <stdio.h>

static void zece(void)
{
    printf("meriti 10\n");
}

static void ask(void)
{
	long v[12];
	printf("ce nota vrei?");
	// TODO
	// hint: suprascrieti adresa de return
}

static void zero(void)
{
	ask();
	printf("meriti 2\n");
}

int main(void)
{
    zero();
    return 0;
}
