#include <iostream>

class ClassBar
{
public:
  ClassBar()
  {
    std::cout << "ClassBar() called" << std::endl;
  }

  ~ClassBar()
  {
    std::cout << "~ClassBar() called" << std::endl;

  }
};
class ClassFoo
{
public:
  ClassFoo()
    : b(new ClassBar())
  {
    std::cout << "ClassFoo() called" << std::endl;
    throw "throw exception";
  }

  ~ClassFoo()
  {
    delete b;
    std::cout << "~ClassFoo() called" << std::endl;
  }

private:
  ClassBar *b;
};


int main(void)
{
  try {
    std::cout << "heap: new ClassFoo" << std::endl;
    ClassFoo *f = new ClassFoo();
  } catch (const char *e) {
    std::cout << "heap exception: " << e << std::endl;
  }

  try {
    std::cout << "stack: ClassFoo" << std::endl;
    ClassFoo f;
  } catch (const char *e) {
    std::cout << "stack exception: " << e << std::endl;
  }

  return 0;
}
