#include <iostream>

int gVar = 3;

void my_func( int v)
{
	bool myCond = false;
 
	try
	{
    	if (v == 1)
    	{
        	myCond = true;
        	throw 0;
    	}
    	if (v == 2)
    	{
        	myCond = true;
        	throw 0;
    	}
    	if (v == 3)
    	{
        	myCond = true;
        	throw 0;
    	}
	}
	catch (...)
	{
		    std::cout << "Exception caught" << std::endl;
	}
 
	if (myCond)
	{
	    std::cout << "myCond - true" << std::endl;
		gVar = 0;
	}
	else
	{
	    std::cout << "myCond - false" << std::endl;
		gVar++;
	}
}

int main()
{
	int i;

	for (i = 0; i < 10 ; i++)
		my_func((i+3)%5);

	return 1;
}
