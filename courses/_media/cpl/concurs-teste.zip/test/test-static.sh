#!/bin/bash

LLVM_PASS_STATIC=cpl-static
PASS_LIBNAME=libLLVMCpl.so
PASS_DIR=$1
TESTS_DIR=testfiles
SCORE_FILE=$2
EXPECT_FILE=$3

# find the library
LIB=$(find "$PASS_DIR" -name "$PASS_LIBNAME")
if ! [ -e "$LIB" ]; then
	echo "Cannot find library $PASS_LIBNAME! Did you build the pass in $PASS_DIR?"
	exit
fi

declare -A results
declare -a tests
while IFS="," read -r key static dynamic
do
	tests+=( $key )
	results[$key]=$static
done < $EXPECT_FILE

for i in "${!tests[@]}" ; do
	test=${tests["$i"]}
	expected=${results["$test"]}
	test_path=$TESTS_DIR/"test"$test".bc"

	OUT=$(opt -load=$LIB \
		-$LLVM_PASS_STATIC \
		-stats \
		-cpl-score-file=$SCORE_FILE \
		$test_path 2>&1 >/dev/null | \
			grep "Static" | cut -d " " -f 1)
	echo -ne "Static Test $test_path:\t\t"
	[ $OUT -a $OUT = $expected ] && echo OK || echo "FAIL ($OUT!=$expected)"
done
