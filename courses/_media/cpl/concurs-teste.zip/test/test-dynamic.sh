#!/bin/bash

LLVM_PASS_DYNAMIC=cpl-dynamic
PASS_LIBNAME=libLLVMCpl.so
PASS_DIR=$1
TESTS_DIR=testfiles
SCORE_FILE=$2
EXPECT_FILE=$3

# find the library
LIB=$(find "$PASS_DIR" -name "$PASS_LIBNAME")
if ! [ -e "$LIB" ]; then
	echo "Cannot find library $PASS_LIBNAME! Did you build the pass in $PASS_DIR?"
	exit
fi

declare -A results
declare -a tests
while IFS="," read -r key static dynamic
do
	tests+=( $key )
	results[$key]=$dynamic
done < $EXPECT_FILE

for i in "${!tests[@]}" ; do
	test=${tests["$i"]}
	expected=${results["$test"]}
	test_path=$TESTS_DIR/"test"$test".bc"
	test_exe=$(mktemp)
	cc=clang
	if [ $test = 3 ] || [ $test = 3.O3 ] ; then cc=clang++ ;fi

	opt -load=$LIB \
	-$LLVM_PASS_DYNAMIC \
	-cpl-score-file=$SCORE_FILE \
	$test_path | $cc -xir - -O0 -o $test_exe

	OUT=$($test_exe | grep "Dynamic" | cut -d " " -f 1)

	echo -ne "Dynamic Test $test_path:\t\t"
	[ $OUT -a $OUT = $expected ] && echo OK || echo "FAIL ($OUT!=$expected)"
done
