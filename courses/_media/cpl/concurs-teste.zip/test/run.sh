#!/bin/bash

PASS_DIR=$1
SCORE_FILES=scorefiles
EXPECT_FILES=expect
TESTS_DIR=testfiles

if [ "$#" -ne 1 ]; then
	echo "Usage: $0 /path/to/pass.so"
	exit 0
fi

# build the tests
echo "Building tests..."
make --no-print-directory -C "$TESTS_DIR" > /dev/null

echo "Running static-tests..."
./test-static.sh $PASS_DIR $SCORE_FILES/score1.txt $EXPECT_FILES/expect1.in
./test-static.sh $PASS_DIR $SCORE_FILES/score2.txt $EXPECT_FILES/expect2.in
./test-static.sh $PASS_DIR $SCORE_FILES/score3.txt $EXPECT_FILES/expect3.in
./test-static.sh $PASS_DIR $SCORE_FILES/score4.txt $EXPECT_FILES/expect4.in

echo "Running dynamic-tests..."
./test-dynamic.sh $PASS_DIR $SCORE_FILES/score1.txt $EXPECT_FILES/expect1.in
./test-dynamic.sh $PASS_DIR $SCORE_FILES/score2.txt $EXPECT_FILES/expect2.in
./test-dynamic.sh $PASS_DIR $SCORE_FILES/score3.txt $EXPECT_FILES/expect3.in
./test-dynamic.sh $PASS_DIR $SCORE_FILES/score4.txt $EXPECT_FILES/expect4.in
