#include <iostream>

using namespace std;

int main() {
	std::cout << "Hello, global_ctors!" << std::endl;
	return 0;
}
