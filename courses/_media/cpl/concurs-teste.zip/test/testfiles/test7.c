#include <stdio.h>
#include <stdlib.h>

volatile int x = 10;

int main()
{
  int i;

  for (i = 0; i < x; i++)
    printf("%d: Hello, World!\n", i);

  return 0;
}
