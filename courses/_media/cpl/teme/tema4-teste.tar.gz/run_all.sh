#!/bin/bash

#set -x

#declare -r CPL_LLC=/home/student/workspace/llvm_build/bin/llc
[ -z "${CPL_LLC}" ] && echo "Please set llc path in CPL_LLC" >&2 && exit 1

gen_ll=0

num_pass=0
num_total=0

rm -rf tmp
mkdir -p tmp

arm-linux-gnueabi-gcc lib/main.c -o tmp/main.o -c -O3 -march=armv4

for f in input/*.c; do
	[ "${gen_ll}" = 1 ] && clang "${f}" -O3 -target armv3-none-eabi -S -emit-llvm -o "${f}.ll"
	PASS=0
	${CPL_LLC} -O3 -march cpl "${f}.ll" -o tmp/test.s && \
		arm-linux-gnueabi-gcc tmp/test.s -o tmp/test.o -c -march=armv3 && \
		arm-linux-gnueabi-gcc tmp/test.o tmp/main.o -march=armv3 -static -o tmp/test && \
		qemu-arm tmp/test > tmp/test.out && \
		diff tmp/test.out "ref/$(basename "${f}").ref" && \
		PASS=1
	num_total=$((num_total+1))
	[ "$PASS" = 1 ] && echo "[ PASS ] $f" && num_pass=$((num_pass+1))
	[ "$PASS" = 0 ] && echo "[ FAIL ] $f"
done

echo "Result: ${num_pass}/${num_total}"

