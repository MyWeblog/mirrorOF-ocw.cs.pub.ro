
#ifndef _CPL_H
#define _CPL_H

void dump_int(int);
void dump_string(const char *);

#endif

