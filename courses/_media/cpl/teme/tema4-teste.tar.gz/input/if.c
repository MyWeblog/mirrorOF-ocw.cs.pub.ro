
#include "cpl.h"

__attribute__((noinline))
int f(int a, int b, int c) {
	if (c) {
		dump_int(a);
		dump_int(b);
		return a + b;
	}
	else {
		dump_string("HI");
		return 0;
	}
}

int cpl_main() {
	dump_int(f(5, 3, 0));
	dump_int(f(9, 8, 1));
	return 0;
}

