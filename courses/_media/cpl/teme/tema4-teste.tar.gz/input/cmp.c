
#include "cpl.h"

__attribute__((noinline))
int lt(int a, int b) {
	return a < b;
}

__attribute__((noinline))
int le(int a, int b) {
	return a <= b;
}

__attribute__((noinline))
int gt(int a, int b) {
	return a > b;
}

__attribute__((noinline))
int ge(int a, int b) {
	return a >= b;
}

__attribute__((noinline))
int eq(int a, int b) {
	return a == b;
}

__attribute__((noinline))
int ne(int a, int b) {
	return a != b;
}

int cpl_main() {
	dump_int(lt(4, 5));
	dump_int(lt(5, 5));
	dump_int(le(4, 5));
	dump_int(le(5, 5));
	dump_int(gt(4, 5));
	dump_int(gt(5, 5));
	dump_int(ge(4, 5));
	dump_int(ge(6, 5));
	dump_int(eq(4, 5));
	dump_int(eq(4, 4));
	dump_int(ne(4, 5));
	dump_int(ne(4, 4));
	return 0;
}

