
#include "cpl.h"

__attribute__((noinline))
int f(int a0, int a1, int a2, int a3, int a4) {
	return a0 + a1 + a2 + a3 + a4;
}

int cpl_main() {
	dump_int(f(1, 2, 3, 4, 5));
	return 0;
}

