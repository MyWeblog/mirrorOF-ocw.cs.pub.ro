
#include"cpl.h"

int cpl_main() {
	dump_string("Hello World!");
	return 0;
}

