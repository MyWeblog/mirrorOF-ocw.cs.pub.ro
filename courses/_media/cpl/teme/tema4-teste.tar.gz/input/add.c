
#include "cpl.h"

__attribute__((noinline))
int f(int a, int b) {
	return a + b;
}

int cpl_main() {
	dump_int(f(4, 5));
	return 0;
}

