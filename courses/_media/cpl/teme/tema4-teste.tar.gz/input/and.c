
#include "cpl.h"

__attribute__((noinline))
int f(int a, int b) {
	return a & b;
}

int cpl_main() {
	dump_int(f(5, 6));
	return 0;
}

