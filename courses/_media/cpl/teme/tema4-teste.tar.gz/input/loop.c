
#include "cpl.h"

__attribute__((noinline))
void g(void (*f)(int), int a) {
	f(a);
}

int n = 10;

int cpl_main() {
	int ln = n;
	while (ln > 0) {
		g(dump_int, ln);
		ln--;
	}
	return 0;
}

