
#include "cpl.h"

__attribute__((noinline))
int f(int num) {
	return num >> 1;
}

int cpl_main() {
	dump_int(f(-1));
	return 0;
}

