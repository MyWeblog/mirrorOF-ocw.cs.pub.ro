
#include "cpl.h"

__attribute__((noinline))
void g(int *a) {
	*a = 5;
}

__attribute__((noinline))
int f(int a) {
	int b;
	g(&b);
	return a + b;
}

int cpl_main() {
	dump_int(f(4));
	return 0;
}

