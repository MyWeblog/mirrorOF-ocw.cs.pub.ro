
#include "cpl.h"

__attribute__((noinline))
int f() {
	return 2015;
}

int cpl_main() {
	dump_int(f());
	return 0;
}
