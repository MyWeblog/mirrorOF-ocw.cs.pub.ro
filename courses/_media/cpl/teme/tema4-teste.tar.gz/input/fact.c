
#include "cpl.h"

__attribute__((noinline))
int g(int a) {
	return a;
}

__attribute__((noinline))
int f(int a) {
	if (a) {
		return a * f(g(a - 1));
	}
	return 1;
}

int cpl_main() {
	dump_int(f(5));
	return 0;
}

