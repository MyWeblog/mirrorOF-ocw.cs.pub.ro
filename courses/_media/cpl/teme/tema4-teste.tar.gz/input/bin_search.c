
#include "cpl.h"

int v[] = {
	0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20
};

__attribute__((noinline))
int f(int *v, int n, int el) {
	int s = 0;
	int e = n - 1;
	int m = (s + e) / 2;
	while (s <= e) {
		if (v[m] == el) {
			return m;
		}
		else if (v[m] < el) {
			s = m + 1;
		}
		else {
			e = m - 1;
		}
		m = (s + e) / 2;
	}
	return -1;
}

int cpl_main() {
	dump_int(f(v, 11, 2));
	dump_int(f(v, 11, 6));
	dump_int(f(v, 11, 9));
	dump_int(f(v, 11, 10));
	return 0;
}

