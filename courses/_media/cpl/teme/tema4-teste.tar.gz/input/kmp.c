
#include "cpl.h"

__attribute__((noinline))
void preKmp(const char *x, int m, int kmpNext[]) {
   int i, j;

   i = 0;
   j = kmpNext[0] = -1;
   while (i < m) {
      while (j > -1 && x[i] != x[j])
         j = kmpNext[j];
      i++;
      j++;
      if (x[i] == x[j])
         kmpNext[i] = kmpNext[j];
      else
         kmpNext[i] = j;
   }
}

__attribute__((noinline))
int KMP(const char *x, int m, const char *y, int n) {
   int i, j, kmpNext[32];

   /* Preprocessing */
   preKmp(x, m, kmpNext);

   /* Searching */
   i = j = 0;
   while (j < n) {
      while (i > -1 && x[i] != y[j])
         i = kmpNext[i];
      i++;
      j++;
      if (i >= m) {
         return j - i;;
      }
   }
   return -1;
}

int cpl_main() {
	char str[] = "ABC ABCDAB ABCDABCDABDE";
	int i = KMP("ABCDABD", 7, str, 25);
	dump_int(i);
	dump_string(str + i);
	return 0;
}

