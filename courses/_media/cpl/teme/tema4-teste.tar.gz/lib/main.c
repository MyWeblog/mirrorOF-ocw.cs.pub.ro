
#include <stdio.h>

extern int cpl_main();

void dump_int(int n) {
	printf("%d\n", n);
}

void dump_string(const char *s) {
	printf("%s\n", s);
}

int main() {
	return cpl_main();
}

