if [ $# -ne 1 ]
then
	echo Usage lcplrun.sh "<file.lcpl.json>"
	exit
fi
FNAME=`basename $1 .lcpl.json`
./lcpl-codegen $1 $FNAME.ll &&\
    llvm-as $FNAME.ll -o $FNAME.bc  &&\
    llvm-link $FNAME.bc ../runtime/runtime.bc -o $FNAME.run.bc &&\
    lli $FNAME.run.bc

