clean()
{
	rm *.bc *.out
}

test()
{
	echo === $1 ===
	FNAME=`basename $1 .lcpl.json`
	if [ $1 = "../simple/methods.lcpl.json" ]
	then
		./lcplrun.sh $1 > $FNAME.out << END
 > This is a string >> 01234
END
	else
		./lcplrun.sh $1 > $FNAME.out
	fi
		diff $FNAME.out ${1%lcpl.json}ref
}

clean
for l in ../tests/simple/*.lcpl.json
do
	test $l
done
for l in ../tests/advanced/*.lcpl.json
do
test $l
done
for l in ../tests/complex/*.lcpl.json
do
test $l
done
clean
