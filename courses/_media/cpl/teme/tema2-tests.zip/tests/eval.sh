#!/bin/bash

if [ "$1" = "" -o "$2" = "" ]; then
  echo "Usage: $0 <path-to-tests> <path-to-executable> [<test-to-run>]"
  exit 1
fi

TESTS="$1"
EXEC="$2"
TEST="$3"

if [ ! -d $TESTS ]; then
  echo "Invalid tests directory: $TESTS"
  exit 1
fi

if [ ! -x $EXEC ]; then
  echo "Invalid parser: $EXEC"
  exit
fi

TEST_COUNT=0
FAILED_TESTS=0

fail() {
  FAILED_TESTS=$((FAILED_TESTS+1))
  printf "FAIL (%s)\n" "$1"
}

pass() {
  printf "PASS\n"
}

test()
{
  TEST_COUNT=$((TEST_COUNT+1))
  FILENAME="$1"
  INPUT="$FILENAME.lcpl.json"
  OUTPUT="`basename $FILENAME`.out"
  ERROR="`basename $FILENAME`.err"
  REF="$INPUT.ref"
  TEMP="`basename $FILENAME`.ll `basename $FILENAME`.bc"

  VERBOSE="$2"

  echo === $FILENAME ===
  $EXEC $INPUT > $OUTPUT 2> $ERROR
  SUCCESS=$?

  if [[ $FILENAME == *"error"* && $SUCCESS != 0 ]]; then
    SUCCESS=0
  fi

  if [ $SUCCESS = 0 ]; then
    DIFF=`diff -a -w $OUTPUT $REF 2>&1`
    if [ -z "$DIFF" ]; then
      pass
      rm -f $OUTPUT, $ERROR, $TEMP
    else
      fail "Different program output. First lines of diff below"
      cat $OUTPUT
      echo "-----"
      echo "$DIFF" | head -n 30
      echo "-- Error log: --"
      cat $ERROR
      echo "-----"
      echo
    fi
  else
    fail "No output generated"
    cat $OUTPUT
    echo "-- Error log: --"
    cat $ERROR
    echo "-----"
    echo
  fi
}

if [ "$3" != "" ]; then
  test $TESTS/$3
  exit 0
fi

echo "******************************"
echo "**** Running simple tests ****"
echo "******************************"
echo

SIMPLE=(
  "string-concat" "string-special" "string-conv" "string-conv2" "string-equal"
  "substring" "substring-error" "substring-error2" "substring-error3"
  "arithmetic" "arithmetic2" "if" "local" "assign" "assign-string" "while"
  "phi-ints" "phi-strings" "phi-mixed" "if-no-else" "static-dispatch-no-args"
  "static-dispatch-args" "static-dispatch-ret" "string-length" "string-to-int"
  "abort-error" "write-param" "attr" "attrs" "constructor" "hidden"
  "multiple-classes" "multiple-classes-attrs" "multiple-classes-attrs-many"
  "multiple-classes-methods" "object-assign" "object-equal" "null"
  "constr-order" "default-inits-int" "default-inits-obj" "default-inits-string"
  "typename" "cast" "cast-error" "copy" "dynamic-dispatch"
  "dynamic-dispatch-ret" "null-error-dynamic-dispatch"
  "null-error-static-dispatch" "override" "override-several" "override-tree"
  "pass-self" "assign-result-int" "assign-result-string" "assign-result-object"
  "polymorphism" "assign-control-flow"
)

test $TESTS/hello
for AST in ${SIMPLE[@]}; do
  test $TESTS/simple/$AST
done

SIMPLE_FAILURES=$FAILED_TESTS
FAILED_TESTS=0

echo
echo

echo "********************************"
echo "**** Running advanced tests ****"
echo "********************************"
echo

ADVANCED=(
  "attr-init" "censor" "class-order" "if-control-flow-cond"
  "if-control-flow-then" "if-control-flow-else" "while-control-flow-body"
  "while-control-flow-cond" "nested-locals" "return" "shapes" "stack"
  "substring-expr" "widgets" "writes"
)

for AST in ${ADVANCED[@]}; do
  test $TESTS/advanced/$AST
done

ADVANCED_FAILURES=$FAILED_TESTS
FAILED_TESTS=0

echo
echo

echo "*******************************"
echo "**** Running complex tests ****"
echo "*******************************"
echo

COMPLEX=("compiler" "database")

for AST in ${COMPLEX[@]}; do
  test $TESTS/complex/$AST
done

COMPLEX_FAILURES=$FAILED_TESTS
FAILED_TESTS=0

echo
echo "Ran $TEST_COUNT tests"
echo "Failures in simple tests:   $SIMPLE_FAILURES"
echo "Failures in advanced tests: $ADVANCED_FAILURES"
echo "Failures in complex tests:  $COMPLEX_FAILURES"
