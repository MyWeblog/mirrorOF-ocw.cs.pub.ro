#include "IRGenerator.h"
#include "StringConstants.h"

#include <cassert>

using namespace lcpl;

RuntimeInterface::RuntimeInterface(llvm::Module &M) {
  auto &Context = M.getContext();

  RTTIType = llvm::StructType::create(Context, "struct.__lcpl_rtti");
  StringType = llvm::StructType::create(Context, "struct.TString");
  IOType = llvm::StructType::create(Context, "struct.TIO");

  auto RTTIPtrType = RTTIType->getPointerTo();
  auto StrPtrType = StringType->getPointerTo();
  auto IOPtrType = IOType->getPointerTo();

  auto IntType = llvm::IntegerType::getInt32Ty(Context);
  auto VoidPtrType = llvm::IntegerType::getInt8PtrTy(Context);

  RTTIType->setBody(StrPtrType, IntType, RTTIPtrType,
                    llvm::ArrayType::get(VoidPtrType, 0), nullptr);

  StringType->setBody(RTTIPtrType, IntType, llvm::Type::getInt8PtrTy(Context),
                      nullptr);
  llvm::Type *IOTypeFields[] = {RTTIPtrType};
  IOType->setBody(IOTypeFields);

  RString = M.getOrInsertGlobal("RString", RTTIType);
  RIO = M.getOrInsertGlobal("RIO", RTTIType);

  llvm::Type *IOOutParamTypes[] = {IOPtrType, StrPtrType};
  IO_out = llvm::cast<llvm::Function>(M.getOrInsertFunction(
      "M2_IO_out", llvm::FunctionType::get(IOPtrType, IOOutParamTypes, false)));
  LCPLNew = llvm::cast<llvm::Function>(M.getOrInsertFunction(
      "__lcpl_new", llvm::FunctionType::get(VoidPtrType, RTTIPtrType, false)));
}

IRGenerator::IRGenerator(llvm::StringRef ModuleName, Program *P,
                         const TypeTable &ASTTypes, SymbolMap DefinitionsMap)
    : Context(), Module(ModuleName, Context), Builder(Context), Runtime(Module),
      AST(P), ASTTypes(ASTTypes), DefinitionsMap(std::move(DefinitionsMap)) {}

llvm::Module *IRGenerator::runGenerator() {
  if (!visit(AST))
    return nullptr;

  return &Module;
}

bool IRGenerator::visit(Program *P) {
  for (auto C : *P) {
    if (!visit(C)) {
      return false;
    }
  }

  // Generate the startup code: a main function which should instantiate a
  // 'Main' object and invoke its 'main' method
  std::string FunctionName("main");
  assert(!Module.getFunction(FunctionName) && "Function already exists!");

  auto FunctionType =
      llvm::FunctionType::get(llvm::IntegerType::getInt32Ty(Context), false);
  CurrentFunction = llvm::cast<llvm::Function>(
      Module.getOrInsertFunction(FunctionName, FunctionType));
  assert(CurrentFunction && "Failed to create function");

  auto CurrentBlock = llvm::BasicBlock::Create(Context, "", CurrentFunction);
  assert(CurrentBlock && "Failed to create basic block");

  Builder.SetInsertPoint(CurrentBlock);

  // TODO: We're abusively declaring Main::main as void(void) - it should take a
  // parameter representing 'self'
  auto MainMethod = llvm::cast<llvm::Function>(Module.getOrInsertFunction(
          "M4_Main_main",
          llvm::FunctionType::get(llvm::Type::getVoidTy(Context), false)));
  (void)Builder.CreateCall(MainMethod);
  (void)Builder.CreateRet(Builder.getInt32(0));
  return true;
}

bool IRGenerator::visit(Class *C) {
  // TODO: For now we're only processing the 'Main' class; remove this check
  // when you're ready to process other classes in the program
  if (C->getName() != strings::MainClass) {
    return true;
  }

  return ASTVisitor::visit(C);
}

bool IRGenerator::visit(Method *M) {
  // TODO: For now we're only processing the 'main' method; remove this check
  // when you're ready to process other methods
  if (M->getName() != strings::MainMethod) {
    return true;
  }

  // TODO: Generalize this piece of code to handle other methods
  std::string FunctionName("M4_Main_main");
  assert(!Module.getFunction(FunctionName) && "Function already exists");

  // TODO: We're abusively declaring Main::main as void(void) - it should take a
  // parameter representing 'self'
  CurrentFunction = llvm::Function::Create(
      llvm::FunctionType::get(llvm::Type::getVoidTy(Context), false),
      llvm::GlobalValue::ExternalLinkage, "M4_Main_main", &Module);
  assert(CurrentFunction && "Failed to create function");

  if (!visit(M->getBody())) {
    return false;
  }

  (void)Builder.CreateRetVoid();

  return true;
}

bool IRGenerator::visit(Block *B) {
  auto CurrentBlock = llvm::BasicBlock::Create(Context, "", CurrentFunction);
  assert(CurrentBlock && "Failed to create basic block");

  Builder.SetInsertPoint(CurrentBlock);

  if (!ASTVisitor::visit(B)) {
    return false;
  }

  return true;
}

bool IRGenerator::visit(Dispatch *D) {
  // TODO: We're only handling dispatches into the 'out' method, which we
  // hardcode to IO::out; remove this check when you're ready to handle other
  // dynamic dispatches
  if (D->getName() != "out") {
    return true;
  }

  for (auto Arg : *D) {
    if (!visit(Arg)) {
      return false;
    }
  }

  // Get the Value generated for the first (and only) argument
  // TODO: Generalize this to handle more than one argument
  auto OutputString = NodeMap[*D->begin()];
  if (!OutputString) {
    return true;
  }

  // TODO: Because we're not taking a 'self' object as parameter yet, we'll have
  // to create a new IO object here to pass into the IO::out method. You should
  // update this after implementing 'self'.
  auto IOType = Runtime.ioType();
  auto RIO = Runtime.ioRTTI();
  auto New = Runtime.lcplNew();

  // Create a new IO object and bitcast from void* to IO*
  auto NewIO = Builder.CreateBitCast(Builder.CreateCall(New, RIO),
                                     IOType->getPointerTo());

  auto IO_out = Runtime.ioOut();
  llvm::Value *OutArgs[] = {NewIO, OutputString};

  (void)Builder.CreateCall(IO_out, OutArgs);

  return true;
}

bool IRGenerator::visit(StringConstant *SC) {
  // Create a new String object and bitcast from void* to String*, then write
  // the value of the StringConstant into it in several steps:
  // * Write the length of the string into the new String object
  // * Create the storage for the string
  // * Write the pointer to the storage into the new String object
  // TODO: This is hardcoded to write "Hello world", make it more generic
  auto StringType = Runtime.stringType();
  auto RString = Runtime.stringRTTI();
  auto New = Runtime.lcplNew();

  auto NewString = Builder.CreateBitCast(Builder.CreateCall(New, RString),
                                         StringType->getPointerTo());
  std::string StringValue("Hello world!\n");
  auto LengthField =
      Builder.CreateGEP(NewString, {Builder.getInt32(0), Builder.getInt32(1)});
  (void)Builder.CreateStore(Builder.getInt32(StringValue.length()),
                            LengthField);

  auto StringField =
      Builder.CreateGEP(NewString, {Builder.getInt32(0), Builder.getInt32(2)});
  (void)Builder.CreateStore(Builder.CreateGlobalStringPtr(StringValue),
                            StringField);

  NodeMap[SC] = NewString;

  return true;
}
