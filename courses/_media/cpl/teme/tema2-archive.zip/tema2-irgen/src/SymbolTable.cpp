#include "SymbolTable.h"
#include "SemanticException.h"

#include <cassert>

using namespace lcpl;

void SymbolTable::pushScope() {
  auto *scope = new SymbolTableScope();
  symbolTable.push_back(scope);
}

void SymbolTable::popScope() {
  assert(!symbolTable.empty() && "popScope on an empty symbol table");

  SymbolTableScope *scope = symbolTable.back();
  symbolTable.pop_back();
  scope->clear();
  delete scope;
}

void SymbolTable::insert(TreeNode *v, const std::string &name) {
  SymbolTableScope *scope = symbolTable.back();
  (*scope)[name] = v;
}

TreeNode *SymbolTable::lookup(const std::string &name) const {
  assert(!symbolTable.empty() && "lookup on an empty symbol table");

  auto scope = getScope(name);

  if (scope) {
    auto it = scope->find(name);
    if (it != scope->end()) {
      return it->second;
    }
  }

  throw UnknownVariableException(name);
}

auto SymbolTable::getScope(const std::string &name) const
    -> SymbolTableScope * {
  for (int i = symbolTable.size() - 1; i >= 0; i--) {
    SymbolTableScope *scope = symbolTable[i];
    auto it = scope->find(name);
    if (it != scope->end()) {
      return scope;
    }
  }

  return nullptr;
}

