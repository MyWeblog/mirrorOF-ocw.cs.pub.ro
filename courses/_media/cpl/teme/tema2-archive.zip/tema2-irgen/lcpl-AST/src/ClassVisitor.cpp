#include "ClassVisitor.h"

#include <unordered_set>

using namespace lcpl;

bool ClassVisitor::visitProgram(Program *P) {
  std::unordered_set<Class *> Visited;
  for (auto C : *P) {
    if (!visitClass(C, Visited))
      return false;
  }

  return true;
}

bool ClassVisitor::visitClass(Class *C, std::unordered_set<Class *> &Visited) {
  if (Visited.count(C))
    return true;

  auto Parent = ASTTypes.getParentClass(C);

  if (Parent && !visitClass(Parent, Visited))
    return false;

  Visited.insert(C);

  if (ASTTypes.isBuiltinClass(C))
    return visitBuiltinClass(C);

  return visitUserClass(C);
}

bool ClassVisitor::visitBuiltinClass(Class *C) { return true; }
bool ClassVisitor::visitUserClass(Class *C) { return true; }
