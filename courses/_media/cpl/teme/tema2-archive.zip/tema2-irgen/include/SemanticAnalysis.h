#ifndef SEMANTIC_ANALYSIS_H
#define SEMANTIC_ANALYSIS_H

#include "ASTVisitor.h"
#include "SymbolTable.h"
#include "Type.h"
#include "TypeTable.h"

#include <map>

namespace lcpl {

/// \brief Performs the semantic analysis on the lcpl program received in the
/// constructor
class SemanticAnalysis : public ASTVisitor {
public:
  SemanticAnalysis(Program *p);
  virtual ~SemanticAnalysis() {}

  void runAnalysis();

  /// \brief Get the type table
  /// \warning  This should only be called after runAnalysis(), otherwise the
  ///           table will be empty
  TypeTable getTypeTable() { return typeTable; }

  /// \brief Get a map from symbols to their definitions
  SymbolMap getSymbolDefinitions() const { return definitionsMap; }

private:
  bool visit(Program *p) override;
  bool visit(Class *c) override;
  bool visit(Feature *f) override;

  bool visit(Attribute *a) override;

  bool visit(Method *m) override;
  bool visit(FormalParam *param) override;

  bool visit(Expression *e) override;

  bool visit(IntConstant *ic) override;
  bool visit(StringConstant *sc) override;
  bool visit(NullConstant *nc) override;
  bool visit(Symbol *s) override;

  bool visit(Block *b) override;
  bool visit(Assignment *a) override;
  bool visit(BinaryOperator *bo) override;
  bool visit(UnaryOperator *uo) override;
  bool visit(Cast *c) override;
  bool visit(Substring *s) override;
  bool visit(Dispatch *d) override;
  bool visit(StaticDispatch *d) override;
  bool visit(NewObject *n) override;
  bool visit(IfStatement *i) override;
  bool visit(WhileStatement *w) override;
  bool visit(LocalDefinition *local) override;

private:
  Program *program;
  TypeTable typeTable;
  SymbolTable symbolTable;
  SymbolMap definitionsMap;

  void checkMainClassAndMethod();
  void checkInheritanceGraph();

  void checkFeatures(Class *c);

  template <typename DispatchT> bool checkDispatchArgs(DispatchT *d, Method *m);
};
}

// Templates can't be defined in the implementation file, so in order to
// keep things clean(er) it is common practice to separate their implementations
// into another header file
#include "SemanticAnalysisImpl.h"

#endif /* __SEMANTIC_ANALYSIS__ */
