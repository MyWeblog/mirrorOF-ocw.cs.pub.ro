#ifndef __LCPL_PROGRAM__
#define __LCPL_PROGRAM__

#include <memory>
#include <string>
#include <utility>
#include <vector>
#include <map>

#include "Class.h"
#include "TreeNode.h"
#include "support/iterator.h"

namespace lcpl {
/// \brief AST node for an entire LCPL program
///
/// This should be the root of the AST
class Program : public TreeNode {
  typedef std::vector<std::unique_ptr<Class>> ClassesType;

  struct iterator
      : public llvm::iterator_adaptor_base<iterator,
                                           ClassesType::const_iterator> {
    explicit iterator(const ClassesType::const_iterator &&wrapped)
        : iterator_adaptor_base(wrapped) {}
    Class *operator*() const { return I->get(); }
  };

public:
  /// \brief Create a node for an entire program
  /// \note This takes ownership of \p classes if provided
  explicit Program(int lineNumber, const std::vector<Class *> &classes = {})
      : TreeNode(lineNumber), classes() {
    for (auto cls : classes) {
      this->classes.emplace_back(std::move(cls));
    }
  }

  /// \brief Add a class and take ownership of it
  void addClass(std::unique_ptr<Class> c) { classes.push_back(std::move(c)); }

  /// @{
  /// \brief Iterate through the program's classes
  iterator begin() const { return iterator(classes.begin()); }
  iterator end() const { return iterator(classes.end()); }
  /// @}

private:
  ClassesType classes;
};

typedef std::unique_ptr<Program> ProgramPtr;    
}
#endif // __LCPL_PROGRAM__
