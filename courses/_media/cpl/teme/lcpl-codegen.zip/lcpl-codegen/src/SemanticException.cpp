
#include <SemanticException.h>
using namespace lcpl;

std::ostringstream SemanticException::stringStream;
