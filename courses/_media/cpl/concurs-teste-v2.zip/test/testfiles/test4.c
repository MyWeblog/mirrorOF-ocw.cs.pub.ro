#include <stdio.h>

static void f()
{
	printf("f!\n");
}

static void g()
{
	printf("g!\n");
}

static void h()
{
	printf("h!\n");
}


int main()
{
	f();
	g();
	h();
	return 0;
}
