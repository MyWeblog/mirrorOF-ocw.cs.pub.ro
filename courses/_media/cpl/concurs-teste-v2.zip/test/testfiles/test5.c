#include <stdio.h>

static int z = -1;

int main()
{
	int x = 42;
	int y = 256;

	return x + y + (z * 512/2);
}
