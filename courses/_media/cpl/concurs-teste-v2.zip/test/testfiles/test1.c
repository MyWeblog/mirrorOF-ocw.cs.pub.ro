#include <stdio.h>
#include <stdlib.h>

int foo()
{
  exit(EXIT_FAILURE);
}


int main()
{
  printf("Hello, World!\n");
  foo();
  return 0;
}
