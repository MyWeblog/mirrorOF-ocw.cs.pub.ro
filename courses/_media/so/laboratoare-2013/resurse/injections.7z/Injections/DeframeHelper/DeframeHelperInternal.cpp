#include "stdafx.h"
#include "DeframeHelperInternal.h"
#include "DeframeHelper.h"

#pragma comment (linker, "/section:.shared,S")
#pragma data_seg (".shared")
HWND hwndInjector = NULL;	// Deframe main window

// messages
UINT wmDeframe = 0;	// used to notify Deframe of "deframing" a window
UINT wmReframe = 0; // used to notify Deframe of "reframing" a window

UINT lenRememberedWindows = 0;
// pretty weak for now; also no locking supplied (most probably not even needed)
// contains a list of window titles separated by 0's
TCHAR rememberedWindows[MAX_LEN_S_WINDOWS] = {0};
#pragma data_seg ()

HHOOK hShellHook;
HHOOK hWPHook;

HWND hWnd;
HMENU sysMenu;

PGWR_PROC pGetWindowRect;
bool isTopmost;
bool isBorderless;
bool isThick;
HotPatch patchGetWindowRect;

bool IsWindowTitleKnown(UINT len, TCHAR *title)
{
	for (UINT i = 0; i + len < lenRememberedWindows; ++i) {
		bool found = true;
		for (UINT j = 0; found && j < len; ++j)
			if (rememberedWindows[i + j] != title[j])
				found = false;
		if (found && 0 == rememberedWindows[i + len]) return true;
		while (0 != rememberedWindows[i]) ++i;
	}
	return false;
}

LONG InitialGetStyles()
{
	LONG result = GetWindowLong(hWnd, GWL_STYLE);
	isThick = 0 != (result & WS_THICKFRAME);
	return result;
}

void ToggleWindowBorders()
{
	static LONG originalStyles = InitialGetStyles();
	LONG styles = GetWindowLong(hWnd, GWL_STYLE);

	int captionHeight = GetSystemMetrics(SM_CYCAPTION);
	int borderWidth = GetSystemMetrics(isThick ? SM_CXSIZEFRAME : SM_CXDLGFRAME);
	int borderHeight = GetSystemMetrics(isThick ? SM_CYSIZEFRAME : SM_CYDLGFRAME);

	isBorderless = originalStyles == styles; // hWnd will be borderless when ToggleWindowBorders() returns
	if (!isBorderless) {
		// it's already borderless, so our GetWindowRect is in place
		patchGetWindowRect.RestoreOpcodes();
	}
	RECT rc;
	pGetWindowRect(hWnd, &rc);
	if (isBorderless)
		patchGetWindowRect.WriteOpcodes();

	if (isBorderless) {
		// shrink the window rectangle with the removed borders
		rc.left += borderWidth;
		rc.right -= borderWidth;
		rc.top += captionHeight + borderHeight;
		rc.bottom -= borderHeight;
	}
	else {
		// expand it with the added borders
		rc.left -= borderWidth;
		rc.right += borderWidth;
		rc.top -= captionHeight + borderHeight;
		rc.bottom += borderHeight;
	}

	styles ^= WS_CAPTION | (isThick ? WS_THICKFRAME : 0);
	LONG result = SetWindowLong(hWnd, GWL_STYLE, styles);
	if (0 != result)
		SetWindowPos(hWnd, NULL, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, SWP_FRAMECHANGED);

	if (NULL == hwndInjector)
		hwndInjector = FindWindow(NULL, TEXT("Deframe"));
	if (NULL != hwndInjector) {
		// notify Deframe of our work
		PostMessage(hwndInjector, isBorderless ? wmDeframe : wmReframe, reinterpret_cast<WPARAM>(hWnd), styles);
	}
	ModifyMenu(sysMenu, IDM_REMOVE_FRAME, MF_BYCOMMAND | (isBorderless ? MF_CHECKED : 0), IDM_REMOVE_FRAME, TEXT_NO_BORDER);
}

void ToggleWindowOnTop()
{
	if (!isTopmost) {
		SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		ModifyMenu(sysMenu, IDM_ALWAYS_ON_TOP, MF_BYCOMMAND | MF_CHECKED, IDM_ALWAYS_ON_TOP, TEXT_ON_TOP);
		isTopmost = true;
	}
	else {
		SetWindowPos(hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		ModifyMenu(sysMenu, IDM_ALWAYS_ON_TOP, MF_BYCOMMAND, IDM_ALWAYS_ON_TOP, TEXT_ON_TOP);
		isTopmost = false;
	}
}

BOOL WINAPI MyGetWindowRect(HWND hWnd, LPRECT lpRect)
{
	patchGetWindowRect.RestoreOpcodes();
	BOOL res = pGetWindowRect(hWnd, lpRect);
	patchGetWindowRect.WriteOpcodes();
	if (res) {
		// inflate the window rect, as if the window was fully decorated
		int captionHeight = GetSystemMetrics(SM_CYCAPTION);;
		int borderWidth = GetSystemMetrics(isThick ? SM_CXSIZEFRAME : SM_CXDLGFRAME);
		int borderHeight = GetSystemMetrics(isThick ? SM_CYSIZEFRAME : SM_CYDLGFRAME);

		lpRect->left -= borderWidth;
		lpRect->top -= captionHeight + borderHeight;
		lpRect->right += borderWidth;
		lpRect->bottom += borderHeight;
	}
	return res;
}

LRESULT CALLBACK ShellProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	if (HSHELL_WINDOWCREATED == nCode) {
		if (0 == pGetWindowRect) {
			HMODULE user32 = GetModuleHandle(TEXT("user32.dll"));
			if (NULL == user32) return 0;
			pGetWindowRect = reinterpret_cast<PGWR_PROC>(GetProcAddress(user32, "GetWindowRect"));
			patchGetWindowRect.SetDetour(pGetWindowRect, MyGetWindowRect);
			patchGetWindowRect.SetWriteProtection();
			patchGetWindowRect.SaveOpcodes();
		}

		hWnd = reinterpret_cast<HWND>(wParam);	// the process visible window; will be remembered
		
		// tamper with the system menu, if not already done
		sysMenu = GetSystemMenu(hWnd, FALSE);
		BOOL bRes;
		bRes = ModifyMenu(sysMenu, IDM_ALWAYS_ON_TOP, MF_BYCOMMAND, IDM_ALWAYS_ON_TOP, TEXT_ON_TOP);
		if (!bRes)
			AppendMenu(sysMenu, MF_STRING, IDM_ALWAYS_ON_TOP, TEXT_ON_TOP);
		bRes = ModifyMenu(sysMenu, IDM_REMOVE_FRAME, MF_BYCOMMAND | (isBorderless ? MF_CHECKED : 0), IDM_REMOVE_FRAME, TEXT_NO_BORDER);
		if (!bRes)
			AppendMenu(sysMenu, MF_STRING, IDM_REMOVE_FRAME, TEXT_NO_BORDER);

		TCHAR title[1024];
		int len = GetWindowText(hWnd, title, 1024);
		if (IsWindowTitleKnown(len, title)) {
			// this window was to be deframed automatically, so send a message to it (actually to WndProc()) about this
			SendMessage(hWnd, WM_SYSCOMMAND, IDM_REMOVE_FRAME, 0);
		}
	}
	return CallNextHookEx(hShellHook, nCode, wParam, lParam);
}

LRESULT CALLBACK WndProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	if (HCBT_SYSCOMMAND == nCode) {
		switch (wParam) {
		case IDM_REMOVE_FRAME:
			ToggleWindowBorders();
			break;

		case IDM_ALWAYS_ON_TOP:
			ToggleWindowOnTop();
			break;
		}
	}
	return 0;
}

void ProcessDetach()
{
	sysMenu = GetSystemMenu(hWnd, FALSE);
	RemoveMenu(sysMenu, IDM_ALWAYS_ON_TOP, MF_BYCOMMAND);
	RemoveMenu(sysMenu, IDM_REMOVE_FRAME, MF_BYCOMMAND);

	if (0 != pGetWindowRect) {
		patchGetWindowRect.RestoreOpcodes();
		patchGetWindowRect.RestoreProtection();
	}
}
