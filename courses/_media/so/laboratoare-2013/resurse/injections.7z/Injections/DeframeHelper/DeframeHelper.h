#pragma once

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the DEFRAMEHELPER_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// DEFRAMEHELPER_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef DEFRAMEHELPER_EXPORTS
#define DEFRAMEHELPER_API __declspec(dllexport)
#else
#define DEFRAMEHELPER_API __declspec(dllimport)
#endif

static const DWORD IDM_REMOVE_FRAME = 0x1000000;
static const DWORD IDM_ALWAYS_ON_TOP = 0x2000000;

#define DEFRAME_MESSAGE_DE TEXT("Deframe-de")
#define DEFRAME_MESSAGE_RE TEXT("Deframe-re")

#ifdef __cplusplus
extern "C" {
#endif

DEFRAMEHELPER_API void InstallHook();
DEFRAMEHELPER_API void RemoveHook();

// int n = SetRemenberedWindows(len, windowList) informs the library about windows to automatically tamper with.
// Parameters:
//	int len				- the length of the window list string
//	TCHAR *windowList	- the window list string, contains window names separated by 0's
// Return value:
//	int n				- 0 on success, the maximum acceptable length otherwise
DEFRAMEHELPER_API int SetRememberedWindows(int len, TCHAR *windowList);

#ifdef __cplusplus
}
#endif
