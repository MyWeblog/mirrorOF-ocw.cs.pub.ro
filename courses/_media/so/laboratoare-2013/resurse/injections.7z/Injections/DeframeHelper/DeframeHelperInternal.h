#pragma once

#include "HotPatch.h"

#define TEXT_ON_TOP TEXT("On top")
#define TEXT_NO_BORDER TEXT("No borders")
#define MAX_LEN_S_WINDOWS 4096

typedef BOOL (WINAPI *PGWR_PROC)(HWND, LPRECT);

LRESULT CALLBACK ShellProc(int nCode, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK WndProc(int nCode, WPARAM wParam, LPARAM lParam);
BOOL WINAPI MyGetWindowRect(HWND hWnd, LPRECT lpRect);
void ToggleWindowBorders(HWND hWnd);
void ProcessDetach();
bool IsWindowTitleKnown(UINT len, TCHAR *title);
