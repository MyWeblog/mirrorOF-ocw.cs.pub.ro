#include "stdafx.h"
#include "DeframeHelper.h"
#include "DeframeHelperInternal.h"

extern HHOOK hShellHook;
extern HHOOK hWPHook;
extern HMODULE hDeframeHelper;
extern UINT wmDeframe;
extern UINT wmReframe;
extern UINT lenRememberedWindows;
extern TCHAR rememberedWindows[MAX_LEN_S_WINDOWS];

extern "C" DEFRAMEHELPER_API void InstallHook()
{
	hShellHook = SetWindowsHookEx(WH_SHELL, ShellProc, hDeframeHelper, 0);	// intercepts window creation
	hWPHook = SetWindowsHookEx(WH_CBT, WndProc, hDeframeHelper, 0);	// intercepts system menu commands
	if (0 == wmDeframe) {
		// setup the messages used to signal the host application (Deframe/64)
		wmDeframe = RegisterWindowMessage(DEFRAME_MESSAGE_DE);
		wmReframe = RegisterWindowMessage(DEFRAME_MESSAGE_RE);
	}
}

extern "C" DEFRAMEHELPER_API void RemoveHook()
{
	if (NULL != hShellHook) {
		UnhookWindowsHookEx(hShellHook);
		hShellHook = NULL;
	}
	if (NULL != hWPHook) {
		UnhookWindowsHookEx(hWPHook);
		hWPHook = NULL;
	}
}

extern "C" DEFRAMEHELPER_API int SetRememberedWindows(int len, TCHAR *windowList)
{
	if (len > MAX_LEN_S_WINDOWS) return MAX_LEN_S_WINDOWS;
	for (int i = 0; i < len; ++i)
		rememberedWindows[i] = windowList[i];
	lenRememberedWindows = len;
	return 0;
}
