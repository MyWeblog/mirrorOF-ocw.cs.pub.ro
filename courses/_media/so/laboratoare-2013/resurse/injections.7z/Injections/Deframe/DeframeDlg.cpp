
// DeframeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Deframe.h"
#include "DeframeDlg.h"
#include "DeframeHelper.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CDeframeDlg dialog




CDeframeDlg::CDeframeDlg(CStringArray *pRememberedWindows/* = NULL*/, CWnd* pParent /*=NULL*/)
	: CDialog(CDeframeDlg::IDD, pParent),
	wmExplorerRestarted(0),
	wmDeframe(0),
	wmReframe(0),
	exiting(false)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	if (NULL != pRememberedWindows)
		rememberedWindows.Append(*pRememberedWindows);
}

void CDeframeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_WINDOWS, lstWindows);
}

BEGIN_MESSAGE_MAP(CDeframeDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_SIZE()
	ON_CLBN_CHKCHANGE(IDC_LIST_WINDOWS, OnCheckChange)
END_MESSAGE_MAP()


// CDeframeDlg message handlers

BOOL CDeframeDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	AddTrayIcon(IDR_MAINFRAME, TEXT("Deframe"));

	// register the user level Windows messages used to signal different events
	wmExplorerRestarted = RegisterWindowMessage(TEXT("TaskbarCreated"));	// Explorer specific message
	wmDeframe = RegisterWindowMessage(DEFRAME_MESSAGE_DE);	// from DeframeHelper
	wmReframe = RegisterWindowMessage(DEFRAME_MESSAGE_RE);	// from DeframeHelper

	for (int i = 0; i < rememberedWindows.GetCount(); ++i)
		lstWindows.AddString(rememberedWindows[i]);
	for (int i = 0; i < rememberedWindows.GetCount(); ++i)
		lstWindows.SetCheck(i, BST_CHECKED);
	AnnounceRememberedWindows();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDeframeDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDeframeDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDeframeDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

// BOOL res = CDeframeDlg::SetTrayIcon(dwMessage, idIcon, szToolTip) general notification area icon manipulation routine.
// Parameters:
//	DWORD dwMessage				- see Shell_NotifyIcon() in MSDN for details.
//	int idIcon					- resource id for the icon to add to the notification area.
//	const CString& szToolTip	- text to show when hovering the icon in the notification area.
// Return value:
//	BOOL res					- TRUE on success, see Shell_NotifyIcon() in MSDN for details.
BOOL CDeframeDlg::SetTrayIcon(DWORD dwMessage, int idIcon, const CString& szToolTip)
{
	NOTIFYICONDATA niData;
	ZeroMemory(&niData, sizeof(NOTIFYICONDATA));
	niData.cbSize = sizeof(niData);
	niData.hWnd = m_hWnd;
	niData.uID = 0;
	if (NIM_DELETE != dwMessage) {
		niData.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
		niData.uCallbackMessage = DF_MESSAGE;
		niData.hIcon = LoadIcon(theApp.m_hInstance, MAKEINTRESOURCE(idIcon));
		lstrcpy(niData.szTip, szToolTip);
	}
	return Shell_NotifyIcon(dwMessage, &niData);
}

void CDeframeDlg::OnOK()
{
	// just minimize (hide) the window
	SendMessage(WM_SIZE, SIZE_MINIMIZED);
}

void CDeframeDlg::OnCancel()
{
	exiting = true;
	if (trackedWindows.GetSize() > 0) {
		// first signal all the windows having DeframeHelper in them (patched GetClientRect()) to unload it cleanly
		POSITION pos = trackedWindows.GetStartPosition();
		while (pos) {
			HANDLE hWnd;
			UINT styles;
			trackedWindows.GetNextAssoc(pos, hWnd, styles);
			if (!IsWindow(static_cast<HWND>(hWnd)))
				trackedWindows.RemoveKey(hWnd);
			else {
				// simulate a click that toggles the frame. This will cleanly restore GetClientRect().
				::SendMessage(static_cast<HWND>(hWnd), WM_SYSCOMMAND, IDM_REMOVE_FRAME, 0);
			}
		}
	}
	// if the above only references invalid windows just exit
	if (trackedWindows.GetSize() == 0) {
		RemoveTrayIcon();
		CDialog::OnCancel();
	}
}

LRESULT CDeframeDlg::WindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) {
	case DF_MESSAGE:
		// Notification Area event
		switch(lParam) {
		case WM_LBUTTONUP:
			if (IsWindowVisible()) {
				ShowWindow(SW_MINIMIZE);
				ShowWindow(SW_HIDE);
			}
			else {
				ShowWindow(SW_SHOW);
				ShowWindow(SW_RESTORE);
			}
			break;

		case WM_RBUTTONUP:
			{
				CMenu trayMenu;
				trayMenu.LoadMenu(IDR_MENU_CONTEXT);
				trayMenu.SetDefaultItem(ID_CONTEXT_TOGGLEDEFRAME);
				CPoint pt;
				GetCursorPos(&pt);
				SetForegroundWindow();
				trayMenu.GetSubMenu(0)->TrackPopupMenu(TPM_LEFTALIGN, pt.x, pt.y, this);
			}
			break;
		}
		break;
	default:
		if (wmExplorerRestarted == message) {
			AddTrayIcon(IDR_MAINFRAME, TEXT("Deframe"));
		}
		else if (wmDeframe == message) {
			// message from DeframeHelper - it deframed something
			CWnd theWnd;
			theWnd.m_hWnd = reinterpret_cast<HWND>(wParam);
			CString title;
			theWnd.GetWindowText(title);
			bool found = false;
			for (int i = 0; !found && i < lstWindows.GetCount(); ++i) {
				CString haveText;
				lstWindows.GetText(i, haveText);
				if (0 == haveText.Compare(title))
					found = true;
			}
			if (!found) {
				// this window wasn't deframed before
				lstWindows.AddString(title);
			}
			trackedWindows.SetAt(reinterpret_cast<HANDLE>(wParam), static_cast<UINT>(lParam));
			theWnd.m_hWnd = 0;	// else ~CWnd() will destroy another's process window
		}
		else if (wmReframe == message) {
			// DeframeHelper reframed something
			trackedWindows.RemoveKey(reinterpret_cast<HANDLE>(wParam));
			if (exiting && 0 == trackedWindows.GetSize()) {
				// the last window we were waiting for just got reframed, its GetWindowRect() is back to stock
				// nothing else runs code from DeframeHelper, safe to unload and finish
				OnCancel();
			}
		}
	}

	return CDialog::WindowProc(message, wParam, lParam);
}

void CDeframeDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	// TODO: Add your message handler code here
	if (SIZE_MINIMIZED == nType) {
		ShowWindow(SW_MINIMIZE);
		ShowWindow(SW_HIDE);
	}
}

BOOL CDeframeDlg::OnCommand(WPARAM wParam, LPARAM lParam)
{
	// TODO: Add your specialized code here and/or call the base class
	switch (wParam) {
	case ID_CONTEXT_TOGGLEDEFRAME:
		SendMessage(DF_MESSAGE, 0, WM_LBUTTONUP);
		break;

	case ID_CONTEXT_EXIT:
		OnCancel();
		break;
	}
	return CDialog::OnCommand(wParam, lParam);
}

void CDeframeDlg::OnCheckChange()
{
	rememberedWindows.RemoveAll();
	int len = 0;
	for (int i = 0; i < lstWindows.GetCount(); ++i)
		if (lstWindows.GetCheck(i)) {
			CString title;
			lstWindows.GetText(i, title);
			rememberedWindows.Add(title);
			len += title.GetLength();
		}
	AnnounceRememberedWindows();
}

// Collapses the list of remembered window names with 0's inbetween and ships it to DeframeHelper.
void CDeframeDlg::AnnounceRememberedWindows()
{
	int len = 0;
	for (int i = 0; i < rememberedWindows.GetCount(); ++i)
		len += 1 + rememberedWindows[i].GetLength();
	TCHAR *res = new TCHAR[len];
	TCHAR *pos = res;
	for (int i = 0; i < rememberedWindows.GetCount(); ++i) {
		MoveMemory(pos, rememberedWindows[i], sizeof(TCHAR) * rememberedWindows[i].GetLength());
		pos += rememberedWindows[i].GetLength();
		*pos++ = 0;
	}
	SetRememberedWindows(len, res);
	delete []res;
}
