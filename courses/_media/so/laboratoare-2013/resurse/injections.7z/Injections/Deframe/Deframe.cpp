
// Deframe.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Deframe.h"
#include "DeframeDlg.h"
#include "DeframeHelper.h"
#include <cstdio>
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CDeframeApp

BEGIN_MESSAGE_MAP(CDeframeApp, CWinAppEx)
	ON_COMMAND(ID_HELP, &CWinApp::OnHelp)
END_MESSAGE_MAP()


// CDeframeApp construction

CDeframeApp::CDeframeApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CDeframeApp object

CDeframeApp theApp;


// CDeframeApp initialization

BOOL CDeframeApp::InitInstance()
{
	CWnd *oldDeframe = CWnd::FindWindow(NULL, TEXT("Deframe"));
	if (NULL != oldDeframe) {
		oldDeframe->ShowWindow(SW_NORMAL);
		oldDeframe->SetForegroundWindow();
		oldDeframe->SetFocus();
		return FALSE;
	}

	// InitCommonControlsEx() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// Set this to include all the common control classes you want to use
	// in your application.
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinAppEx::InitInstance();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	CStringArray rememberedWindows;
	ReadIniSettings(&rememberedWindows);

	TCHAR path[MAX_PATH];
	DWORD len = GetModuleFileName(NULL, path, MAX_PATH);
	while (path[len - 1] != '\\') --len;
	MoveMemory(path + len, TEXT("Deframe64.dat"), sizeof(TCHAR) * (lstrlen(TEXT("Deframe64.dat")) + 1));
	STARTUPINFO siDeframe64 = {sizeof(STARTUPINFO)};
	PROCESS_INFORMATION piDeframe64;
	BOOL bRes = CreateProcess(0, path, NULL, NULL, TRUE, 0, NULL, NULL, &siDeframe64, &piDeframe64);
	if (bRes) WaitForInputIdle(piDeframe64.hProcess, INFINITE);

	InstallHook();

	CDeframeDlg dlg(&rememberedWindows);
	m_pMainWnd = &dlg;
	INT_PTR nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	RemoveHook();
	
	if (bRes) ::PostThreadMessage(piDeframe64.dwThreadId, WM_QUIT, 0, 0);

	SaveIniSettings(&(dlg.GetRememberedWindows()));

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

void CDeframeApp::ReadIniSettings(CStringArray *pRememberedWindows)
{
	TCHAR path[MAX_PATH];
	DWORD len = GetModuleFileName(NULL, path, MAX_PATH);
	while (path[len - 1] != '.') --len;
	path[len++] = 'i';
	path[len++] = 'n';
	path[len++] = 'i';
	path[len] = 0;
	
	pRememberedWindows->RemoveAll();
	FILE *fp = _wfopen(path, TEXT("rt"));
	if (!fp) return;
	while (!feof(fp)) {
		wchar_t line[1024];
		*line = 0;
		fgetws(line, 1024, fp);
		if (0 != *line) pRememberedWindows->Add(line);
	}
	fclose(fp);
}

void CDeframeApp::SaveIniSettings(CStringArray *pRemembeedWindows)
{
	TCHAR path[MAX_PATH];
	DWORD len = GetModuleFileName(NULL, path, MAX_PATH);
	while (path[len - 1] != '.') --len;
	path[len++] = 'i';
	path[len++] = 'n';
	path[len++] = 'i';
	path[len] = 0;

	FILE *fp = _wfopen(path, TEXT("wt"));
	for (int i = 0; i < pRemembeedWindows->GetCount(); ++i)
		fputws(pRemembeedWindows->operator [](i), fp);
	fclose(fp);
}
