//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Deframe.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DEFRAME_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       130
#define IDR_MENU_CONTEXT                130
#define IDC_LIST1                       1001
#define IDC_LIST_WINDOWS                1001
#define ID_DEFRAME_EXIT                 32771
#define ID_CONTEXT_TOGGLEDEFRAME        32777
#define ID_CONTEXT_EXIT                 32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
