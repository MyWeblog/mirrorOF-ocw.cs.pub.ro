
// DeframeDlg.h : header file
//

#pragma once
#include "afxcmn.h"
#include "afxwin.h"


// CDeframeDlg dialog
class CDeframeDlg : public CDialog
{
// Construction
public:
	CDeframeDlg(CStringArray *pRememberedWindows = NULL, CWnd* pParent = NULL);	// standard constructor

	CStringArray &GetRememberedWindows() { return rememberedWindows; }

// Dialog Data
	enum { IDD = IDD_DEFRAME_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
private:
	BOOL SetTrayIcon(DWORD dwMessage, int idIcon, const CString& szToolTip);
	
	// BOOL res = CDeframeDlg::AddTrayIcon(idIcon, szToolTip) adds given icon to the notification area.
	// Arguments:
	//	int idIcon					- resource id of the icon to add.
	//	const CString& szToolTip	- message to display when hovering the icon in the notification area.
	// Return value:
	//	BOOL res					- TRUE on success.
	BOOL AddTrayIcon(int idIcon, const CString& szToolTip)
	{
		return SetTrayIcon(NIM_ADD, idIcon, szToolTip);
	}

	// BOOL res = CDeframeDlg::ModifyTrayIcon(idIcon, szToolTip) modifies an icon previously added by CDeframeDlg::AddTrayIcon().
	// Arguments:
	//	int idIcon					- resource id of the icon to add.
	//	const CString& szToolTip	- message to display when hovering the icon in the notification area.
	// Return value:
	//	BOOL res					- TRUE on success.
	BOOL ModifyTrayIcon(int idIcon, const CString& szToolTip)
	{
		return SetTrayIcon(NIM_MODIFY, idIcon, szToolTip);
	}

	// BOOL res = CDeframeDlg::RemoveIcon() removes the previously added icon from the notification area.
	// Return value:
	//	BOOL res	- TRUE on success.
	BOOL RemoveTrayIcon()
	{
		return SetTrayIcon(NIM_DELETE, 0, TEXT(""));
	}

	void AnnounceRememberedWindows();

	static const UINT DF_MESSAGE = WM_USER + 1;
	
	// messages; initialized in OnInitDialog()
	UINT wmExplorerRestarted;
	UINT wmDeframe;	// message received when DeframeHelper removes some frames
	UINT wmReframe;	// message received when DeframeHelper adds the frames back
	
	CMap<HANDLE, HANDLE, UINT, UINT> trackedWindows;	// windows currently running code from DeframeHelper
	CStringArray rememberedWindows;
	bool exiting;
	CCheckListBox lstWindows;
protected:
	virtual void OnOK();
	virtual void OnCancel();
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnCheckChange();
protected:
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
};
