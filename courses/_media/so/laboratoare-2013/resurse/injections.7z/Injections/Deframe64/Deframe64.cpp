#include <windows.h>
#include "DeframeHelper.h"

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	InstallHook();
	// main message loop:
	MSG msg;
	while (GetMessage(&msg, NULL, 0, 0) && WM_QUIT != msg.message) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	RemoveHook();
	return static_cast<int>(msg.wParam);
}
