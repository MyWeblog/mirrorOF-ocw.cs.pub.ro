#!/usr/bin/python

import os
import posix_ipc
import mmap

def read_from_memory(mapfile):
    """Reads a string from the mapfile and returns that string"""
    mapfile.seek(0)
    s = [ ]
    c = mapfile.read_byte()
    while c != '\0':
        s.append(c)
        c = mapfile.read_byte()

    s = ''.join(s)

    return s


if __name__ == '__main__':
    SHM_NAME = "/my_mem"
try:
    shm = posix_ipc.SharedMemory(SHM_NAME)

    print 'Dumping info about this shared memory'
    print '    File descriptor ' + str(shm.fd)
    print '    Size ' + str(shm.size)

    mapfile = mmap.mmap(shm.fd, shm.size)
    print 'From SHM I read \"' + read_from_memory(mapfile) + '\"'
    mapfile.close()
    shm.close_fd()

except:
    print "Failed to open shared memory " + SHM_NAME;

