/*
 * util.h : macro-uri si constante utile 
 * IPC - SO - Lab 5 - ex 3
 */

#ifndef __UTIL_H__
#define __UTIL_H__	1

#include <sys/user.h>

/**
 * identificator pentru zona de memorie partajata
 */
#define SHM_NAME	"/my_mem"

/**
 * functie macro utila pentru simplificarea codului 
 * de tratare a erorilor
 */
#define CHECK(x) \
	do { \
		if (!(x)) { \
			printf("%s:%d: ", __func__, __LINE__); \
			perror(#x); \
			exit(EXIT_FAILURE); \
		} \
	} while (0) \

/**
 * dimensiunea zonei de memorie partajate
 */
#define SHM_SIZE	PAGE_SIZE

#endif
