/**
 * Server pentru memoria partajata
 * SO - Laborator 5 - IPC
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <sys/mman.h>
#include <sys/types.h>
#include <fcntl.h>

#include "util.h"

#define HELLO "Hello python!"

int main(void)
{
	void *mem;	/* adresa de mapare */
	int shm_fd;	/* descriptor zona de memorie */

	/* creeaza zona de memorie partajata */
	shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0644);

	/* redimensionarea zonei de memorie */
	CHECK(ftruncate(shm_fd, SHM_SIZE) >= 0);

	mem = mmap(0, SHM_SIZE, PROT_WRITE | PROT_READ, MAP_SHARED, shm_fd, 0);
	CHECK(mem != MAP_FAILED);

	strncpy(mem, HELLO, strlen(HELLO) + 1);
	printf("Am scris: %s\n", (char *) mem);

	/* demapeaza zona de memorie */
	CHECK(munmap(mem, SHM_SIZE) >= 0);

	/* inchide descriptorul zonei de memorie */
	CHECK(close(shm_fd) >= 0);

	sleep(20);

	/* sterge zona de memorie */
	CHECK(shm_unlink(SHM_NAME) >= 0);

	return 0;
}

