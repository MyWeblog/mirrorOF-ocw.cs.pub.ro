/*
*	SO - Tema 0	# Linux
*	Guardian Process
*
*	Oana Baron
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>

#define CHECK(x) \
    do { \
        if (!(x)) { \
            perror(#x); \
            exit(1); \
        } \
    } while(0) 

#define GUARDIAN_LOCK_FILE      "/tmp/.guardian.lock"
#define CHILD	2

int restart;
pid_t pid;

/*
 *	Verifica daca mai exista vreun guardian
 *	In caz ca mai exista vreo instanta - termina procesul
 *	Altfel intoarce file descriptorul fisierului pentru lock
 */
int lock_guardian(){
  
	int fd, ret;
	
	fd = open(GUARDIAN_LOCK_FILE, O_CREAT | O_WRONLY, 0644);
	CHECK(fd != -1);
	
	ret = flock(fd, LOCK_EX | LOCK_NB);
	if (ret == -1) {
		if (errno == EWOULDBLOCK) {
		  
			fprintf(stderr, "Guardian is already running\n");
			exit(EXIT_FAILURE);
		} else	CHECK(ret != -1);
	}
	
	return fd;
}

/*
 *	@fd - file descriptor al fisierului de log
 
 *	Elibereaza lock-ul pe fisier
 */
void clean(int fd) {

	CHECK(flock(fd, LOCK_UN) != -1);
	CHECK(close(fd) != -1);
	CHECK(unlink(GUARDIAN_LOCK_FILE) != -1);
}

/*
 *	Adauga directorul curent la sfarsitul lui $PATH
 */
void update_path() {

	char *aux, *new;
	
	aux = getenv("PATH");
	CHECK(aux != NULL);
	
	new = calloc(strlen(aux) + 3, sizeof(char));
	CHECK(new != NULL);
	
	strcpy(new, aux);
	strcat(new, ":.");
	
	CHECK(setenv("PATH", new, 1) != -1);

	free(new);
	new = NULL;
}

/*
 *	@name - numele comenzii
 *
 *	Redirecteaza stdin  catre "/dev/null"
 *		     stdout catre name.stdout
 *		     stderr catre name.stderr
 */
void redirect(char *name) {

	int fd;
	char *filename;

	filename = calloc(strlen(name) + 8, sizeof(char));
	CHECK(filename != NULL);
	
	/* in  */
	fd = open("/dev/null", O_RDONLY);
	CHECK(fd != -1);
	CHECK(dup2(fd, STDIN_FILENO) != -1);
	
	/* out */
	sprintf(filename, "%s.stdout", name);
	fd = open(filename, O_CREAT | O_WRONLY | O_APPEND, 0644);
	CHECK(fd != -1);
	CHECK(dup2(fd, STDOUT_FILENO) != -1);
	
	/* err */
	sprintf(filename, "%s.stderr", name);
	fd = open(filename, O_CREAT | O_WRONLY | O_APPEND, 0644);
	CHECK(fd != -1);
	CHECK(dup2(fd, STDERR_FILENO) != -1);
	
	free(filename);
	filename = NULL;
}

/*
 * 	@signum - numarul semnalului 
 *
 *	Handlerul monitorizeaza urmatoarele semnale:
 *		* SIGINT - opreste procesul
 *		* SICONT - reporneste procesul
 */
static void guardian_handler(int signum) {
  
	// stop command
	if (signum == SIGINT) {
		kill(pid, SIGKILL);
		restart = 0;
		return;
	}
	
	// restart command
	if (signum == SIGCONT) {
		kill(pid, SIGKILL);
		return;
	}
	
	fprintf(stderr, "Exception - signal %d\n", signum);
}

/*
 * 	Seteaza handlerul pentru SIGINT si SIGCONT
 */
void init_handler() {
  
	struct sigaction semnale;
	sigset_t mask;
	
	CHECK(sigfillset(&mask) != -1);
	CHECK(sigdelset(&mask, SIGINT) != -1);
	CHECK(sigdelset(&mask, SIGCONT) != -1);
	CHECK(sigprocmask(SIG_BLOCK, &mask, NULL) != -1);
	
	CHECK(sigemptyset(&mask) != -1);
	CHECK(sigaddset(&mask, SIGCONT) != -1);
	CHECK(sigaddset(&mask, SIGINT ) != -1); 

	memset(&semnale,0,sizeof(struct sigaction));
	semnale.sa_mask = mask;
	semnale.sa_handler = guardian_handler;
	CHECK(sigaction(SIGCONT, &semnale, NULL) != -1);
	CHECK(sigaction(SIGINT , &semnale, NULL) != -1);

}

void loop(char* cmd, char *argv[]) {

	int status, ret;

	restart = 1;
	while(restart) {
		pid = fork();
		CHECK(pid != -1);

		if (pid == 0) {
			/* child */
			redirect(cmd);
			execvp(cmd, argv);

			exit(CHILD);
		}
		
		/* parent */
		ret = waitpid(pid, &status, 0);
		
		if (WEXITSTATUS(status) == CHILD)
		{
			fprintf(stderr, "The child program does not exist!\n");
			return;
		}
		

	}
}

int main(int argc, char *argv[]) {

	int lock_fd;

	if (argc < 2) {
		fprintf(stderr, "Usage: ./guardian nume_program arg1 arg2 ...\n");
		return EXIT_FAILURE;
	}

	lock_fd = lock_guardian();

	CHECK(daemon(1, 1) != -1);

	update_path();
	init_handler();
	
	loop(argv[1], argv + 1);

	clean(lock_fd);
	return 0;
}
