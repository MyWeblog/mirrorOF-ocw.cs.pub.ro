/*!
 Tema 0 SO, Guardian process

 @author Drutu Bogdan-Cristian

 Copyright (C) 2010 SO (http://cs.pub.ro/~so/)

 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include <signal.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>

#define ERROR(msg) {\
			fprintf(stderr,msg);\
			exit(EXIT_FAILURE);\
		}


// Necesar pentru a putea opri sau reporni acest proces
volatile int proc_pid;

/*
 * redirectarea stdout si stderr 
 */
void redirectOut(char * command) {
	int fd = 0;
	char *file = (char *) calloc (30, sizeof(char));

	// redirectare stdin
	memset (file, 0, sizeof(file));
	sprintf(file,"/dev/null");
	if ((fd = open(file, O_RDONLY)) < 0)
		ERROR("Unable to open file\n");
	if (dup2 (fd, STDIN_FILENO) < 0)
		ERROR("Unable to duplificate file\n");
	close(fd);

	// redirectare stdout
	memset (file, 0, sizeof(file));
	sprintf(file,"%s.stdout", command);

	if ((fd = open(file, O_WRONLY | O_CREAT | O_APPEND, 0644)) < 0)
		ERROR("Unable to open file\n");
	if (dup2 (fd, STDOUT_FILENO) < 0)
		ERROR("Unable to duplificate file\n");
	close(fd);

	// redirectare stderr
	memset (file, 0, sizeof(file));
	sprintf(file,"%s.stderr",command);
	if ((fd = open(file, O_WRONLY | O_CREAT | O_APPEND, 0644)) < 0)
		ERROR("Unable to open file\n");

	if (dup2 (fd, STDERR_FILENO) < 0)
		ERROR("Unable to duplificate file\n");
	close(fd);
	
	free(file);
}

/*
 * executarea unei comenzi data 
 */
void execute_command(char **command, int redirect) {
    int pid, status;

    switch ((pid=fork())) 
    {
        case -1:
            //error forking.
            return;
        case 0:
        {
        	// redirectam stdin, stdout si stderr
        	if (redirect) 
        		redirectOut(command[0]);
        		
            /* 
             * exec se poate întoarce doar cu cod de eroare (de ex. când
             * nu se găsește fișierul de executat).
             * În caz de eroare incercam sa executam din calea curenta,
             * altfel terminăm procesul copil 
             */
        	if (execvp(command[0],command) < 0)
        		execv(command[0],command);

	       	ERROR("Error Execution\n");
        }
    }

	// setam procesul copilului ca fiind global
	proc_pid = pid;

	// asteptam terminarea copilului
	waitpid(pid, &status, 0);
	
//	printf("%d\n",WEXITSTATUS(status));
	if (WEXITSTATUS(status) == 1)
		ERROR("The child program does not exist!\n");
}

/*
 * handler de semnal 
 */
void signalHandler(int signo) {
	switch (signo) 
	{
		case SIGINT:
			kill(proc_pid,9);
			exit(EXIT_SUCCESS);
			break;

		case SIGCONT:
			kill(proc_pid,9);
			break;
	}
}

/*
 * configurarea handler-elor de semnal necesare
 */
void set_signals() {
	sigset_t new, old;

	if (sigfillset(&new) < 0)
		ERROR("Error sigfillset\n");
		
	if (sigdelset(&new, SIGINT) < 0)
		ERROR("Error sigdelset\n");
	
	if (sigdelset(&new, SIGCONT) < 0)
		ERROR("Error sigdelset\n");

	if (sigprocmask(SIG_SETMASK, &new, &old) < 0)
		ERROR("Error sigprocmask\n");


	struct sigaction sa;

	memset(&sa, 0, sizeof(sa));
	sa.sa_handler = signalHandler;

	if (sigaction(SIGINT, &sa, NULL) < 0)
		ERROR("sigaction\n");

	if (sigaction(SIGCONT, &sa, NULL) < 0)
		ERROR("sigaction\n");
}

int main(int argc, char **argv) {

	daemon(1,1);

	int fd;
	struct flock *lock;

	if ((fd = open("/tmp/.lock",O_RDWR | O_CREAT | O_TRUNC, 0644)) < 0)
		ERROR("Open file error\n");
		
	lock = (struct flock *) calloc(1, sizeof(struct flock));
	lock->l_type = F_WRLCK;
	lock->l_whence = SEEK_SET;
	lock->l_len = 1;
	
	if (fcntl(fd,F_SETLK,lock) == -1)
		ERROR("Guardian is already running\n");

	if (argc < 2)
		ERROR("Usage: nume_program arg1 arg2 ...\n");
	
	set_signals();
	
	while (1) {
		execute_command (&argv[1],1);
	}

	return 0;
}

