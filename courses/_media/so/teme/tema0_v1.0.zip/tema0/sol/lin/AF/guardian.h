#define CHECKERR(cond)				\
	do {					\
		if (cond) {			\
			perror(#cond);		\
			exit(EXIT_FAILURE);	\
		}				\
	} while(0)

#define GUARDIAN_LOCK	"/tmp/.guardian.lock"

#define LOCK_TAKEN	-1
#define LOCK_AVAILABLE	1

#define SUFFIX_LENGTH	6

#define CHILD_ERROR	0xDEADBEEF

