/**
 * SO Homework #0 Linux, Guardian Process
 *
 * @author Cătălin Moraru
 * Copyright (C) 2010, SO team (http://cs.pub.ro/~so/)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

#define CHECK(x)	 									\
	do { 												\
		if (!(x)) { 									\
			printf("[%s]:%s:%d: ", __FILE__,			\
			__func__, __LINE__);						\
			perror(#x); 								\
			exit(EXIT_FAILURE);							\
		} 												\
	} while(0)

#define		MAX_CMD_NAME	128
#define		LOCK_FILE		"/tmp/.my_guard_file"

static int restart = 1;
static pid_t  pid = (pid_t) -1;
static int fdlock = -1;


/**
 *	Control the guardian with signals:
 *	@SIGINT: 	respawn the child
 *	@SIGCONT:	kill child and exit stop the main loop
 */
static void sig_handler(int signo){
	switch(signo){
		case SIGINT:
			restart = 0;		
			kill(pid, SIGKILL);
			break;
			
		case SIGCONT:
			kill(pid, SIGKILL);
			break;
	}
}

/**
 * Set redirections for the new child
 *	stdin	-> /dev/null
 *	stdout	-> name.stdout
 *	stderr	-> name.stderr
 */
void set_redirect(char *name){	
	int fd;
	
	/** stdin */
	CHECK(fd = open("/dev/null", O_RDONLY, 0111));
	CHECK(dup2(fd, STDIN_FILENO) >= 0);	
	
	/** stdout */
	char *my_stdout = (char*) malloc (MAX_CMD_NAME);
	snprintf(my_stdout, MAX_CMD_NAME, "%s.stdout", name);
	
	CHECK(fd = open(my_stdout, O_WRONLY | O_APPEND | O_CREAT, 0644));
	CHECK(dup2(fd, STDOUT_FILENO) >= 0);
	free(my_stdout);
	
	/** stderr */
	char *my_stderr = (char*) malloc (MAX_CMD_NAME);
	snprintf(my_stderr, MAX_CMD_NAME, "%s.stderr", name);
	
	CHECK(fd = open(my_stderr, O_WRONLY | O_APPEND | O_CREAT, 0644));
	CHECK(dup2(fd, STDERR_FILENO) >= 0);
	free(my_stderr);
}

/**
 *	Check if the process is the only one running
 *  Try setting a lock on the LOCK_FILE
 */
void check_singularity(){
	int ret;
	struct flock fl;

	fl.l_type 	= F_WRLCK;
	fl.l_whence = SEEK_SET;
	fl.l_start 	= 0;
	fl.l_len 	= 1;

	CHECK((fdlock = open(LOCK_FILE, O_WRONLY|O_CREAT, 0666)) != -1);

	if((ret = fcntl(fdlock, F_SETLK, &fl)) == -1){
		if (errno == EACCES || errno == EAGAIN) { /** Lock was granted... */
	        fprintf(stderr, "Guardian is already running\n");
			exit(EXIT_SUCCESS);
    	} else {
			CHECK(ret != -1);
		}
	} 
}

/**
 *	Remove lock file
 */
void clean(){
	struct flock fl;
	
	fl.l_type 	= F_UNLCK;
	fl.l_whence = SEEK_SET;
	fl.l_start 	= 0;
	fl.l_len 	= 1;
	
	CHECK(fcntl(fdlock, F_SETLK, &fl) != -1);
	CHECK(close(fdlock) != -1);
	CHECK(unlink(LOCK_FILE) != -1);
}

/**
 *	Block all signals without the commanding ones and set up handler
 *		SIGINIT: kill process & child
 *		SIGCONT: respawn child
 */
void set_up_signals(){
	sigset_t set;	
	
	CHECK(sigfillset(&set)	!= -1);
	CHECK(sigdelset (&set, SIGINT)	!= -1); 
	CHECK(sigdelset (&set, SIGCONT) != -1);
	CHECK(sigprocmask(SIG_BLOCK, &set, NULL) != -1);
	
	/** set up handler */
	struct sigaction sa;
	sigset_t mask;

	memset(&sa, 0, sizeof(sa));
	memset(&mask, 0, sizeof(mask));
	sa.sa_mask = mask;
	sa.sa_handler = sig_handler;
	CHECK(sigaction(SIGINT,  &sa, NULL) != -1);
	CHECK(sigaction(SIGCONT, &sa, NULL) != -1);
}

/**
 *	Add current directory to PATH
 */
void set_up_path(){
	char *crt_dir = ":.";
	char *old_path, *new_path;
	
	old_path = getenv("PATH");
	
	if (!old_path){
		new_path = (char*) calloc (strlen(crt_dir) + 1, sizeof(char));
	} else {
		new_path = (char*) calloc (strlen(old_path) + strlen(crt_dir) + 1, sizeof(char));
	}
	strcat(new_path, old_path);
	strcat(new_path, crt_dir);
	CHECK(setenv("PATH", new_path, 1) != -1);
	
	free(new_path);
}

int main(int argc, char **argv){
	
	/** skip first parameter */
	argc--; argv++;
	
	/** sanity check */
	if (argv[0] == NULL){
		fprintf(stderr, "Usage: nume_program arg1 arg2 ...\n");
		exit(EXIT_FAILURE);
	}
	
	CHECK(daemon(1, 1) != -1);

	check_singularity();
	set_up_signals();
	set_up_path();

	int status;
	do{
		switch (pid = fork())
		{
			case -1: /** fork failed */
			{
				fprintf(stderr, "Fork failed\n");
				exit(EXIT_FAILURE);
			}
	
			case 0:	/** child executes here */ 
			{
					/** redirect stdin, stdout, stderr */
					set_redirect(argv[0]);
					
					execvp( argv[0] , (char * const *)argv );
				
					/** inform parent about our problem */
					exit(errno);
			}
			
			default: /** parent executes here */
			{
				waitpid(pid, &status, 0);
				
				/** exit if no child executable exists */
				if (WEXITSTATUS(status) && (WEXITSTATUS(status) == ENOENT)) {
					fprintf(stdout,"The child program does not exist!\n");
					return EXIT_SUCCESS;
				}
			}
		}
	}while(restart);
	
	clean();
	return EXIT_SUCCESS;
}