/**
 * SO Homework #0 Linux, Guardian Process
 *
 * Copyright (C) 2010, Daniel Baluta <daniel.baluta@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>

#ifdef DEBUG
#define dprintf printf
#else
#define dprintf(...)
#endif

#define GUARDIAN_VERSION "1.0.0"

int go_out = 0;
int zombie = 0;

pid_t pid = (pid_t) - 1;

/**
 * decorate_path - decorate PATH 
 *
 * Appends current directory at the end of PATH
 * NOTE: keep your eyes wide open since this might be dangerous 
 * http://www.faqs.org/faqs/unix-faq/faq/part2/section-13.html
 */
void decorate_path()
{
	const char *crt_dir = ":.";
	char *old_path, *new_path;

	old_path = getenv("PATH");
	if (!old_path) {
		perror("getenv");
		exit(EXIT_FAILURE);
	}

	new_path = calloc(strlen(old_path) + strlen(crt_dir) + 1, sizeof(char));
	if (!new_path) {
		perror("malloc");
		exit(EXIT_FAILURE);
	}
	strncpy(new_path, old_path, strlen(old_path));
	strncat(new_path, crt_dir, strlen(crt_dir));

	setenv("PATH", new_path, 1);

	free(new_path);
}

/**
 * try_lock_guardian - try lock guardian 
 * 
 * Check if another guardian owns the lock (using an exclusive open)
 * Immediately exit if there's one instance of guardian running
 */
void try_lock_guardian()
{
	int fd;

	fd = open("/tmp/.guardian.lock", O_CREAT | O_EXCL, 0644);
	if (fd < 0) {
		fprintf(stderr, "Guardian is already running\n");
		exit(EXIT_FAILURE);
	}
}

/**
 * unlock_guardian - unlock guardian 
 * 
 * Remove lock file
 */
void unlock_guardian()
{
	unlink("/tmp/.guardian.lock");
}

/** 
 * redirect_io - redirects child standard I/O files 
 * @file: file prefix for new stdout/stderr files
 * 
 * Redirects output/stderr to @file.stdout/@file.stderr
 * Redirects input from /dev/null
 */
void redirect_io(const char *file) {
	char fname[32];
	int fd_in, fd_out, fd_err;
	
	fd_in = open("/dev/null", O_RDONLY);
	if(fd_in < 0) {
		perror("open:");
		exit(EXIT_FAILURE);
	}

	snprintf(fname, 32, "%s.stdout", file);
	fd_out = open(fname, O_CREAT | O_RDWR | O_APPEND, 0644);
	if(fd_out < 0) {
		perror("open:");
		exit(EXIT_FAILURE);
	}
	
	snprintf(fname, 32, "%s.stderr", file);
	fd_err = open(fname, O_CREAT | O_RDWR | O_APPEND, 0644);
	if(fd_err < 0) {
		perror("open:");
		exit(EXIT_FAILURE);
	}
	dup2(fd_in, STDIN_FILENO);
	dup2(fd_out, STDOUT_FILENO);
	dup2(fd_err, STDERR_FILENO);
}
/**
 * guardian_loop - guardian main loop
 * @file: program name
 * @argv: program arguments
 * 
 * starts/guards @file program. Guardian is controlled via signals 
 * 	* SIGINT  - stops @file program
 * 	* SIGCONT - restarts @file program
*/
void guardian_loop(const char *file, char *argv[])
{
	int status, ret;

	do {
		pid = fork();
		if (pid < 0)
			exit(EXIT_FAILURE);
		if (pid == 0) {
			redirect_io(file);
			execvp(file, argv);

			/* let parent now about this */
			exit(errno);
		}
		do {
			ret = waitpid(pid, &status, 0);
			if (ret < 0) {
				/* child doesn't yet RIP :( */
				if (errno == EINTR)
					zombie = 1;
				else
					break;
			} else {
				if (WIFEXITED(status) && 
				   (ENOENT == WEXITSTATUS(status))) {
					fprintf(stderr, "The child program does not exist!\n");
					go_out = 1;
					break;
				}
				zombie = (!WIFEXITED(status)
					  && !WIFSIGNALED(status));
			}
		} while (zombie);
	} while (!go_out);
}

/**
 * guardian_handler - guardian signal handler
 * @sig_num: received signal number 
 * The following signals are monitored:
 *	- SIGINT, kills child program and marks guardian
 *		as finished.
 *	- SICONT, kills child program
 * Since all other signals are ignored, receiving other signal 
 * than the one mentioned above will result in a warning
 */
static void guardian_handler(int sig_num)
{
	if (pid == (pid_t) - 1)
		return;

	switch (sig_num) {
	case SIGINT:
		dprintf("Stop child with pid %d\n", pid);
		go_out = 1;
		kill(pid, SIGKILL);
		break;
	case SIGCONT:
		dprintf("Restart child with pid %d\n", pid);
		kill(pid, SIGKILL);
		break;
	default:
		printf("WARN: didn't we ignored this signal? (%d)\n", sig_num);
	}
}

/**
 * setup_signals - setup signals
 *
 * Set all signals as ignored by default
 * Set signal handler for guardian control 
 * signals SIGINT and SIGCONT
 */
void setup_signals()
{
	struct sigaction action;
	sigset_t set;
	
	/* block all signals */
	sigfillset(&set);
	sigprocmask(SIG_BLOCK, &set, NULL);

	/* setup handler for SIGINT  ~ stop command */
	memset(&action, 0, sizeof(struct sigaction));
	sigemptyset(&set);
	sigaddset(&set, SIGINT);
	sigprocmask(SIG_UNBLOCK, &set, NULL);

	action.sa_mask = set;
	action.sa_handler = guardian_handler;
	sigaction(SIGINT, &action, NULL);

	/* setup handler for SIGCONT ~ restart command */
	memset(&action, 0, sizeof(struct sigaction));
	sigemptyset(&set);
	sigaddset(&set, SIGCONT);
	sigprocmask(SIG_UNBLOCK, &set, NULL);

	action.sa_mask = set;
	action.sa_handler = guardian_handler;
	sigaction(SIGCONT, &action, NULL);
}

int main(int argc, char *argv[])
{

	dprintf("guardian: version %s\n", GUARDIAN_VERSION);

	if (argc < 2) {
		fprintf(stderr, "Usage: ./guardian arg0 arg1 ..\n");
		return EXIT_FAILURE;
	}

	try_lock_guardian();
	
	/* release the Kraken! */
	daemon(1, 1);
	
	decorate_path();
	setup_signals();
	guardian_loop(argv[1], argv + 1);

	unlock_guardian();
	return 0;
}
