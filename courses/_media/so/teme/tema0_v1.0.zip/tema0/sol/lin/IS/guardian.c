/**
* SO Homework #0 Linux, Guardian Process
*
* @author Irina Stănescu
* Copyright (C) 2010, SO team (http://elf.cs.pub.ro/so/)
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>

/* Macro definitions used to avoid magic numbers */
#define MIN_ARGS 2
#define MAX_LEN 100
#define EXIT_CODE 123

#define LOCK_FILENAME "/tmp/guardian.lock"
#define STDOUT_SUFFIX ".stdout"
#define STDERR_SUFFIX ".stderr"

int restart_child = 1;
int lock_fd = -1;
pid_t child_pid = 0;

void check_lock() {

	/* Get a file descriptor for the lock file */
	struct flock lock_fl = {F_WRLCK, SEEK_SET, 1, 1, 0};

	lock_fd = open(LOCK_FILENAME, O_CREAT | O_RDWR, 0666);
	if (lock_fd == -1) {
		perror("open");
		exit(EXIT_FAILURE);
	}

	/* Check if the lock is held by another guardian instance */
	if (fcntl(lock_fd, F_SETLK, &lock_fl) == -1) {
		fprintf(stderr, "Guardian is already running\n");
		exit(EXIT_FAILURE);
	}
}


void free_lock() {

	close(lock_fd);
	if (unlink(LOCK_FILENAME) == -1) {
		perror("unlink");
		exit(EXIT_FAILURE);
	}
}


void modify_env_var(char *var, char *dir_path) {

	char *path = getenv(var), *new_path;

	/* If var is not used, set directly */
	if (!path) {
		if (setenv(var, dir_path, 1) == -1) {
			perror("setenv");
			exit(EXIT_FAILURE);
		}
		return;
	}

	/* Allocate memory for the string representing the new 
	   environment variable */
	new_path = (char*) calloc (strlen(path) + strlen(dir_path) + 1, 
					sizeof(char));

	if (!new_path) {
		perror("calloc");
		exit(EXIT_FAILURE);
	}

	/* Add dir_path to the old path */
	snprintf(new_path, MAX_LEN, "%s:%s", path, dir_path);

	/* Set the new value for the environment variable */
	if (setenv(var, new_path, 1) == -1) {
		perror("setenv");
		exit(EXIT_FAILURE);
	}

	free(new_path);
}


/* Signal handler for SIGINT and SIGCONT */
void signal_handler(int signal) {
	switch(signal) {
		/* SIGINT kills both guardian and child process */
		case SIGINT:
			restart_child = 0;
		/* SIGCONT restarts the child process only */
		case SIGCONT:
			/* If there is a child process started, kill it */
			if (child_pid)
				kill(child_pid, SIGKILL);
			break;
	}
}


/* Install signal handlers for signals */
void setup_signals() {

	/* Block all signals except SIGINT and SIGCONT */
	if (signal(SIGINT, signal_handler) == SIG_ERR ||
		signal(SIGCONT, signal_handler) == SIG_ERR ||
		signal(SIGSEGV, SIG_IGN) == SIG_ERR) {
			perror("signal");
			exit(EXIT_FAILURE);
	}
}


void redirect(char *file, int redirect_fd) {
	int fd;

	if (fd == STDIN_FILENO) {
    	fd = open(file, O_RDONLY);
	} else {
		fd = open(file, O_WRONLY | O_APPEND | O_CREAT, 0666);
 	}

	if (fd == -1) {
        perror("open");
        exit(EXIT_FAILURE);
    }

    if (dup2(fd, redirect_fd) == -1) {
        perror("dup2");
        exit(EXIT_FAILURE);
    }

    if (close(fd)) {
        perror("close");
        exit(EXIT_FAILURE);
    }
}


void redirect_stdio(char *cmd) {
	char *child_stdout, *child_stderr;

	/* Prepare file names for redirections */
	child_stdout = (char*) calloc (strlen(cmd) + strlen(STDOUT_SUFFIX) + 1, 
						sizeof(char));

	if (!child_stdout) {
        perror("calloc");
        exit(EXIT_FAILURE);
	}

	child_stderr = (char*) calloc (strlen(cmd) + strlen(STDERR_SUFFIX) + 1, 
						sizeof(char));

	if (!child_stderr) {
        perror("calloc");
		free(child_stdout);
        exit(EXIT_FAILURE);
	}

	snprintf(child_stdout, MAX_LEN, "%s%s", cmd, STDOUT_SUFFIX);
	snprintf(child_stderr, MAX_LEN, "%s%s", cmd, STDERR_SUFFIX);

  	/* Redirect stdin to /dev/null */
	redirect("/dev/null", STDIN_FILENO);
	/* Redirect stdout to program_name.stdout */
	redirect(child_stdout, STDOUT_FILENO);
	/* Redirect stderr to program_name.stderr */
	redirect(child_stderr, STDERR_FILENO);

	free(child_stdout);
	free(child_stderr);
}


void run(char **argv) {
	int status;

	while (restart_child) {
		switch (child_pid = fork()) {
			case -1:
				perror("fork");
				exit(EXIT_FAILURE);
			case 0:
				redirect_stdio(argv[0]);

				/* Execute command */
				execvp(argv[0], argv);

				/* If the execution got here, execvp failed */
				exit(EXIT_CODE);

			default:
				waitpid(child_pid, &status, 0);

				if (WEXITSTATUS(status) == EXIT_CODE) {
		            fprintf(stderr, "The child program does not exist!\n");
        		    return;
        		}
		}
	}
}


int main(int argc, char *argv[]) {

	/* Verify proper usage for the guardian */
	if (argc < MIN_ARGS) {
		fprintf(stderr, "Usage: ./guardian nume_program arg1 arg2 ...\n");
		return EXIT_FAILURE;
	}

	/* Daemonize first */
	if (daemon(1,1) == -1) {
		return EXIT_FAILURE;
	}

	/* Check if this is the only instance of the guardian */
	check_lock();

	/* Add current dir to $PATH */
	modify_env_var("PATH",".");

	/* Add handler for SIGINT, SIGCONT */
	setup_signals();

	run(argv + 1);

	/* Free lock so that other guardians can be executed */
	free_lock();

	return EXIT_SUCCESS;
}
