# author: sana

import subprocess
import time
import win32api
import win32console
import win32process
import random
import os
import shutil
import filecmp

import signal

# CTRL + BREAK e tratat de acelasi handler ca si CTRL + C
#   => arunca o exceptie pe care o prind
signal.signal(signal.SIGBREAK, signal.default_int_handler)

class GuardianProcess:
	'''Guardian process wrapped with events sending capabilities'''
	
	def __init__(self, cmd):
		si = win32process.STARTUPINFO()
		
		info = win32process.CreateProcess(
						None, # AppName
						cmd, # Command line
						None, # Process Security
						None, # ThreadSecurity
						0, # Inherit Handles?
						0, # Creation flags
						None, # New environment
						None, # Current directory
						si) # startup info.

		# Recall info is a tuple of (hProcess, hThread, processId, threadId)
		self.handle, self.pid = info[0], info[2]
	
	def send_event(self, eventType):
		try:
			win32api.GenerateConsoleCtrlEvent(eventType, 0)
			time.sleep(0.3)
		except:
			pass
		
	def send_CTRL_BREAK(self):
		print 'Trimit CTRL + BREAK'
		self.send_event(win32console.CTRL_BREAK_EVENT);
		
	def send_CTRL_C(self):
		print 'Trimit CTRL + C'
		self.send_event(win32console.CTRL_C_EVENT);

	def wait(self):
		self.send_event(win32console.CTRL_C_EVENT);

def my_check(i):
	res = 'child' + str(i) + '.std'
	ref = 'windows_ref/' + res

	#print 'OUT[' + str(i) + ']' + str(filecmp.cmp(res + 'out', ref + 'out'))
	#print 'ERR[' + str(i) + ']' + str(filecmp.cmp(res + 'err', ref + 'err'))
	return filecmp.cmp(res + 'out', ref + 'out') == True and filecmp.cmp(res + 'err', ref + 'err') == True

def test0():
	print 'Test 0'
	print '  Verific daca o singura instanta de guardian ruleaza la un moment dat'

	try:
		os.unlink(GUARDIAN_ALREADY_RUNNING)
	except:
		pass

	time.sleep(0.1)
	x=random.randint(0, 10000)
	test_dir = '__test' + str(x)
	os.mkdir(test_dir)

	os.chdir(test_dir)
	# Primul guardian
	proc1 = GuardianProcess('../guardian.exe pwd')
	os.chdir('..')

	time.sleep(0.5)
	# Al doilea guardian
	proc2 = GuardianProcess('guardian.exe ls');

	time.sleep(0.2)
	proc1.wait()
	time.sleep(0.2)
	proc2.wait()

	time.sleep(1)

	result = filecmp.cmp(GUARDIAN_ALREADY_RUNNING, 'windows_ref/' + GUARDIAN_ALREADY_RUNNING)
	shutil.rmtree(test_dir)
	time.sleep(0.1)
	return result
	
def test1():
	print 'Test 1'

	try:
		os.unlink('child1.stdout')
		os.unlink('child1.stderr')
	except:
		pass

	time.sleep(0.1)
	proc1 = GuardianProcess('guardian.exe child1 1 2 3 4 5')
	time.sleep(1)
	proc1.wait()
	time.sleep(1)
	return my_check(1)
	
def test(i):
	print 'Test ' + str(i)
	
	res = 'child' + str(i) + '.std'
	try:
		os.unlink(res + 'out')
		os.unlink(res + 'err')
	except:
		pass

	time.sleep(0.1)
	proc1 = GuardianProcess('guardian.exe child' + str(i))
	time.sleep(1)
	time.sleep(1)
	proc1.wait()
	return my_check(i)

def test4():
	print 'Test 4'
	try:
		os.unlink("child4.stderr")
		os.unlink("child4.stdout")
	except:
		pass
		
	proc1 = GuardianProcess('guardian.exe child4')
	time.sleep(1)

	proc1.send_CTRL_BREAK()
	time.sleep(1)
	proc1.send_CTRL_BREAK()
	time.sleep(1)
	proc1.send_CTRL_BREAK()
	time.sleep(1)
	proc1.send_CTRL_C()
	time.sleep(0.5)
	proc1.wait()

	return my_check(4)
	
def test5():
	print 'Test 5'
	try:
		os.unlink("child5.stderr")
		os.unlink("child5.stdout")
	except:
		pass

	proc1 = GuardianProcess('guardian.exe child5')
	time.sleep(1)
	proc1.wait()

	return filecmp.cmp(CHILD_DOES_NOT_EXIT, 'windows_ref/' + CHILD_DOES_NOT_EXIT)

def compute_result(x):
	global passed
	global failed
	
	if x:
		passed = passed + 1
	else:
		failed = failed + 1

	
passed=0
failed=0
		
GUARDIAN='./guardian.exe'
GUARDIAN_ALREADY_RUNNING='__guardian_already_running'
CHILD_DOES_NOT_EXIT='__child_does_not_exist'

os.chdir('src')
os.system('nmake /F Makefile.Windows clean')
os.system('nmake /F Makefile.Windows')
os.chdir('..')

for i in range(1, 5):
	os.system('cp ./src/child' + str(i) + ' child' + str(i) + '.exe')

# START
# ========================================================================== #
results = [test0(), test1(), test(2), test(3), test4(), test5()]
map(compute_result, results)
# ========================================================================== #
print 'Statistics'
print '    passed = ' + str(passed)
print '    failed = ' + str(failed)
# ========================================================================== #
# END
