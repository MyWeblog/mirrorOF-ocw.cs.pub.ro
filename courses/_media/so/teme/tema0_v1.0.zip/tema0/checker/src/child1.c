/*!
  Proces copil foarte simplu

 @author Dascalu Laurentiu

 Copyright (C) 2010 SO (http://cs.pub.ro/~so/)

 This program is free software; you can redistribute it and
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "include/child_util.h"

#ifdef _WIN32
#define HELLO_MSG     "Salut, sunt child1!\r\n"
#else
#define HELLO_MSG     "Salut, sunt child1!\n"
#endif

int main(int argc, char **argv)
{
	int i;

#ifdef _WIN32
	DWORD aux;
	HANDLE outHandle;
	HANDLE errHandle;
	
	outHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	errHandle = GetStdHandle(STD_ERROR_HANDLE);

	// Windows-ul pune el niste \r-uri aiurea si nu reuseste diff-ul intre fisiere
	WriteFile(outHandle, "[STDOUT] " HELLO_MSG, strlen("[STDOUT] " HELLO_MSG), &aux, NULL);
	WriteFile(errHandle, "[STDERR] " HELLO_MSG, strlen("[STDERR] " HELLO_MSG), &aux, NULL);	
#else
	PRINT_STDOUT("[STDOUT] " HELLO_MSG);
	PRINT_STDERR("[STDERR] " HELLO_MSG);
#endif

	PRINT_STDOUT("Numar de parametri %d\n", argc);
	for (i = 0 ; i < argc ; i++)
		PRINT_STDOUT("\tParam %d = %s\n", i, argv[i]);

	FINAL_WORK();

	return 0;
}
