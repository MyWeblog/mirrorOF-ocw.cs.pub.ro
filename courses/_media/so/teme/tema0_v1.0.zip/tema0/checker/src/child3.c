/*!
  Fata de child2 acest program verifica daca poate citi input de la STDIN.
 In cazul in care reuseste, atunci esueaza cu un mesaj.

 @author Dascalu Laurentiu

 Copyright (C) 2010 SO (http://cs.pub.ro/~so/)

 This program is free software; you can redistribute it and
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "include/child_util.h"

#define NTHREADS                 4
#define MAX_VALUE                9

#ifdef _WIN32
#define SEMAPHORE_NAME    "my_sem"
#else
#define SEMAPHORE_NAME    "/my_sem"
#endif

static int value;

#ifdef _WIN32

static HANDLE sem;
static HANDLE *threads;
HANDLE hFile, hMapFile;
CRITICAL_SECTION hCritSect;
char *mem;

static HANDLE open_file(DWORD flag)
{
	HANDLE fd;

	fd = CreateFile(SEMAPHORE_NAME,
			FILE_READ_DATA | FILE_WRITE_DATA,
			FILE_SHARE_READ,
			NULL,
			flag,
			FILE_ATTRIBUTE_NORMAL,
			NULL);

	return fd;
}

static void destroy_file(HANDLE hFile)
{
	CHECK(CloseHandle(hFile), !=, 0, "CloseHandle()", -1);
	CHECK(DeleteFile(SEMAPHORE_NAME), !=, 0, "DeleteFile()", -1);
}

LPVOID map(HANDLE fd, DWORD size, HANDLE *hMapFile) {
	HANDLE mo;
	LPVOID mem;

	mo = CreateFileMapping(
			fd,
			NULL,
			PAGE_READWRITE,
			0,
			size,
			NULL);
	CHECK(mo, !=, NULL, "CreateFileMapping()", -1);
	*hMapFile = mo;

	mem = MapViewOfFile(
			mo,
			FILE_MAP_ALL_ACCESS,
			0,
			0,
			0);
	CHECK(mem, !=, NULL, "MapViewOfFile()", -1);

	return mem;
}

void my_at_exit(void)
{
	if (mem != NULL)
		CHECK(UnmapViewOfFile(mem), !=, 0, "UnmapViewOfFile()", -1);

	if (hMapFile != INVALID_HANDLE_VALUE)
		CHECK(CloseHandle(hMapFile), !=, 0, "CloseHandle()", -1);

	DeleteCriticalSection(&hCritSect);
	PRINT_STDERR("[PANIC] Somebody called exit()\n");
}

static void init()
{
	DWORD aux = -1;
	char x = '1';
	char *err_msg = "Child read data from STDIN\n";
	HANDLE hStdin = GetStdHandle(STD_INPUT_HANDLE);
	HANDLE hStderr = GetStdHandle(STD_ERROR_HANDLE);

	ReadFile(hStdin, &x, sizeof(char), &aux, NULL);
	if (aux > 0)
	{
		WriteFile(hStderr, err_msg, 28, &aux, NULL);
		FINAL_WORK();
		exit(-1);
	}
	CHECK(atexit(my_at_exit), ==, 0, "atexit()", -1);
	InitializeCriticalSection(&hCritSect);
}

static HANDLE *create_threads(int nthreads, LPTHREAD_START_ROUTINE thread_routine)
{
	HANDLE *hThreads;
	DWORD idThread;
	int i;

	hThreads = (HANDLE *) malloc(nthreads * sizeof(HANDLE));

	for (i = 0 ; i < nthreads ; i++)
	{
		hThreads[i] = CreateThread(NULL,
						0,
						(LPTHREAD_START_ROUTINE) thread_routine,
						(LPVOID) i,
						0,
						&idThread);
		CHECK(hThreads[i], !=, NULL, "CreateTHread()", -1);
	}

	return hThreads;
}

static void destroy_threads(HANDLE *hThreads, int nthreads)
{
	int i;
	for (i = 0 ; i < nthreads ;  i++)
		CHECK(WaitForSingleObject(hThreads[i], INFINITE), ==, 0, "WaitForSingleObject()", -1);
	free(hThreads);
}

static HANDLE create_semaphore()
{
	hFile = open_file(OPEN_EXISTING);
	if (INVALID_HANDLE_VALUE == hFile)
	{
		// Creez fisierul daca nu exista
		hFile = open_file(CREATE_ALWAYS);

		// Il mapez in memorie si initializez celula de memorie
		mem = map(hFile, 1, &hMapFile);
		mem[0] = 0;
	}
	else
		// Daca fisierul exista, atunci mapez fisierul in memorie
		mem = map(hFile, 1, &hMapFile);

	return NULL;
}

static int read_semaphore_value(HANDLE sem)
{
	return mem[0];
}

void destroy_semaphore(HANDLE sem)
{
	CHECK(UnmapViewOfFile(mem), !=, 0, "UnmapViewOfFile()", -1);
	mem = NULL;
	CHECK(CloseHandle(hMapFile), !=, 0, "CloseHandle()", -1);
	hMapFile = INVALID_HANDLE_VALUE;
	destroy_file(hFile);
}

static volatile int started_threads;

static DWORD WINAPI thread_routine(LPVOID arg)
{
	int id = (int) arg;
	int value = mem[0];

	EnterCriticalSection(&hCritSect);
	if (!(id == 0 && value < 2 * (NTHREADS - 1)))
		mem[0]++;
	started_threads++;
	LeaveCriticalSection(&hCritSect);

	// Putin spinlock pentru ca toate thread-urile sa fi trecut
	// de sectiunea critica; in Linux se implementeaza mai usor
	// cu o bariera de sincronizare a thread-urilor
	while (started_threads < NTHREADS)
		;

	if (id == 0 && value < 2 * (NTHREADS - 1))
		exit(0);

	return 0;
}

#else

#include <semaphore.h>
#include <fcntl.h>
#include <pthread.h>

static sem_t *sem;
static pthread_t *threads;
static pthread_barrier_t barrier;

static void my_at_exit();
static void init();
static sem_t *create_semaphore();
static int read_semaphore_value(sem_t *sem);
static void close_semaphore(sem_t *sem);
static void destroy_semaphore(sem_t *sem);

static pthread_t *create_threads(int nthreads, void *(*start_routine)(void *));
static void destroy_threads(pthread_t *threads, int nthreads);
static void *thread_routine(void *arg);

void my_at_exit()
{
	PRINT_STDERR("[PANIC] Somebody called exit()\n");
	CHECK(pthread_barrier_destroy(&barrier), ==, 0, "pthread_barrier_destroy()", -1);
	close_semaphore(sem);
}

void init()
{
	char x;
	char *err_msg = "Child read data from STDIN\n";

	if (read(STDIN_FILENO, &x, sizeof(char)) > 0)
	{
		write(STDERR_FILENO, err_msg, 28);
		FINAL_WORK();
		exit(-1);
	}
	CHECK(atexit(my_at_exit), ==, 0, "atexit()", -1);
	CHECK(pthread_barrier_init(&barrier, NULL, NTHREADS), ==, 0, "pthread_barrier_init()", -1);
}

sem_t *create_semaphore()
{
	sem_t * sem;

	// Daca semaforul exista, atunci il refolosesc
	sem = sem_open(SEMAPHORE_NAME, O_RDWR);
	if (sem != SEM_FAILED)
		return sem;

	// Daca nu, deschid unul nou
	sem = sem_open(SEMAPHORE_NAME, O_CREAT | O_RDWR, 0644, 0);
	CHECK(sem, !=, SEM_FAILED, "sem_open()", -1);
	return sem;
}

int read_semaphore_value(sem_t *sem)
{
	int value;
	CHECK(sem_getvalue(sem, &value), ==, 0, "sem_get_value()", -1);
	return value;
}

void close_semaphore(sem_t *sem)
{
	CHECK(sem_close(sem), >=, 0, "sem_close()", -1);
}

void destroy_semaphore(sem_t *sem)
{
	CHECK(sem_unlink(SEMAPHORE_NAME), >=, 0, "sem_unlink()", -1);
}

pthread_t *create_threads(int nthreads, void *(*start_routine)(void *))
{
	int i;
	pthread_t *threads;

	threads = (pthread_t *) malloc(nthreads * sizeof(pthread_t));
	CHECK(threads, !=, NULL, "malloc()", -1);

	for (i = 0; i < nthreads; i++)
	CHECK(pthread_create(&threads[i], NULL, start_routine, (void *) i),
			==, 0, "pthread_create()", -1);

	return threads;
}

void destroy_threads(pthread_t *threads, int nthreads)
{
	int i;
	void *ret_value;

	for (i = 0; i < nthreads; i++)
	CHECK(pthread_join(threads[i], &ret_value), ==, 0, "pthread_join()", -1);
	free(threads);
}

static void *thread_routine(void *arg)
{
	int id;
	int value;
	int result;

	id = (int) arg;
	value = read_semaphore_value(sem);

	if (!(id == 0 && value < 2 * (NTHREADS - 1)))
		CHECK(sem_post(sem), ==, 0, "sem_post()", -1);

	result = pthread_barrier_wait(&barrier);
	if (result != 0 && result != PTHREAD_BARRIER_SERIAL_THREAD)
		perror("pthread_barrier_wait()");

	if (id == 0 && value < 2 * (NTHREADS - 1))
		exit(0);

	pthread_exit(NULL);
}

#endif

int main()
{
	/*
	 * Thread-ul master creaza un semafor
	 * si NTHREAD-uri workeri.
	 *
	 * Fiecare worker incrementeaza semaforul,
	 * dar unul din ei apeleaza exit(0).
	 *
	 * Programul intra in bucla infinita doar
	 * atunci cand semaforul are o valoare mai
	 * mare decat numarul de thread-uri.
	 *
	 * Din cauza ca un thread apeleaza exit(0),
	 * semaforul va ajunge la pragul minim
	 * la a treia rulare
	 */
	init();
	sem = create_semaphore();
	threads = create_threads(NTHREADS, thread_routine);
	destroy_threads(threads, NTHREADS);
	value = read_semaphore_value(sem);

	PRINT_STDOUT("Value = %d\n", value);
	if (value >= MAX_VALUE)
	{
		destroy_semaphore(sem);
		FINAL_WORK();
	}

	return 0;
}
