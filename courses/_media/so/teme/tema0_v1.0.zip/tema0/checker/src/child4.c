/*!
  Copil simplu folosit pentru testarea mecanismului de trimitere a
 evenimentelor(Windows) sau semnalelor(GNU/Linux)

 @author Dascalu Laurentiu

 Copyright (C) 2010 SO (http://cs.pub.ro/~so/)

 This program is free software; you can redistribute it and
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "include/child_util.h"

#define HELLO_MSG     "Child4 started execution!\n"

int main()
{
	/*
	 * In acest test, se trimit semnale din shell catre guardian.
	 * - SIGSEGV se va ignora
	 * - SIGCONT va restarta copilul guardianului
	 * - SIGINT va inchide copilul si, apoi, va inchide guardianul
	 */

	PRINT_STDOUT(HELLO_MSG);

	FINAL_WORK();

	return 0;
}
