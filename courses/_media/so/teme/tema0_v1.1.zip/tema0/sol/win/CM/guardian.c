/**
 * SO Homework #0 Linux, Guardian Process
 *
 * @author Catalin Moraru
 * Copyright (C) 2010, SO team (http://cs.pub.ro/~so/)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <windows.h>
#include <stdlib.h>
#include <stdio.h>

#define	MAX_CMD_SIZE			128
#define MAX_ARGS			128
#define	MAX				128

#define CHILD_STDOUT_EXT		".stdout"
#define CHILD_STDERR_EXT		".stderr"

#define RUNNING                 	"Guardian is already running\n"
#define NOT_EXIST			"The child program does not exist!\n"

#define LOCK_FILE			"C:\\LockFile"

#define CALL_FIRST 			1 

#define CHECK(x) \
	do { \
		if (!(x)) { \
			printf("[%s]:%s:%d: ", __FILE__, \
			__FUNCTION__, __LINE__); \
			clean();\
			ErrorExit(#x); \
			ExitProcess(EXIT_FAILURE); \
		} \
	} while(0)


/** control variable for the main loop - needed in the signal handler */
volatile static int restart = 1;

/** Usefull process info - needed also in the signal handler */
STARTUPINFO si;
PROCESS_INFORMATION pi;

/** Handle for the LOCK_FILE */
HANDLE hLock;

/** Process heap handle */
HANDLE hProcessHeap;

/*
 *	Error printing function
 *	@in: lpCond - string holding the assertion
 */

void ErrorExit(LPTSTR lpCond) { 

    /** Retrieve the system error message for the last-error code */
    LPVOID lpMsgBuf;

    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        GetLastError(),
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR) &lpMsgBuf,
        0, NULL );

    /** Display the error message and exit the process */
	fprintf_s(stderr, "[%s]\n%s\n", lpCond, lpMsgBuf);
	
    LocalFree(lpMsgBuf);
}


/* 
 *	Dispose of Lock
 */
void clean(){
	CHECK(CloseHandle(hLock)	!= FALSE);
	CHECK(DeleteFile(LOCK_FILE)	!= FALSE);
}

/*
 *	Error reporting function - prints some errors to file:
 *		- NOT_EXIST
 *		- RUNNING
 *	
 */
static void report_error(LPSTR lpFileName,  LPSTR lpInfo)
{
	DWORD dwWritten = -1;
	HANDLE hErr;

	hErr = CreateFile(
		lpFileName,
		FILE_WRITE_DATA,
		FILE_SHARE_WRITE,
		NULL,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL);

	CHECK(hErr != FALSE);
	CHECK(WriteFile(hErr, lpInfo, strlen(lpInfo), &dwWritten, NULL) != FALSE);
	CHECK(CloseHandle(hErr) != FALSE);
}

/*
 *	Closes redirected file handles of the child
 * 	 @in: si - structure that hold the handles
 */
void CloseFileHandles(STARTUPINFO *si){
		CHECK( CloseHandle( (*si).hStdOutput )	!= FALSE );
		CHECK( CloseHandle( (*si).hStdError )	!= FALSE );
}

/*
 *	Clear process
 */
void CloseProcess(LPPROCESS_INFORMATION pi)
{
    CHECK(CloseHandle(pi->hThread) != FALSE);
    CHECK(CloseHandle(pi->hProcess)!= FALSE);
}

/*
 *	Set child redirect
 *	@in: lpName - to compose the redirect files
 *			stdout-> @name.stdout
 *			stderr-> @name.stderr
 *	@out: si - structure to be past to CreateProcess
 *			 - contains the new file handles
 */
void set_redirect(LPSTR lpName, STARTUPINFO *si){
	HANDLE hFile;
	SECURITY_ATTRIBUTES sa;
	
	LPSTR lpChildStdout;
	LPSTR lpChildStderr;

	
	ZeroMemory(&sa, sizeof(sa));
	sa.nLength = sizeof(sa);
	sa.bInheritHandle = TRUE;
	
	ZeroMemory(si, sizeof(*si));
	(*si).cb		= sizeof(STARTUPINFO);
	(*si).dwFlags	= STARTF_USESTDHANDLES;
	

	/** Redirect STDOUT */

	lpChildStdout = HeapAlloc(hProcessHeap, HEAP_ZERO_MEMORY, MAX_CMD_SIZE);
	CHECK(lpChildStdout != NULL);

	sprintf_s(lpChildStdout, MAX_CMD_SIZE, "%s%s", lpName, CHILD_STDOUT_EXT);
	
	hFile = CreateFile(
        	lpChildStdout,
	        FILE_APPEND_DATA,
	        FILE_SHARE_READ | FILE_SHARE_WRITE,		
        	&sa,					
		OPEN_ALWAYS,			
        	FILE_ATTRIBUTE_NORMAL,
	        NULL);		
	CHECK(hFile != INVALID_HANDLE_VALUE);	 

	(*si).hStdOutput = hFile;
	
	/** Redirect STDERR */

	lpChildStderr = HeapAlloc(hProcessHeap, HEAP_ZERO_MEMORY, MAX_CMD_SIZE);
	CHECK(lpChildStdout != NULL);

	sprintf_s(lpChildStderr, MAX_CMD_SIZE, "%s%s", lpName, CHILD_STDERR_EXT);

	hFile = CreateFile(
        	lpChildStderr,
	        FILE_APPEND_DATA,			
        	FILE_SHARE_READ | FILE_SHARE_WRITE,		
	        &sa,					
        	OPEN_ALWAYS,			
	        FILE_ATTRIBUTE_NORMAL,	
        	NULL);		
	CHECK(hFile != INVALID_HANDLE_VALUE);	 

	(*si).hStdError = hFile;

	CHECK(HeapFree(hProcessHeap, 0, lpChildStdout) != FALSE);
	CHECK(HeapFree(hProcessHeap, 0, lpChildStderr) != FALSE);
}

/*
 *  Console  handler - treats CTRL+C and CTRL+BREAK events
 *		- CTRL+C	 - stops  child process 
 *		- CTRL+BREAK - retart child process
 *  @in: dwEventType
 */
static BOOL CtrlHandler(DWORD dwEventType)
{
    switch (dwEventType) {
		case CTRL_C_EVENT:
			TerminateProcess(pi.hProcess, 0);
			restart = 0;
			break;
		case CTRL_BREAK_EVENT:
			TerminateProcess(pi.hProcess, 0);
			break;
		default:
			/* ignore rest */
			break;
    }
    return TRUE;
}


/*
 *  Sets SIGSEGV handler
 */
static void set_signal()
{
	CHECK(SetConsoleCtrlHandler((PHANDLER_ROUTINE) CtrlHandler, TRUE) != FALSE);
}

/*
 *  Restores SIGSEGV handler
 */
static void restore_signal()
{
	CHECK(SetConsoleCtrlHandler((PHANDLER_ROUTINE) CtrlHandler, FALSE) != FALSE);
}

/*
 *    Check singularity by trying to create a file 
 *    We use CREATE_ALWAYS flags - if the file exists CreateFile will fail
 */
void check_singularity(){
	hLock = CreateFile(
            LOCK_FILE,
            0,
            0,
            NULL,	
            CREATE_NEW,
            FILE_ATTRIBUTE_NORMAL,
            NULL	
    );
    if (hLock == INVALID_HANDLE_VALUE) {
		report_error("__guardian_already_running", RUNNING);
		ExitProcess(EXIT_FAILURE);
    }
}

int main(int argc, char **argv){	
	BOOL bRet;
	DWORD dwRes, dwCmdSize;
	LPSTR lpCmdStr, lpName;
	
	/** skip first parameter */
	argc--; argv++;

	
	/** sanity check */
	if (argv[0] == NULL){
		fprintf_s(stderr, "Usage: nume_program arg1 arg2 ...\n");
		ExitProcess(EXIT_FAILURE);
	}

	check_singularity();
	set_signal();
	
	
	/** Save exec name */
	lpName = argv[0];

	/** Get Process heap */
	CHECK((hProcessHeap = GetProcessHeap()) != NULL);

	/** Compose command string */
	dwCmdSize = argc * MAX;
	lpCmdStr = HeapAlloc(hProcessHeap, HEAP_ZERO_MEMORY, dwCmdSize);   
	for (; *argv != NULL; argv++){
		CHECK(strcat_s(lpCmdStr, dwCmdSize,argv[0]) != -1);
		CHECK(strcat_s(lpCmdStr, dwCmdSize," ")		!= -1);
	}

	/** main loop */
	do{
		set_redirect(lpName, &si);
		ZeroMemory( &pi, sizeof(pi) );

		bRet = CreateProcess(
		        NULL,               
		        lpCmdStr,
		        NULL,               
		        NULL,               
		        TRUE,               
		        0,                  
		        NULL,               
		        NULL,               
		        &si,                
		        &pi);               
		
		if ((bRet == FALSE) && ERROR_FILE_NOT_FOUND == GetLastError()) {
			report_error("__child_does_not_exist", NOT_EXIST);
			clean();
			ExitProcess(EXIT_FAILURE);
		} else 
			CHECK(bRet != FALSE);

		dwRes = WaitForSingleObject(pi.hProcess, INFINITE);
		CHECK(WAIT_FAILED != dwRes);

		CloseProcess(&pi);
		CloseFileHandles(&si);
	}while(restart);

	CHECK(HeapFree(hProcessHeap, 0, lpCmdStr) != FALSE);
	restore_signal();
	clean();
	
	return EXIT_SUCCESS;
}
