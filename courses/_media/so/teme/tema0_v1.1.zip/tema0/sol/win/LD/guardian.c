/*!
 Tema 0 SO, Guardian process

 @author Dascalu Laurentiu

 Copyright (C) 2010 SO (http://cs.pub.ro/~so/)

 This program is free software; you can redistribute it and
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include "guardian.h"

#define GUARDIAN_LOCK_FILE      "C:\\guardian_lock"
#define CHILDREN_NOT_FOUND      (100)
#define USAGE                   "Usage: nume_program arg1 arg2 ...\r\n"
#define RUNNING                 "Guardian is already running\r\n"
#define NOT_EXIST               "The child program does not exist!\r\n"

static volatile int signal_received;
static char buffer[1024];
HANDLE err;

static void report_error(char *filename, char *info)
{
	DWORD written = -1;

	err = CreateFile(
		filename,
		FILE_WRITE_DATA,
		FILE_SHARE_WRITE,
		NULL,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL);

	CHECK(err, !=, INVALID_HANDLE_VALUE, "CreateFile()", -1);
	CHECK(WriteFile(err, info, strlen(info), &written, NULL), !=, 0, "WriteFile()", -1);
	CHECK(CloseHandle(err), !=, 0, "CloseHandle()", -1);
}

static int check_guardian()
{
	HANDLE fd;
	DWORD fileAttr;
	
	// Caut atributele unui fisier
	fileAttr = GetFileAttributes(GUARDIAN_LOCK_FILE);

	if (0xFFFFFFFF != fileAttr)
		return 0;

	fd = CreateFile(GUARDIAN_LOCK_FILE,
		GENERIC_WRITE,
		0,
		NULL,
		CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL);

	CHECK(CloseHandle(fd), !=, 0, "CloseHandle()", -1);
	return 1;
}

static void clean_guardian()
{
	// Sterg fisierul lock
	CHECK(DeleteFile(GUARDIAN_LOCK_FILE), !=, 0, "DeleteFile()", -1);
}

static BOOL CtrlHandler(DWORD eventType)
{
	signal_received = eventType;
	return TRUE;
}

static void register_handler()
{
	CHECK(SetConsoleCtrlHandler((PHANDLER_ROUTINE) CtrlHandler, TRUE), !=, FALSE, "SetConsoleCtrlHandler", -1);
	signal_received = -1;
}

static void redirect(char *arg, STARTUPINFO *si, SECURITY_ATTRIBUTES *sa)
{
	char str[128];
	HANDLE myStdinHandle, myStdoutHandle, myStderrHandle;

	sa->bInheritHandle = TRUE;

	myStdinHandle = CreateFile("nul",
		GENERIC_READ,
		FILE_SHARE_READ,
		sa,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL);
	CHECK(myStdinHandle, !=, INVALID_HANDLE_VALUE, "CreateFile", -1);

	CHECK(sprintf_s(buffer, 1023, "%s.stdout", arg), >=, 0, "snprintf()", -1);
	myStdoutHandle = CreateFile(buffer,
		FILE_APPEND_DATA,
		FILE_SHARE_WRITE | FILE_SHARE_READ,
		sa,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL);
	CHECK(myStdoutHandle, !=, INVALID_HANDLE_VALUE, "CreateFile", -1);

	CHECK(sprintf_s(buffer, 1024, "%s.stderr", arg), >=, 0, "snprintf()", -1);
	myStderrHandle = CreateFile(buffer,
		FILE_APPEND_DATA,
		FILE_SHARE_WRITE | FILE_SHARE_READ,
		sa,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL);
	CHECK(myStderrHandle, !=, INVALID_HANDLE_VALUE, "CreateFile", -1);

	si->cb = sizeof(*si);
	si->dwFlags = STARTF_USESTDHANDLES;
	si->hStdInput = myStdinHandle;
	si->hStdOutput = myStdoutHandle;
	si->hStdError = myStderrHandle;
}

static void close_old_handles(STARTUPINFO *si)
{
	if (si->hStdInput != NULL)
		CHECK(CloseHandle(si->hStdInput), !=, 0, "CloseHandle()", -1);
	if (si->hStdOutput != NULL)
		CHECK(CloseHandle(si->hStdOutput), !=, 0, "CloseHandle()", -1);
	if (si->hStdError != NULL)
		CHECK(CloseHandle(si->hStdError), !=, 0, "CloseHandle()", -1);
}

static void main_loop(int argc, char **argv)
{
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	SECURITY_ATTRIBUTES sa;
	int i;
	DWORD dwRes;
	char *cmd;

	buffer[0] = '\0';

	strcat(buffer, argv[0]);
	for (i = 1 ; i < argc ; i ++)
	{
		strcat(buffer, " ");
		strcat(buffer, argv[i]);
	}

	cmd = _strdup(buffer);
	dwRes = WAIT_OBJECT_0;
	ZeroMemory(&si, sizeof(si));

	while(1)
	{
		if (signal_received == CTRL_C_EVENT)
		{
			TerminateProcess(pi.hProcess, 0);
			break;
		}
		else if (signal_received == CTRL_BREAK_EVENT)
		{
			TerminateProcess(pi.hProcess, 0);
			signal_received = -1;
			dwRes = WAIT_OBJECT_0;
		}

		// Daca procesul copil s-a terminat, il repornesc
		if (dwRes == WAIT_OBJECT_0)
		{
			close_old_handles(&si);
			ZeroMemory (&sa, sizeof (sa));
			sa.nLength = sizeof(sa);
			ZeroMemory (&si, sizeof (si));
			redirect(argv[0], &si, &sa);

			if(!CreateProcess(NULL,
				cmd,
				NULL,
				NULL,
				TRUE,
				0,
				NULL,
				NULL,
				&si,
				&pi))
			{
				report_error("__child_does_not_exist", NOT_EXIST);
				return;
			}
		}

		dwRes = WaitForSingleObject(pi.hProcess, 0);
	}

	free(cmd);

}

int main(int argc, char **argv)
{
	if (argc <= 1)
	{
		fprintf(stderr, USAGE);
		return -1;
	}

	if (!check_guardian())
	{
		report_error("__guardian_already_running", RUNNING);
		return -1;
	}

	register_handler();
	main_loop(argc - 1, argv + 1);

	clean_guardian();

	return 0;
}
