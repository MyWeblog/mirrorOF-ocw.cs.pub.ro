#define _GNU_SOURCE
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <libgen.h>
#include <string.h>
#include <sys/wait.h>

#define PID_FILENAME "/tmp/.guardian.pid"
#define STDOUT_SUFFIX ".stdout"
#define STDERR_SUFFIX ".stderr"


/* implicitly restart the child when it dies.
 * this behaviour will be stopped when the guardian process receives a SIGINT
 */
static volatile int restart_child = 1;
static volatile pid_t child_pid;


static void kill_child(void)
{
	/* only send kill to propper children */
	if ((child_pid == 0) || (child_pid == (pid_t) -1))
		return;

	/* either we don't have permission to send a signal to the child
	 * or the child does not exist. Either case there's nothing we can do
	 * if an error is returned by kill(), so we don't even bother to check.
	 */
	kill(child_pid, SIGKILL);
}

static void signal_handler(int signal)
{
	/* killing is done in the signal handler.
	 * The main loop is stuck on a waitpid() system call.
	 * When waitpid() returns, it will restart the child (if restart_child != 0)
	 */
	if (signal == SIGCONT)
		kill_child();

	if (signal == SIGINT)
	{
		kill_child();
		restart_child = 0;
	}
}

int create_pid_file(void)
{
	int fd, rc, len;
	char pidbuf[30]; /* numeric pid represented as ASCII chars */

	fd = open(PID_FILENAME, O_CREAT | O_TRUNC | O_WRONLY, 0644);
	if (fd == -1)
		return -1;

	/* try to get an exclusive lock on the file.
	 * If another process holds the lock this will not block and
	 * it will return an error.
	 * When a process holding the lock exits, the file is unlocked.
	 * This lock is not inherited by child processes.
	 */
	rc = lockf(fd, F_TLOCK, 0);
	if (rc == -1)
	{
		if (errno == EACCES || errno == EAGAIN)
			fprintf(stderr, "Guardian is already running\n");
		goto error;
	}

	len = snprintf(pidbuf, sizeof(pidbuf), "%ld", (long) getpid());
	rc = write(fd, pidbuf, len);
	if (rc != len)
		goto error;

	/* don't close the file on success.
	 * We still need it open so that the lock remains taken until we exit.
	 */
	return 0;

error:
	close(fd);
	return -1;
}



/*
 * concatenate @program_name with @suffix,
 * open that file accodring to @flags
 * make dest_fd file descriptor point to that file.
 */
static int redirect_file(const char * const program_name, const char * suffix, int dest_fd, int flags)
{
	int rc;
	char *name;
	size_t program_name_len, len;
	int fd = -1;

	program_name_len = strlen(program_name);
	if (program_name_len == 0)
		return -1;

	len = program_name_len + strlen(suffix) + 1 /* \0 */;
	name = malloc(len);
	if (!name)
		return -1;

	snprintf(name, len, "%s%s", program_name, suffix);
	fd = open(name, flags, 0644);
	free(name);
	if (fd == -1)
		return -1;

	rc = dup2(fd, dest_fd);
	close(fd);

	return rc;
}

static int redirect_std_files(const char * const program_path)
{
	int rc;
	const char * program_name = basename((char*) program_path);
	rc = redirect_file(program_name, STDOUT_SUFFIX, STDOUT_FILENO, O_CREAT | O_APPEND | O_WRONLY);
	if (rc == -1)
		return -1;

        rc = redirect_file(program_name, STDERR_SUFFIX, STDERR_FILENO, O_CREAT | O_APPEND | O_WRONLY);
	if (rc == -1)
	{
		close(STDOUT_FILENO);
		return -1;
	}

	rc = redirect_file("/dev/null", "", STDIN_FILENO, O_RDONLY);
	if (rc == -1)
	{
		close(STDOUT_FILENO);
		close(STDERR_FILENO);
	}
	return 0;
}

static pid_t create_process(char * argv[])
{
	char buff[1];
	int rc;
	pid_t child_pid;
	int fifo[2];


	/* we want the fifo file descriptors to be automagically closed if exec succeeds
	 * so that the monitored process cannot interfere with the guardian.
	 * The file descriptors will remain valid if the exec() call fails!
	 * Well use this to reliably send messages from the child to the parrent.
	 */
	rc = pipe2(fifo, O_CLOEXEC);
	if (rc != 0)
		exit(EXIT_FAILURE); /* maybe we should write an err msg? */

	child_pid = fork();
	switch(child_pid)
	{
		case -1:
			exit(EXIT_FAILURE);
		case 0:
			rc = redirect_std_files(argv[0]);
			if (rc == 0)
			{
				execvp(argv[0], argv);
				execv (argv[0], argv);
			}
			/* normally execvp/execv should not return, but it may do so
			 * if argv[0] is not existent, or not executable, etc.
			 * We also exit if file redirect was not possible.
			 */

			/* repeat sending stuff until a char gets through or a real error appears*/
			do {
				rc = write(fifo[1], "x", 1);
			} while(rc < 1 || (rc == -1 && errno == EINTR));
			exit(EXIT_FAILURE);
		default:
			/* close my writing end */
			close(fifo[1]);

			/* read a char and skip all EINTR errors */
			do {
				rc = read(fifo[0], buff, 1);
			} while (rc == -1 && errno == EINTR);
			/* close my reading end (avoid consumming all available fds) */
			close(fifo[0]);

			/* if we could read char then the exec() calls failed and
			 * the child got to write on the fifo. If the child's exec() calls would have
			 * succeeded, the fifo fds would have been closed (due to O_CLOEXEC) and
			 * we would have received an EOF (i.e. rc == 0) from the read system call.
			 *
			 * Treat error of communication with the child as an error of execuing the child.
			 */
			if (rc != 0)
				return -1;
	}

	return child_pid;
}

int main(int argc, char * argv[])
{
	int rc;

	if (argc < 2)
	{
		fprintf(stderr, "Usage: nume_program arg1 arg2 ...\n");
		return EXIT_FAILURE;
	}

	/* daemonize, but don't change current dir, and don't close standard files */
	rc = daemon(1, 1);
	if (rc == -1)
		return EXIT_FAILURE;

	/* pid file creation *must* follow the daemon() call because the pid file is locked
	 * and the lock does *not* survive fork()s. daemon() uses fork()s and this leads to lock loss
	 */
	rc = create_pid_file();
	if (rc == -1)
		return EXIT_FAILURE;

	if ((SIG_ERR == signal(SIGINT,  &signal_handler)) ||
	    (SIG_ERR == signal(SIGCONT, &signal_handler)) ||
	    (SIG_ERR == signal(SIGSEGV, &signal_handler)))
		return EXIT_FAILURE;

	do {
		int rc;
		child_pid = create_process(argv + 1); /* +1 to skip the first element: this program's name */
		if (child_pid == -1)
		{
			fprintf(stderr, "The child program does not exist!\n");
			break;
		}


		/* don't care why the child died. wait until death. */
		rc = waitpid(child_pid, NULL, 0);
		if (rc == -1)
			return EXIT_FAILURE;
	} while(restart_child);
	return EXIT_SUCCESS;
}

