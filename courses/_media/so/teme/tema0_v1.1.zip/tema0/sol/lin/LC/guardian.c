/*
 * ==========================================================================
 *
 *       Filename:  t0.c
 *
 *    Description:  Homework 0, SO
 *
 *        Created:  01/29/2010 08:18:02 PM
 *       Revision:  none
 *
 *         Author:  Cojocar Lucian, cojocar-gmail-com
 *
 * ==========================================================================
 */
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define LOCK_PATH	"/tmp/aplicatia_mea"
#define MAXARGS	32
#define MAXF	255

#define DIE(x) do {\
	if ((x)) {\
		perror(#x);\
		exit(-1);\
	}\
} while (0)

static pid_t child_pid;
static int restart;

static void
tratare_semnal(int sig)
{
	switch (sig) {
	case SIGINT:
		restart = 0;
		kill(child_pid, SIGKILL);
		break;
	case SIGCONT:
		kill(child_pid, SIGKILL);
		break;
	default:
		fprintf(stderr, "sig: %d\n", sig);
	}
}

int
main(int argc, char *argv[])
{
	char *bin_name = NULL;
	char tmp[MAXF];
	char x;
	int err, out;
	int i;
	int status;
	int app_fd;
	char *args[MAXARGS];
	sigset_t new_set, old_set;
	struct sigaction semnale;
	int status_fd[2];

	if (argc < 2) {
		fprintf(stderr, "Usage: nume_program arg1 arg2 ...\n");
		exit(-1);
	}

	/* 
	 * verificam daca suntem singuri
	 */
	DIE((app_fd = open(LOCK_PATH, O_CREAT | O_WRONLY, 0666)) < 0);
	status = flock(app_fd, LOCK_EX | LOCK_NB);
	if (status < 0) {
		if (errno == EWOULDBLOCK) {
			fprintf(stderr, "Guardian is already running\n");
			exit(-1);
		}
		DIE(status < 0);
	}
	
	DIE(close(STDIN_FILENO) < 0);
	DIE(open("/dev/null", O_RDONLY) < 0);

	DIE(daemon(1, 1) < 0);
	/*
	 * extragere cale din numele comenzii
	 * /bin/ls => ls
	 * strrchr?
	 */
	bin_name = strrchr(argv[1], '/');
	if (!bin_name) {
		bin_name = argv[1];
	}

	/* pregatim argumentele */
	assert(argc < MAXARGS);
	for (i = 0; i < argc; ++i) {
		args[i] = argv[i+1];
	}
	args[i] = NULL;

	/* semanle */
	/* mascam toate semnalele */
	DIE(sigfillset(&new_set) < 0);
	DIE(sigdelset(&new_set, SIGINT) < 0);
	DIE(sigdelset(&new_set, SIGCONT) < 0);
	DIE(sigprocmask(SIG_SETMASK, &new_set, &old_set) < 0);

	/* adaugam handler pentru semnalele nemascate */
	DIE(sigemptyset(&new_set) < 0);
	DIE(sigaddset(&new_set, SIGINT) < 0);
	DIE(sigaddset(&new_set, SIGCONT) < 0);

	memset(&semnale, 0, sizeof (semnale));
	semnale.sa_handler = tratare_semnal;
	semnale.sa_mask = new_set;
	semnale.sa_flags = SA_RESTART;
	sigaction(SIGINT, &semnale, NULL);
	sigaction(SIGCONT, &semnale, NULL);

	restart = 1;
	do {
		/*
		 * creeaza fisierele de log
		 */
		snprintf(tmp, MAXF, "%s.stdout", bin_name);
		DIE((out = open(tmp, O_WRONLY | O_CREAT | O_APPEND, 0666)) < 0);

		snprintf(tmp, MAXF, "%s.stderr", bin_name);
		DIE((err = open(tmp, O_WRONLY | O_CREAT | O_APPEND, 0666)) < 0);

		/* pipe comunicatie */
		DIE(pipe(status_fd) < 0);
		DIE(fcntl(status_fd[0], F_SETFL, O_NONBLOCK) < 0);

		DIE((child_pid = fork()) < 0);
		if (child_pid) {
			/* parinte */
			DIE(close(status_fd[1]) < 0);

			DIE(child_pid != wait(&status));

			if (read(status_fd[0], &x, 1) == 1) {
				fprintf(stderr, "The child program does not exist!\n");
				restart = 0;
			}

			DIE(close(out) < 0);
			DIE(close(err) < 0);

			DIE(close(status_fd[0]) < 0);
		} else {
			/* copil */
			/*
			 * stdout, si stderr
			 * sau dup2(STDOUT_FILENO, out)
			 */
			DIE(close(STDOUT_FILENO) < 0);
			DIE(dup(out) < 0);
			DIE(close(STDERR_FILENO) < 0);
			DIE(dup(err) < 0);

			DIE(close(status_fd[0]) < 0);
			/*
			 * se putea modifica variabila $PATH, dar cred ca era ilegal din
			 * punctul de vedere al enuntului
			 */
			if (execvp(argv[1], args) < 0) {
				/* poate e in calea curenta */
				if (execv(argv[1], args) < 0) {
					/* fail */
					DIE(write(status_fd[1], &x, 1) < 0);
				}
			}
			DIE(close(status_fd[1]) < 0);
			exit(0);
		}
	} while (restart);

	DIE(sigprocmask(SIG_SETMASK, &old_set, NULL) < 0);
	DIE(flock(app_fd, LOCK_UN) < 0);
	DIE(close(app_fd) < 0);
	DIE(unlink(LOCK_PATH) < 0);

	return 0;
}
