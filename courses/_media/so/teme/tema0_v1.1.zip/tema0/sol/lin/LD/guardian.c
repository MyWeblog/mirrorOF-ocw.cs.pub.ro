/*!
 Tema 0 SO, Guardian process

 Aplicatia ofera suport pentru pornirea, repornirea si oprirea unui proces.
 O singura instanta de guardian ruleaza la un moment dat si iesirile standard
 ale procesului copil sunt redirectate in nume_comanda.stdout si nume_comanda.stderr.
 Procesul guardian are rolul de repornire a unui proces/serviciu in momentul
 in care acesta isi intrerupe brusc activitatea.

 @author Dascalu Laurentiu

 Copyright (C) 2010 SO (http://cs.pub.ro/~so/)

 This program is free software; you can redistribute it and
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "guardian.h"

#define GUARDIAN_LOCK_FILE      "/tmp/.lock.guardian"
#define PATH                    "PATH"
#define DEBUG                   0
#define CHILDREN_NOT_FOUND      (100)

static volatile int signal_received;
static char buffer[1024];

#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>

static int check_guardian()
{
	int fd = open(GUARDIAN_LOCK_FILE, O_TRUNC | O_RDWR);

	if (fd != -1)
	{
		CHECK(close(fd), ==, 0, "close()", -1);
		return 0;
	}

	fd = open(GUARDIAN_LOCK_FILE, O_CREAT | O_TRUNC | O_RDWR, 0644);
	CHECK(close(fd), ==, 0, "close()", -1);
	return 1;
}

static void clean_guardian()
{
	CHECK(unlink(GUARDIAN_LOCK_FILE), ==, 0, "unlink()", -1);
}

static void update_path()
{
	static char *aux;
	int n;
	memset(buffer, '\0', sizeof(buffer));

	CHECK(aux = getenv(PATH), !=, NULL, "getenv()", -1);
	CHECK(strcat(buffer, aux), !=, NULL, "strcat()", -1);
	CHECK(strcat(buffer, ":"), !=, NULL, "strcat()", -1);

	CHECK(n = strlen(buffer), >=, 0, "strlen()", -1);
	CHECK(getcwd(buffer + n, 1024 - n), !=, NULL, "getcwd()", -1);
	setenv(PATH, buffer, 1);
}

static void signal_handler(int signal)
{
	signal_received = signal;
}

static void register_handler()
{
	int i;
	struct sigaction sa;

	CHECK(daemon(1, 1), ==, 0, "daemon()", -1);
	CHECK(memset(&sa, 0, sizeof(sa)), !=, NULL, "memset()", -1);

	// Iterez de la primul la ultimul semnal
	for (i = SIGHUP; i <= SIGSYS; i++)
	{
		// Nu interceptez SIGUSR1, SIGUSR2
		// si nu se pot intercepta SIGSTOP si SIGKILL
		if (i == SIGUSR1 || i == SIGUSR2 || i == SIGSTOP || i == SIGKILL)
			continue;
		if (i == SIGINT || i == SIGCONT || i == SIGCHLD)
			sa.sa_handler = signal_handler;
		else
			sa.sa_handler = SIG_IGN;

		CHECK(sigaction(i, &sa, NULL), >=, 0, "sigaction()", -1);
	}
}

static void main_loop(int argc, char **argv)
{
	pid_t child;
	int status, result;
	int fd;

	signal_received = -1;

	while (1)
	{
		switch (child = fork())
		{
		case -1:
			perror("fork()\n");
			exit(1);
		case 0:
		{
			// Redirectez STDIN
			CHECK(fd = open("/dev/null", O_RDONLY), >=, 0, "open()", -1);
			CHECK(dup2(fd, STDIN_FILENO), !=, -1, "dup2()", -1);

			// Redirectez STDOUT
			CHECK(snprintf(buffer, 1024, "%s.stdout", argv[0]), >=, 0, "snprintf()", -1);
			CHECK(fd = open(buffer, O_WRONLY | O_CREAT | O_APPEND, 0644), >=, 0, "open()", -1);
			CHECK(dup2(fd, STDOUT_FILENO), !=, -1, "dup2()", -1);

			// Redirectez STDERR
			CHECK(snprintf(buffer, 1024, "%s.stderr", argv[0]), >=, 0, "snprintf()", -1);
			CHECK(fd = open(buffer, O_WRONLY | O_CREAT | O_APPEND, 0644), >=, 0, "open()", -1);
			CHECK(dup2(fd, STDERR_FILENO), !=, -1, "dup2()", -1);

			execvp(argv[0], argv);
			exit(CHILDREN_NOT_FOUND);
		}
		default:
		{
			wait_pid:
			// waitpid() intoarce -1 daca apare un semnal
			result = waitpid(child, &status, 0);

			// Am primit un semnal
			if (signal_received == SIGCONT)
			{
				/*
				 * Am primit SIGCONT =>
				 *  2. continui in bucla de creare a copilului
				 *  1. opresc procesul copil
				 */
				CHECK(kill(child, SIGKILL), ==, 0, "kill()", -1);
				signal_received = -1;
				goto wait_pid;
			}
			else if (signal_received == SIGINT)
			{
				/*
				 * Am primit SIGINT =>
				 *  1. opresc procesul copil
				 *  2. opresc executia guardianului
				 //CHECK(kill(child, SIGKILL), ==, 0, "kill()", -1);
				 */
				kill(child, SIGKILL);
				signal_received = -1;
				return;
			}

			signal_received = -1;
			if (WEXITSTATUS(status) == CHILDREN_NOT_FOUND)
			{
				fprintf(stderr, "The child program does not exist!\n");
				return;
			}
			else
			{
				if (DEBUG && WIFEXITED(status))
					printf("Child terminated normally, with code %d\n",
					WEXITSTATUS(status));
			}
		}
		}
	}
}

int main(int argc, char **argv)
{
	if (argc <= 1)
	{
		fprintf(stderr, "Usage: nume_program arg1 arg2 ...\n");
		return -1;
	}

	if (!check_guardian())
	{
		fprintf(stderr, "Guardian is already running\n");
		return -1;
	}

	update_path();
	register_handler();
	main_loop(argc - 1, argv + 1);
	clean_guardian();

	return 0;
}
