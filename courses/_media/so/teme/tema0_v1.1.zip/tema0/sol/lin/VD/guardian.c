/*
 * Tema 0 Sisteme de Operare, Vlad Dogaru
 * 21 februarie 2010
 */

/* This program is free software. It comes without any warranty, to
 * the extent permitted by applicable law. You can redistribute it
 * and/or modify it under the terms of the Do What The Fuck You Want
 * To Public License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */ 

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>


/**
 * Lock file used to ensure singletonic state.
 * \remarks I would have rather used /var/lock, but that's generally off
 * limits to regular users.
 */
#define LOCK_FILE	"/tmp/guardian.lock"

/** Suffixes for stdout and stderr files. */
#define STDOUT_SUFFIX	".stdout"
#define STDERR_SUFFIX	".stderr"


/** This tells the guardian whether to respawn the child after it
 * finishes. It is set to 0 (don't respawn) by the signal handler when
 * receiving a SIGINT. */
static volatile int restart_child;

/** The current child pid. A value of 0 means no child is running. */
static volatile pid_t child_pid = 0;


/**
 * Ensure another guardian is not already running. This uses a simple
 * file in /tmp to ensure singletonic behaviour, although there are
 * probably better ideas out there.
 *
 * \returns 0 in case of success, or -1 in case another process is
 * already running.
 *
 * \remarks We achieve our goal by making sure a file does not exist and
 * creating it if it does not. Be aware, however, that this is not
 * portable. Read the note in open(2) on O_EXCL. But /tmp mounted over
 * NFS is not a common setup, so we prefer simplicity over absolute
 * correctness.
 */
static int acquire_lock(void);

/** Update PATH environment variable to contain current directory at the
 * end. */
static void update_path(void);

/** Spawn the child process. */
static pid_t run_process(char **);

/** Release the lock that we acquired, so that another guardian process
 * may run. */
static void release_lock(void);

/** Signal handler for the guardian process. */
static void sighandler(int sig_number);

/** Install the custom signal handler for the guardian process.  */
static void install_signal_handler(void);

/** Redirect an output file descriptor to a file. */
void redirect_out(int, const char *);

/** Redirect stdin from /dev/null. */
void redirect_in(void);

int main(int argc, char **argv)
{
	if (argc == 1) {
		fprintf(stderr, "Usage: nume_program arg1 arg2 ...\n");
		exit(EXIT_FAILURE);
	}
	if (acquire_lock() == -1) {
		fprintf(stderr, "Guardian is already running\n");
		exit(EXIT_FAILURE);
	}

	update_path();
	install_signal_handler();

	restart_child = 1;
	if (daemon(1, 1) == -1) {
		perror("daemon");
		exit(EXIT_FAILURE);
	}
	while (restart_child) {
		child_pid = run_process(argv + 1);
		if (child_pid == -1)
			break;
		waitpid(child_pid, NULL, 0);
	}

	release_lock();

	return 0;
}


static int acquire_lock(void)
{
	int fd;

	fd = open(LOCK_FILE, O_CREAT | O_EXCL | O_RDWR, 0644);
	/* File creation might fail either if file already exists (in
	 * which case a process is already running), or in some abnormal
	 * condition. We distinguish bethween the two cases. */
	if (fd == -1) {
		if (errno == EEXIST)
			return -1;
		else {
			perror("open");
			exit(EXIT_FAILURE);
		}
	}

	if (close(fd) == -1)
		perror("close"); /* But try to normally continue. */

	return 0;
}


static void update_path(void)
{
	char *old_path, *new_path;

	old_path = getenv("PATH");
	/* If $PATH is unset, set it to ".". */
	if (old_path == NULL) {
		if (setenv("PATH", ".", 0) == -1) {
			perror("setenv");
			exit(EXIT_FAILURE);
		}
		return;
	}

	/* Concatenate ":." to $PATH. Allocate new_path to length of old
	 * path + 2 (":.") + 1 (\0).
	 *
	 * Use of strlen is strongly discouraged normally, but if we
	 * can't trust getenv, we're in a lot of trouble. */
	new_path = malloc(strlen(old_path) + 3);
	if (new_path == NULL) {
		perror("malloc");
		exit(EXIT_FAILURE);
	}
	/* Normally we should use snprintf, but we already trust
	 * old_path's length and have allocated an adequate buffer. */
	sprintf(new_path, "%s:.", old_path);
	if (setenv("PATH", new_path, 1) == -1) {
		perror("setenv");
		exit(EXIT_FAILURE);
	}
}


static pid_t run_process(char **argv)
{
	int pfd[2], result;
	char buf;
	pid_t pid;
	
	if (pipe2(pfd, O_CLOEXEC) == -1) {
		perror("pipe");
		exit(EXIT_FAILURE);
	}
	pid = fork();
	if (pid == -1)
		perror("fork");
	/* Child. */
	if (pid == 0) {
		char *fname;
		/* Redirect stdout. */
		fname = malloc(strlen(*argv) + strlen(STDOUT_SUFFIX) + 1);
		if (fname == NULL) {
			perror("malloc");
			exit(EXIT_FAILURE);
		}
		sprintf(fname, "%s%s", *argv, STDOUT_SUFFIX);
		redirect_out(STDOUT_FILENO, fname);
		free(fname);

		/* Redirect stderr. */
		fname = malloc(strlen(*argv) + strlen(STDERR_SUFFIX) + 1);
		if (fname == NULL) {
			perror("malloc");
			exit(EXIT_FAILURE);
		}
		sprintf(fname, "%s%s", *argv, STDERR_SUFFIX);
		redirect_out(STDERR_FILENO, fname);
		free(fname);

		/* Redirect stdin. */
		redirect_in();

		execvp(*argv, argv);

		/* If we get here, it means exec failed. Notify parent
		 * of that. Send one character through the pipe to let
		 * parent know we messed up. Ripped off from Lucian
		 * Grijincu. */
		do {
			result = write(pfd[1], &buf, 1);
		} while (((result == -1) && (errno == EINTR)) || (result < 1));
		exit(EXIT_FAILURE);
	} else {
		/* Check that the child process successfully called
		 * exec. If it didn't, we should successfully read a
		 * byte from the pipe. */
		close(pfd[1]);
		do {
			result = read(pfd[0], &buf, 1);
		} while ((result == -1) && (errno == EINTR));
		close(pfd[0]);
		if (result == 1) {
			fprintf(stderr, "The child program does not exist!\n");
			return -1;
		}
		return pid;
	}
}


static void release_lock(void)
{
	if (unlink(LOCK_FILE) == -1)
		perror("unlink");
}


static void sighandler(int sig_number)
{
	/* Stop respawning the child if we get an INT. */
	if (sig_number == SIGINT)
		restart_child = 0;
	/* Kill the chld process if we get CONT or INT. */
	if ((sig_number == SIGINT) || (sig_number == SIGCONT)) {
		if (child_pid != 0)
			kill(child_pid, SIGKILL);
	}
}


static void install_signal_handler(void)
{
	if ((signal(SIGINT, sighandler) == SIG_ERR) ||
			(signal(SIGCONT, sighandler) == SIG_ERR) ||
			(signal(SIGSEGV, SIG_IGN) == SIG_ERR)) {
		perror("signal");
		exit(EXIT_FAILURE);
	}
}


void redirect_out(int target_fd, const char *fname)
{
	int fd = open(fname, O_WRONLY | O_APPEND | O_CREAT, 0644);
	if (fd == -1) {
		perror("open");
		exit(EXIT_FAILURE);
	}
	if (dup2(fd, target_fd) == -1) {
		perror("dup2");
		exit(EXIT_FAILURE);
	}
	if (close(fd)) {
		perror("close");
		exit(EXIT_FAILURE);
	}
}


void redirect_in(void)
{
	int fd = open("/dev/null", O_RDONLY);
	if (fd == -1) {
		perror("open");
		exit(EXIT_FAILURE);
	}
	if (dup2(fd, STDIN_FILENO) == -1) {
		perror("dup2");
		exit(EXIT_FAILURE);
	}
	if (close(fd)) {
		perror("close");
		exit(EXIT_FAILURE);
	}
}
