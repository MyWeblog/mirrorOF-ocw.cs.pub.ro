/**
 * SO Assignment #0 Linux, Guardian Process
 *
 * @author Andrei Faur
 * Copyright (C) 2010, SO team (http://cs.pub.ro/~so/)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <setjmp.h>

#include "guardian.h"

/* A handle to the file used for locking */
static int guardfd;

/* Variable controlling the loop */
static volatile int restart;

/* Pid of child process, needed in the signal handler */
static volatile int child_pid = 0;


/* This routine handles the single-instance application problem */
int lock_setup()
{
	/* Declare an exclusive lock on the whole file */
	struct flock fl = {
		.l_type	= F_WRLCK,
		.l_start = 0,
		.l_whence = SEEK_SET,
		.l_len = 0,
		.l_pid = getpid()
	};

	/* Open the lock to get the descriptor */
	if ((guardfd = open(GUARDIAN_LOCK, O_CREAT | O_WRONLY, 0222)) < 0)
		return LOCK_TAKEN;

	/* If we have the descriptor, then set the lock */
	if (fcntl(guardfd, F_SETLK, &fl) < 0)
		return LOCK_TAKEN;

	/* If previous routines have not failed it means we have the lock */
	return LOCK_AVAILABLE;
}


/* Updates the PATH with the current directory */
void path_setup()
{
	/* Get the PATH variable and the current working directory */
	char *working_dir = getcwd(NULL, 0);
	CHECKERR(working_dir == NULL);

	char *old_path = getenv("PATH");
	CHECKERR(old_path == NULL);

	/* Allocate a new buffer and create new PATH */
	char *new_path;
	new_path = malloc(strlen(old_path) + strlen(working_dir) + 1);
	strcpy(new_path, old_path);
	strcat(new_path, ":");
	strcat(new_path, working_dir);

	CHECKERR(setenv("PATH", new_path, 1) < 0);

	free(new_path);
}


/* Our required signal handler */
static void sig_handler(int signum)
{
	switch(signum) {
		/* Kill the child process, the loop will resurrect it */
		case SIGCONT:
			kill(child_pid, SIGKILL);
			break;
		/* Kill the child process and disable the loop */
		case SIGINT:
			if (child_pid != 0)
				kill(child_pid, SIGKILL);
			restart = 0;
			break;
	}
}


/* This routine reroutes SIGCONT and SIGINT handling to our own
 * function. It makes sure that we ignore the signals in the handler */
void signal_setup()
{
	// SIGCONT and SIGINT will be ignored when the handler runs 
	sigset_t ign_mask;
	CHECKERR(sigemptyset(&ign_mask) < 0);
	CHECKERR(sigaddset(&ign_mask, SIGCONT) < 0);
	CHECKERR(sigaddset(&ign_mask, SIGINT) < 0);

	// SIGCONT and SIGINT will be handled by our own routine 
	struct sigaction action = {
		.sa_handler = sig_handler,
		.sa_mask = ign_mask,
		.sa_flags = SA_RESTART
	};
	sigaction(SIGCONT, &action, NULL);
	sigaction(SIGINT, &action, NULL); 

	// Ignore SIGSEGV
	action.sa_handler = SIG_IGN;
	sigaction(SIGSEGV, &action, NULL);
}


/* Perform redirection as mentioned in the assignment */
void redirect(char *name)
{
	int fd;
	char *fname;

	fname = malloc(strlen(name) + SUFFIX_LENGTH + 2);

	/* Input taken from /dev/null */
	CHECKERR((fd = open("/dev/null", O_RDONLY)) < 0);
	CHECKERR(dup2(fd, STDIN_FILENO) < 0);

	/* Output to name.stdout */
	sprintf(fname, "%s.%s", name, "stdout");
	CHECKERR((fd = open(fname, O_WRONLY | O_CREAT | O_APPEND, 0622)) < 0);
	CHECKERR(dup2(fd, STDOUT_FILENO) < 0);

	/* Error to name.stderr */
	sprintf(fname, "%s.%s", name, "stderr");
	CHECKERR((fd = open(fname, O_WRONLY | O_CREAT | O_APPEND, 0622)) < 0);
	CHECKERR(dup2(fd, STDERR_FILENO) < 0);

	free(fname);
}


/* The core of the implementation, this routine spawns and respawns
 * the child process until a signal causes it to break from the loop
 * by setting restart to 0 */
void guard(char **argv)
{
	siginfo_t info;

	/* Respawn the child until we receive SIGINT */
	restart = 1;
	while(restart) {
		/* Ken Leee, tulibu dibu douchoo....*/
		switch (child_pid = fork()) {
			case -1:/* error */
				perror("pid = fork()");
				exit(EXIT_FAILURE);
			case 0: /* child */
				redirect(*argv);
				execvp(*argv, argv);
				exit(CHILD_ERROR);
		}

		/* parent */

		/* Wait for child to finish */
		waitid(P_PID, child_pid, &info, WEXITED | WSTOPPED);

		/* Quit if child process wasn't started (because of exec err)*/
		if (info.si_code == CLD_EXITED &&
		    info.si_status == (CHILD_ERROR & 0xEF)) {
			fprintf(stderr, "The child program does not exist!\n");
			exit(EXIT_FAILURE);
		}
	}
}

/* We could have ommited this, but in general it is a good
 * ideea to have a cleanup routine */
void cleanup()
{
	CHECKERR(close(guardfd) < 0);
	CHECKERR(unlink(GUARDIAN_LOCK) < 0);
}


/* Walk through the logical steps */
int main(int argc, char **argv)
{
	/* Always check your input */
	if (argc < 2) {
		fprintf(stderr, "Usage: program_name arg1 arg2 ...\n");
		exit(EXIT_FAILURE);
	}

	/* Daemonize */
	CHECKERR(daemon(1, 1) < 0);

	/* Do not continue if there is another guardian running */
	if (lock_setup() == LOCK_TAKEN) {
		fprintf(stderr, "Guardian is already running\n");
		exit(EXIT_FAILURE);
	}

	/* Add current directory to PATH, so that exec will search it */
	path_setup();

	/* Register the handlers for SIGINT and SIGCONT */
	signal_setup();

	/* En Garde! */
	guard(argv + 1);

	cleanup();

	return EXIT_SUCCESS;
}

