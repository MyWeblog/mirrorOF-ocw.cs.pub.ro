/*!
  Counter pe o celula de memorie virtuala pana la o anumita valoarea maxima.
 Incrementarea se face in iteratii (rulari consecutive) si astfel
 se verifica daca procesul guardian reincarca procesul copil.
 
 @author Dascalu Laurentiu

 Copyright (C) 2010 SO (http://cs.pub.ro/~so/)

 This program is free software; you can redistribute it and
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 3
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "include/child_util.h"

#ifdef _WIN32
#define SHM_NAME                 "my_shm"
#else
#define SHM_NAME                 "/my_shm"
#endif

#define SHM_SIZE                         1
#define SHM_MAX_VALUE                    5

#ifdef _WIN32

static HANDLE open(DWORD flag)
{
	HANDLE fd;

	fd = CreateFile(
			SHM_NAME,
			FILE_READ_DATA | FILE_WRITE_DATA,
			FILE_SHARE_READ,
			NULL,
			flag,
			FILE_ATTRIBUTE_NORMAL,
			NULL);
	return fd;
}

static void windows_destroy(HANDLE hFile)
{
	CHECK(CloseHandle(hFile), !=, 0, "CloseHandle()", -1);
	CHECK(DeleteFile(SHM_NAME), !=, 0, "DeleteFile()", -1);
}

void windows_create_init_shm()
{
	// Persistent shared memory not available in Windows
}

LPVOID map(HANDLE fd, DWORD size, HANDLE *hMapFile) {
	HANDLE mo;
	LPVOID mem;

	mo = CreateFileMapping(
			fd,
			NULL,
			PAGE_READWRITE,
			0,
			size,
			NULL);
	CHECK(mo, !=, NULL, "CreateFileMapping()", -1);
	*hMapFile = mo;

	mem = MapViewOfFile(
			mo,
			FILE_MAP_ALL_ACCESS,
			0,
			0,
			0);
	CHECK(mem, !=, NULL, "MapViewOfFile()", -1);

	return mem;
}

#else

#include <sys/mman.h>
#include <sys/types.h>
#include <fcntl.h>

static void linux_create_init_shm()
{
	char *mem;
	int shm_fd;

	shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0644);

	CHECK(shm_fd, >=, 0, "shm_open()", -1);
	CHECK(ftruncate(shm_fd, SHM_SIZE), >=, 0, "ftruncate()", -1);

	mem = (char *) mmap(0, SHM_SIZE, PROT_WRITE | PROT_READ, MAP_SHARED,
			shm_fd, 0);

	CHECK(mem, !=, MAP_FAILED, "mmap()", -1);

	mem[0] = 0;

	CHECK(munmap(mem, SHM_SIZE), >=, 0, "munmap()", -1);
	CHECK(close(shm_fd), >=, 0, "close()", -1);
}

#endif

static void create_init_shm()
{
	void (*dispatch)() = NULL;

	// Initializez pointerul dispatch cu functia
	// dependenta de platforma
#ifdef _WIN32
	dispatch = windows_create_init_shm;
#else
	dispatch = linux_create_init_shm;
#endif

	dispatch();
}


int main()
{
	char *mem, result;
#ifdef _WIN32
	HANDLE hMapFile, hFile;
#else
	int shm_fd;
#endif

#ifdef _WIN32
	hFile = open(OPEN_EXISTING);
	if (INVALID_HANDLE_VALUE == hFile)
	{
		// Creez fisierul daca nu exista
		hFile = open(CREATE_ALWAYS);

		// Il mapez in memorie si initializez celula de memorie
		mem = map(hFile, SHM_SIZE, &hMapFile);
		mem[0] = 0;
	}
	else
		// Daca fisierul exista, atunci mapez fisierul in memorie
		mem = map(hFile, SHM_SIZE, &hMapFile);
#else
	shm_fd = shm_open(SHM_NAME, O_RDWR, 0644);
	if (shm_fd < 0)
	{
		create_init_shm();
		shm_fd = shm_open(SHM_NAME, O_RDWR, 0644);
	}

	mem = (char *) mmap(0, SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED,
			shm_fd, 0);
	CHECK(mem, !=, MAP_FAILED, "mmap()", -1);
#endif

	PRINT_STDOUT("Am citit din memoria partajata: %d\n", mem[0]);
	result = ++mem[0];

#ifdef _WIN32
	CHECK(UnmapViewOfFile(mem), !=, 0, "UnmapViewOfFile()", -1);
	CHECK(CloseHandle(hMapFile), !=, 0, "CloseHandle()", -1);
#else
	CHECK(munmap(mem, SHM_SIZE), >=, 0, "munmap()", -1);
	CHECK(close(shm_fd), >=, 0, "close()", -1);
#endif

	if (result >= SHM_MAX_VALUE)
	{
#ifdef _WIN32
		windows_destroy(hFile);
#else
		CHECK(shm_unlink(SHM_NAME), >=, 0, "unlink()", -1);
#endif
		FINAL_WORK();
	}

	return 0;
}

