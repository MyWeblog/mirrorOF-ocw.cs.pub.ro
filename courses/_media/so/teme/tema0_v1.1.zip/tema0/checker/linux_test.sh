#!/bin/bash

GUARDIAN="./guardian"
GUARDIAN_ALREADY_RUNNING="__guardian_already_running"
CHILD_DOES_NOT_EXIT="__child_does_not_exist"
passed=0
failed=0

function my_check
{
	diff child${1}.stderr linux_ref/child${1}.stderr
	stdout_res=$?
	diff child${1}.stdout linux_ref/child${1}.stdout
	stderr_res=$?

	result=`expr $stdout_res + $stderr_res`

	if [ $result -eq 0 ]
	then
		passed=`expr $passed + 1`
		echo '	PASSED'
	else
		failed=`expr $failed + 1`
		echo '	FAILED'
	fi
}

function my_send_signal
{
	echo "Trimit ${1}"
	killall -${1} guardian
	for i in `seq 1 4`
	do
		sleep 0.25
	done
}

cd src ; make -f Makefile.Linux clean
make -f Makefile.Linux
cd ..

for i in `seq 1 4`
do
    cp ./src/child${i} .
done

# START
# ========================================================================== #
echo 'Test 0'
echo '  Verific daca o singura instanta de guardian ruleaza la un moment dat'
rm -rf ${GUARDIAN_ALREADY_RUNNING}
sleep 0.1
x=$RANDOM
mkdir -p __test${x}/
cd __test${x}/ ; ../$GUARDIAN pwd ; cd ..
sleep 0.5
$GUARDIAN ls 2&> ${GUARDIAN_ALREADY_RUNNING}
killall -SIGINT guardian
sleep 0.5
sleep 1
diff ${GUARDIAN_ALREADY_RUNNING} linux_ref/${GUARDIAN_ALREADY_RUNNING}
if [ $? -eq 0 ]
then
	passed=`expr $passed + 1`
	echo '	PASSED'
else
	failed=`expr $failed + 1`
	echo '	FAILED'
fi
rm -rf __test${x}/
sleep 0.1
# ========================================================================== #
echo 'Test 1'
 
rm -f child1.stderr
rm -f child1.stdout

$GUARDIAN child1 1 2 3 4 5 &
sleep 1
killall -SIGINT $GUARDIAN
sleep 1
my_check 1
# ========================================================================== #

for i in `seq 2 3`
do
	echo "Test $i"
	rm -f child${i}.stderr
	rm -f child${i}.stdout
	sleep 0.1
	$GUARDIAN child${i}
	sleep 1
	sleep 1
	killall -SIGINT guardian
	sleep 1
	sleep 1
	my_check ${i}
done
# ========================================================================== #
echo 'Test 4'
rm -f "child4.stderr"
rm -f "child4.stdout"
$GUARDIAN child4
sleep 1

my_send_signal SIGCONT
my_send_signal SIGSEGV
my_send_signal SIGCONT
my_send_signal SIGSEGV
my_send_signal SIGCONT
my_send_signal SIGSEGV
my_send_signal SIGINT

my_check 4

# ========================================================================== #
echo 'Test 5'
rm -f "child5.stderr"
rm -f "child5.stdout"
$GUARDIAN child5 2&> ${CHILD_DOES_NOT_EXIT}
sleep 1
diff ${CHILD_DOES_NOT_EXIT} linux_ref/${CHILD_DOES_NOT_EXIT}
if [ $? -eq 0 ]
then
	passed=`expr $passed + 1`
	echo '	PASSED'
else
	failed=`expr $failed + 1`
	echo '	FAILED'
fi

echo 'Statistics'
echo '    passed = ' $passed
echo '    failed = ' $failed
# ========================================================================== #
# END
