import sys

def factorial(n):
	num = 1
	while n >= 1:
		num = num * n
		n = n - 1
	return num

if __name__ == '__main__':
	big_number = int(sys.argv[1])

	for i in range(1,big_number+1):
		print "factorial(%d)"%(i)
		factorial(i)
