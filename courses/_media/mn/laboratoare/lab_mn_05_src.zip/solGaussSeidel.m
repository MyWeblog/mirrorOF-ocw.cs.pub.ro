function x = solGaussSeidel(A,b,x0,tol,maxiter)
	% Rezolvare sistem cu Gauss-Seidel
	% Intrari:
	%		A - matricea sistemului
	%		b - vectorul termenilor liberi
	%		x0 - aproximatia intiala a solutiei
	%		tol - precizia determinarii solutiei
	%		maxiter - numarul maxim de iteratii permis
	% Iesiri:
	%		x - solutia sistemului

	% code goes here

endfunction
