ind = find(M > 4);
M(ind)=-M(ind);