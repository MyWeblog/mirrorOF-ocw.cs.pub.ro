x = [2 3 4 1 -20];
suma = 0;
for var = x
    suma = suma + var;
endfor
disp('Media este')
disp(suma / length(x))