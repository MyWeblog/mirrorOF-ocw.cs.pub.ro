V = 'Sunt    multe   spatii   albe   in acest   text.';
ind = findstr(V,' ');
V(ind) = []