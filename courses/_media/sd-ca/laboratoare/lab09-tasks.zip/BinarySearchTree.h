#ifndef __BINARY_SEARCH_TREE__H
#define __BINARY_SEARCH_TREE__H

#include <iostream> 
 
template <typename T>
class BinarySearchTree
{
public:
	BinarySearchTree() {
		//TODO 1.1
	}
	~BinarySearchTree() {
		//TODO 1.2
	}
	
	bool isEmpty() {
		return (pData == NULL);
	}
 
	void insertKey(T x) {
		//TODO 1.3
	}
	
	BinarySearchTree<T>* searchKey(T x) {
		//TODO 1.4
		return NULL;
	}
	
	void inOrderDisplay() {
		//TODO 1.5
	}
	
	T findMin() {
		//TODO 2.1
		return T();
	}
	
	T findMax() {
		//TODO 2.1
		return T();
	}
	
	int findLevels() {
		//TODO 2.2
		return 0;
	}
	
	void displayLevel(int level) {
		//TODO 2.3
	}
	
	void displaySumDescOrder(T sum = T()) {
		//TODO 3
	}
	
	BinarySearchTree<T>* removeKey(T x) {
		//TODO 4
		return this;
	}
 
private:
	BinarySearchTree<T> *leftNode;
	BinarySearchTree<T> *rightNode;
	BinarySearchTree<T> *parent;
	T *pData;
};
 
#endif // __BINARY_SEARCH_TREE_H

