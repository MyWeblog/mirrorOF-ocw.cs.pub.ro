/**
  * Autor: Victor Carbune
  * Echipa SD, 2012
  *
  * License: LGPL
  */

#include <iostream>
#include <cstring>

#include "BinaryTree.h"
#include "ExpressionNode.h"

#define MAX 1000

using namespace std;

/************ Pentru debugging, puteti decomenta linia urmatoare ************/
//#define DEBUG 1

/** Helper functions. */
bool isExpression(const char *input)
{
	return (strchr(input, '|') != NULL);
}

bool isTerm(const char *input)
{
	return (!isExpression(input) && strchr(input, '&') != NULL);
}

bool isLiteral(const char *input)
{
	return (!isExpression(input) && !isTerm(input));
}

BinaryTree<ExpressionNode> *parseLiteral(const char *inputLiteral)
{
	BinaryTree<ExpressionNode> *node;
	ExpressionNode nodeData;

#ifdef DEBUG
	cout<<"ParseLiteral: "<<inputLiteral<<endl;
#endif

	// Update node data
	nodeData.isOperator = false;
	strcpy(nodeData.value, inputLiteral);

	node = new BinaryTree<ExpressionNode>();
	node->setData(nodeData);

	return node;
}

BinaryTree<ExpressionNode> *parseTerm(char *inputTerm)
{
	BinaryTree<ExpressionNode> *node;
	ExpressionNode nodeData;

	// Save the value in a local variable
	char localString[MAX];
	memset(localString, 0, MAX);
	strcpy(localString, inputTerm);

	if (strlen(localString) == 0)
	return NULL;

#ifdef DEBUG
	cout<<"ParseTerm: "<<inputTerm<<endl;
#endif

	// Initialize the node data
	nodeData.isOperator = true;
	strcpy(nodeData.value, "&");

	// Tokenize the input
	char *literal = strtok(localString, "&");

	// Initialize the tree node
	node = new BinaryTree<ExpressionNode>();

	// Set the data of the current node
	node->setData(nodeData);

	// Parse the left subtree
	node->setLeftSubtree(parseLiteral(literal));

	// Parse the right subtree
	char *newString = localString + strlen(literal) + 1;
	if (isLiteral(newString))
		node->setRightSubtree(parseLiteral(newString));
	else
		node->setRightSubtree(parseTerm(newString));

	return node;
}

BinaryTree<ExpressionNode> *parseExpression(char *inputExpr)
{
	BinaryTree<ExpressionNode> *node;
	ExpressionNode nodeData;

	// Work on a local string
	char localString[MAX];
	memset(localString, 0, MAX);
	strcpy(localString, inputExpr);

	if (strlen(localString) == 0)
		return NULL;

#ifdef DEBUG
	cout<<"ParseExpression: "<<inputExpr<<endl;
#endif

	// Initialize the node data
	nodeData.isOperator = true;
	strcpy(nodeData.value, "|");

	// Tokenize the input
	char *term = strtok(localString, "|");

	// Initialize the tree node
	node = new BinaryTree<ExpressionNode>();

	// Set the data of the node
	node->setData(nodeData);

	// Parse the left subtree
	if (isLiteral(term))
		node->setLeftSubtree(parseLiteral(term));
	else
		node->setLeftSubtree(parseTerm(term));

	// Parse the right subtree
	char *newString = localString + strlen(term) + 1;
	if (isExpression(newString)) {
		node->setRightSubtree(parseExpression(newString));
		return node;
	}

	if (isTerm(newString)) {
		node->setRightSubtree(parseTerm(newString));
		return node;
	}

	node->setRightSubtree(parseLiteral(newString));

	return node;
}

bool getValue(ExpressionNode nodeData)
{
	char *token;

	// Check for negation
	if ((token = strchr(nodeData.value, '!')) != NULL)
		return !(atoi(token + 1));

	return atoi(nodeData.value);
}

bool applyOperator(const char *op, bool left, bool right)
{
	// Return the logical value of the expression after applying the
	// right operator on both operands
	return (!strcmp(op, "&")) ? (left && right) : (left || right);
}

bool evaluateAST(BinaryTree<ExpressionNode> *root)
{
	// The node is a leaf -> stores a value
	if (root->getLeftSubtree() == NULL && root->getRightSubtree() == NULL)
		return getValue(root->getData());

	// Otherwise -> stores an operator, so we evaluate recursively
	return applyOperator(root->getData().value,
			     evaluateAST(root->getLeftSubtree()),
			     evaluateAST(root->getRightSubtree()));
}

int main()
{
	char inputExpr[MAX];
	BinaryTree<ExpressionNode> *root = NULL;

	// Read one line from the input
	cin.getline(inputExpr, MAX);

	// Parse the expression and store the root node
	root = isExpression(inputExpr) ? parseExpression(inputExpr) :
	       (isTerm(inputExpr) ? parseTerm(inputExpr) :
	       parseLiteral(inputExpr));

	// Debug the root node. The output should match the initial expression
	// root->displayTree(0);

	cout<<"The result of the expression is: "<<evaluateAST(root)<<endl;

	// The bonus is yours (It is not relevant, moreover I think that
	// you already solved all Hashtables' mysteries)

	delete root;

	return 0;
}
