#include <iostream>
#include "String.h"
#include "hashtable.h"

unsigned int hash(String s) {
    // TODO 2: use hash function from lab's content.
}

int main() {
    // TODO 3: solve problem.

    return 0;
}