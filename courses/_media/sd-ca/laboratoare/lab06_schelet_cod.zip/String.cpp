#include "String.h"

String::String() {
    // TODO 1: Initialise.
}

String::String(const char *p) {
    // TODO 1: Allocate necessary memory and copy the content. 
}

String::~String() {
    // TODO 1: Delete allocated memory.
}

bool String::operator==(const String &p) {
    // TODO 1: Define the operator
}

bool String::operator=(const String &p) {
    // TODO 1: Define the operator
}
