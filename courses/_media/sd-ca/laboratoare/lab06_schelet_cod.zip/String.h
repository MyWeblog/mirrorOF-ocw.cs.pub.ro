#ifndef __STRING_H_
#define __STRING_H_

class String{
public:
    char *s;
public:
    String();
    
    String(const char*);

    ~String();

    bool operator==(const String&);

    bool operator=(const String&);

    friend unsigned int hash(String p);
};

#endif
