#include <vector>
#include <iostream>
#include <iterator>  
#include <limits.h>
#include <stack>
#include <algorithm>
#include "graph.h"

NodeInfo::NodeInfo()
{
	color=WHITE;
	dist=INT_MAX;
	tDesc=0;
	tFin=0;
	nNodeIndex=-1;
}

std::ostream& operator<<(std::ostream& out,Node& node)
{
	for (std::vector<int>::iterator it=node.neigh.begin();it!=node.neigh.end();it++)
		out<<*it<<" ";	
	
	//secventa poate fi rescrisa:
	/*
	std::ostream_iterator<int> out_it(out," ");
	std::copy(node.neigh.begin(),node.neigh.end(),out_it);
	*/
	
	
	out<<std::endl;
	return out;
	
}


Graph::Graph(int n)
{
	this->n=n;
	nodes=new Node[n];
}


Graph::~Graph()
{
	delete [] nodes;
}

void Graph::addEdge(int u,int v,EDGE_DIRECTION dir)
{
	//TODO1.2
}


void Graph::bfs(int node)
{
	std::vector<NodeInfo> nodeInfos(n);

		
	std::cout<<"BFS Traversing from node "<<node<<std::endl;
	
	
	//TODO1.3
	
	
	std::cout<<std::endl;		
}


void Graph::dfs(int node)
{
	std::vector<NodeInfo> nodeInfos(n);

		
	std::cout<<"DFS Traversing from node "<<node<<std::endl;
	
	
	//TODO1.4
	
	
	std::cout<<std::endl;
}

void Graph::sortNeigh()
{
	for (int i=0;i<n;i++)
	   std::sort(nodes[i].neigh.begin(),nodes[i].neigh.end());
}


void Graph::printPretty()
{
	std::cout<<"Print graph:"<<std::endl;
	for (int i=0;i<n;i++)
		std::cout<<i<<"->"<<nodes[i];
}

bool Graph::isBipartite()
{
	std::vector<NodeInfo> nodeInfos(n);
		
	//TODO 2.1

	return false;
}

void Graph::sortTopological(int node)
{
	std::vector<NodeInfo> nodeInfos(n);
	for (unsigned int i=0;i<nodeInfos.size();i++)
		nodeInfos[i].nNodeIndex=i;
	
	
	//TODO3.1
	
	std::cout<<"The order is: "<<node<<std::endl;
	
	
	std::cout<<std::endl;
}
