#include "maze.h"
#include <queue>
#include <limits.h>

using namespace std;

#define INF 2345
static int dx[4] = {-1, 0, 1, 0};
static int dy[4] = {0, -1, 0, 1};

static Maze* maze;

void findDistance(int x, int y)
{
	// alocare si initializare matrice de distante
	int** dist = new int*[maze->get_height()];
	for (int i = 0; i < maze->get_height(); i++) 
	{
		dist[i] = new int[maze->get_width()];
		for (int j = 0; j < maze->get_width(); j++)
			dist[i][j] = INT_MAX;
	}
	dist[x][y] = 0;
	
	//declarare si initializare coada
	queue<pair<int, int> > q;
	q.push(make_pair(x, y));

	//TODO: completati findDistance

	// afisare matrice distanta
	for (int i = 0; i < maze->get_height(); i++) 
	{
		for (int j = 0; j < maze->get_width(); j++)
			if (dist[i][j] == INT_MAX)
				cout<<"#"<<" ";
			else
				cout<<dist[i][j]<<" ";
		cout<<endl;
	}
}

int main()
{
	std::ifstream in("robot.in");
	int m, n;
	in >> m >> n;

	maze = new Maze(m, n);
	in >> *maze;

	int x, y;
	in >> x >> y;
	findDistance(x, y);

	delete maze;
	return 0;
}
