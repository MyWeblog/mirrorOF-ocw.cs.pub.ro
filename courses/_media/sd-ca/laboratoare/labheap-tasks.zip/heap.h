#ifndef HEAP_H
#define HEAP_H

#include<iostream>
 
template <typename T>
class Heap
{ 
private:
    T* values;
    int dimVect;
    int capVect;
public:
    Heap(int capVect);
    ~Heap();
 
    int parent(int poz);
 
    int leftSubtree(int poz);
 
    int rightSubtree(int poz);
 
    void pushUp(int poz);
 
    void pushDown(int poz);
 
    void insert(T x);
 
    T peek();
 
    T extractMin();
};



template <typename T>
Heap<T>::Heap(int capVect)
{
    // TODO 1.1
}

template <typename T>
Heap<T>::~Heap()
{
    // TODO 1.2
}

/* TODO Exercitiul 2 */

template <typename T>
int Heap<T>::parent(int poz)
{
    // TODO 2.1
}

template <typename T>
int Heap<T>::leftSubtree(int poz)
{
    // TODO 2.1
}

template <typename T>
int Heap<T>::rightSubtree(int poz)
{
    // TODO 2.1
}

template <typename T>
void Heap<T>::pushUp(int poz)
{
    // TODO 2.2
 
}

template <typename T>
void Heap<T>::pushDown(int poz)
{
    // TODO 2.2
 
}

/* TODO Exercitiul 3 */

template <typename T>
void Heap<T>::insert(T x)
{
    // TODO 3
}

template <typename T>
T Heap<T>::peek()
{
    // TODO 3
}

template <typename T>
T Heap<T>::extractMin()
{
    // TODO 3
}

#endif // HEAP_H
