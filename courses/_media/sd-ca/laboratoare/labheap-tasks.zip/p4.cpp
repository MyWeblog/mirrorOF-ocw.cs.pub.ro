#include<iostream>

template<class T>
void heapSort(T* array, int &n)
{
	// TODO 4
}

int main(void)
{
	int* v;
	int n;

	// TODO citire n

	// TODO alocare

	// TODO citire vector

	// sortare
	heapSort<int>(v, n);

	// Afisare
	for(int i = 0; i < n; ++i) {
		std::cout << v[i] << " ";
	}
	std::cout << std::endl;

	return 0;
}
