#include <cstdio>

#include "successor.h"

int main() {
  int n, m;

  scanf("%d%d", &n, &m);

  init(n);

  for (int i = 0; i < m; i++) {
    int c, x;

    scanf("%d%d", &c, &x);

    if (c == 0) {
      add(x);
    } else if (c == 1) {
      erase(x);
    } else if (c == 2) {
      find(x);
    } else if (c == 3) {
      next(x);
    } else if (c == 4) {
      findK(x);
    }
  }

  return 0;
}

