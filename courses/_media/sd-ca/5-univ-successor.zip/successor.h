#ifndef _SUCC_H
#define _SUCC_H

void init(int n);

void add(int x);
void erase(int x);
void find(int x);
void next(int x);
void findK(int x);

#endif

