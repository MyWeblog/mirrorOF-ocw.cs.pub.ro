#! /bin/bash

EXEC=successor
TOTAL=0

g++ -Wall main.cpp ${EXEC}.cpp -o $EXEC

TEST_DIR=tests
OUT_DIR=user_out

cd ${TEST_DIR}
TESTS=`ls *.in | sed s/.in//g`
cd -

TESTS_NO=`echo ${TESTS} | wc -w`
MAX_POINTS=100
POINTS_PER_TEST=$(./bc <<< "scale=3; ${MAX_POINTS}/${TESTS_NO}")
TIMEOUT=20

mkdir user_out
TEST_NO=-1

for i in ${TESTS}; do
	STATUS=PASSED
	TEST_NO=$(expr $TEST_NO + 1)

	echo -e "#${TEST_NO} Testing ${i}:\n"


	# This command is pretty mangled. What it does is basically
	# time (command A; command B)
	#	command A -> timeout X exec_test
	#	command B -> store RET_VAL of the timeout to see if there
	#			   to check afterwards
	# The rest of the command is just extracting the 'time' output
	# and saving it

	{ time (timeout ${TIMEOUT} ./${EXEC} <${TEST_DIR}/${i}.in > ${OUT_DIR}/${i}.out; echo $? > RET_VAL); } 2>&1 | cut -f2 -d m | cut -f 1 -d s | sed -n '2p' > ${OUT_DIR}/${i}.time; 

	if [ "`cat RET_VAL`" != '0' ]; then
		echo "TIME OUT"
		STATUS=FAILED

	else
		diff -wiB ${TEST_DIR}/${i}.ok ${OUT_DIR}/${i}.out > diffs

		if [ $? != 0 ]; then
			cat diffs | head -n 20

			echo -e "File truncated!"
			echo -e "Differences were found!\n"
			STATUS=FAILED

		else
			echo -e "Output                               ... OK!\n"
			echo -e "Time:"

			OWN=`cat ${OUT_DIR}/${i}.time`
			REF=`cat ${TEST_DIR}/${i}.time`
			echo -e "[own]: ${OWN}"
			echo -e "[ref]: ${REF}\n"

		fi
	fi


	if [ ${STATUS} == "PASSED" ]; then

		echo -e "Test                               ... PASS!\n"
		TOTAL=$(./bc <<< "scale=3; ${TOTAL} + ${POINTS_PER_TEST}" )

	else
		echo -e "Test                              ... FAILED\n"
	fi
done

echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "TOTAL: $TOTAL/${MAX_POINTS} puncte"

rm -rf diffs ${OUT_DIR}/* RET_VAL
rmdir ${OUT_DIR}
