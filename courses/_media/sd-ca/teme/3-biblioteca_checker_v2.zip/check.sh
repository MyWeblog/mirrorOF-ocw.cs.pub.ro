#!/bin/bash

# Checher tema 3 SD 2014 - Biblioteca

NO_TESTS=9
EXEC=tema3
TEST_POINTS=10
# TODO
TIMEOUT_TIME=(0 1 1 1 1 8 23 8 17 3)
TOTAL=0

# BONUS PART, run tests 5,6,7,8 with better times.
#BONUS_TIME=(3.5 12.5 3.2 10.2)
# Rounded these because timeout does not accept floats.
BONUS_TIME=(4 13 4 11 10)

BONUS_FILE=(5 6 7 8 9)
BONUS_TEST_POINTS=2
NO_BONUS_TESTS=5

timeout_test()
{
	test_no=$1
        timeout=$2

	# Get the input and ref files for the current test
        input_path="tests/in/test"$test_no".in"
        ref_path="tests/out/test"$test_no".out"

	(time timeout $timeout ./$EXEC <$input_path >out.txt) 2>time.err
	TEST_RESULT=$?
}

valgrind_test()
{
	test_no=$1
	# Get the input and ref files for the current test
	timeout=$2
    input_path="tests/in/test"$test_no".in"
    ref_path="tests/out/test"$test_no".out"

	(time timeout $timeout valgrind --leak-check=full --error-exitcode=1 -q ./$EXEC <$input_path >out.txt) 2>time.err
	TEST_RESULT=$?
}


# Check a single test and add the result to the total score. This function
# should _always_ receive a test number as the first and only argument
check_test()
{
    test_no=$1
    test_timeout=$2
    test_points=$3

    echo
    echo -n "Test: $test_no ...................... "

	if [ "$test_no" == "9" ]; then
		valgrind_test $test_no $test_timeout
	else
		timeout_test $test_no  $test_timeout
	fi

    # Run the test, also consider the timeout
    if [ "$TEST_RESULT" == "124" ]; then
        echo "TIMEOUT [$timeout s]"
        rm -f out.txt
        rm -f time.err
		return
    elif [ "$test_no" == "9" -a "$TEST_RESULT" != "0" ]; then
		echo "DETECTED MEMORY LEAKS"
		tail -n 10 time.err
        rm -f out.txt
        rm -f time.err
		return
	fi

    # Check the result
    diff -bB -i $ref_path out.txt 2>&1 1> my_diff
    if test $? -eq 0; then
        echo "PASS"
		if [ -f time.err  ]; then
			cat time.err
		fi
        # Compute like so because $test_points may be 2.5 for bonus and
        # $(($a+$b)) does not know how to deal with floating numbers.
        TOTAL=$(($TOTAL + $test_points))
    else
        echo "FAILED"
        echo "Diff result:"
        cat time.err
        cat my_diff | tail -n 10
    fi

    # Clean up
    rm -f my_diff
    rm -f out.txt
    rm -f time.err
}

calc_decimal ()
{
    $(echo "scale=9; $1" | bc)
}


# Check if the the exec exist
if test ! -x $EXEC; then
    echo "File Missing"
    exit 1
fi


if [[ $1 =~ [1-9] ]]; then
	check_test $1 ${TIMEOUT_TIME[$i]} $TEST_POINTS
else
	for ((i=1;i<=$NO_TESTS;i++))
	do
		check_test $i ${TIMEOUT_TIME[$i]} $TEST_POINTS
	done

        echo ""
        echo "BONUS POINTS [$(($NO_BONUS_TESTS * $BONUS_TEST_POINTS))p]: Re-running some tests with tighter timeouts."
        echo ""

        # also run bonus
	for ((i=0;i<$NO_BONUS_TESTS;i++))
	do
		check_test ${BONUS_FILE[$i]} ${BONUS_TIME[$i]} $BONUS_TEST_POINTS
	done
fi

# And the restul is ...
echo "TOTAL: $TOTAL/$(($TEST_POINTS * $NO_TESTS + $NO_BONUS_TESTS * $BONUS_TEST_POINTS))"
