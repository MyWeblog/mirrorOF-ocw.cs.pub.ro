#!/bin/bash

tests="01_tesla.txt  02_linux.bmp  03_wallpaper.bmp  04_Fur_Elise.wav small.txt"
score=0

for test_file in $tests; do
    cp tests/$test_file .
    timeout 100 ./comp -c $test_file &>/dev/null
    if test $? -eq 0; then
        to=0
    else
        to=1;
    fi
    diff $test_file\.cmp ref/$test_file\.cmp &>/dev/null
    if test $to -eq 0; then
    if test $? -eq 0; then
            echo "compress $test_file passed"
            ((score=$score+6))
        else
            echo "compress $test_file failed"
        fi
        rm $test_file\.cmp
        rm $test_file
    else
        echo "compress $test_file timeout"
    fi
done

for test_file in $tests; do
    cp ref/$test_file\.cmp .
    timeout 100 ./comp -d $test_file\.cmp &>/dev/null
    if test $? -eq 0; then
        to=0
    else
        to=1;
    fi
    if test $to -eq 0; then
        diff decompressed_$test_file tests/$test_file &>/dev/null
        if test $? -eq 0; then
            echo "decompress $test_file passed"
            ((score=$score+6))
        else
            echo "decompress $test_file failed"
        fi
        rm decompressed_$test_file
        rm $test_file\.cmp
    else
        echo "decompress $test_file timeout"
    fi
done

for test_file in $tests; do
    cp tests/$test_file .
    to=0
    timeout 100 ./comp -c $test_file &>/dev/null
    if test $? -ne 0; then
        to=1;
    fi
    timeout 100 ./comp -d $test_file\.cmp &>/dev/null
    if test $? -ne 0; then
        to=1;
    fi
    if test $to -eq 0; then
        diff decompressed_$test_file tests/$test_file &>/dev/null
        if test $? -eq 0; then
            echo "compress and decompress $test_file passed"
            ((score=$score+6))
        else
            echo "compress and decompress $test_file failed"
        fi
        rm $test_file
        rm $test_file\.cmp
        rm decompressed_$test_file
    else
        echo "compress and decompress $test_file timeout"
    fi
done

cp tests/02_linux.bmp .
timeout 50 valgrind --leak-check=full -q --error-exitcode=1 ./comp -c 02_linux.bmp &>/dev/null
has_leaks=$?
timeout 50 valgrind --leak-check=full -q --error-exitcode=1 ./comp -d 02_linux.bmp.cmp &>/dev/null
((has_leaks=$has_leaks+$?))
if test $has_leaks -gt 0; then
    ((score=$score - 15))
    if test $score -lt 0; then
        score=0;
    fi
fi

rm 02_linux.bmp.cmp
rm decompressed_02_linux.bmp
rm 02_linux.bmp

if test $has_leaks -gt 0; then
    echo "Memory leaks detected!"
fi

echo "Punctaj : $score"
