/*
 * Schelet Tema 3 SD 2014 - Biblioteca
 * Autor: emil.racec@gmail.com
 */

#include <stdio.h>

#include "Algorithm.h"

int main(int argc, char* argv[])
{
	Algorithm hm3;
	hm3.resolve();
}
