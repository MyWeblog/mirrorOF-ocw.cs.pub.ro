/*
 * Schelet Tema 3 SD 2014 - Biblioteca
 * Autor: emil.racec@gmail.com
 */

#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>

#include "Algorithm.h"

Algorithm::Algorithm(void) {

}

Algorithm::~Algorithm(void) {

}

std::vector<std::string> &Algorithm::split(const std::string &s,
								char delim, std::vector<std::string> &elems) {
    std::stringstream ss(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        elems.push_back(item);
    }
    return elems;
}

void Algorithm::putBook(std::vector<std::string> &words){

	std::cout << "PUT command:" << "\n";
	/* Observati folosirea iteratorului generic c++ pe std::vector. De ce
	   este incurajata folosirea lui in comparatie cu iterarea clasica? */
	for(std::vector<std::string>::iterator it = words.begin();
			it != words.end(); ++it) {
		std::cout << *it << " ";
	}
	std::cout << "\n";
}

std::string Algorithm::getBooks(std::vector<std::string> &words) {

	std::cout << "GET command" << "\n";
	for(std::vector<std::string>::iterator it = words.begin();
			it != words.end(); ++it) {
		std::cout << *it << " ";
	}
	std::cout << "\n";

	/* returneaza rezultatul comenzii GET sub forma de std::string */
	return GET_NULL;
}


std::string Algorithm::query(std::vector<std::string> &words) {

	std::cout << "PLAY command" << "\n";
	for(std::vector<std::string>::iterator it = words.begin();
			it != words.end(); ++it) {
		std::cout << *it << " ";
	}
	std::cout << "\n";

	/* returneaza QUERY_TRUE respectiv QUERY_FALSE corespunzator */
	return QUERY_TRUE;
}

void Algorithm::resolve() {

    std::string inputLine;
	while ( std::cin.good() )
	{
		std::getline(std::cin, inputLine);

		std::vector<std::string> words;
    	split(inputLine, ' ', words);

		if (words.size() == 0) {
			continue;
		}

		/* TODO: stergeti asta dupa ce raspundeti corect la intrebare :)
		   Observati folosirea operatorului '==' in comparatia a doua siruri
		   de caractere reprezentate ca std::string. De ce este posibil acest
		   lucru? */
		if (words[0] == PUT)
			putBook(words);
		else if (words[0] == GET)
			std::cout << getBooks(words) << "\n";
		else if (words[0] == QUERY)
			std::cout << query(words) << "\n";
		else
			std::cerr << "Invalid option" << "\n";
	}
}
