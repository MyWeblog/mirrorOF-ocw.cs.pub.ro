#!/bin/bash

make clean
make build

mkdir output &> /dev/null

no_tests=27

for i in $(seq 1 $(($no_tests))); do
	./checker "input/test"$i".in" "output/test"$i".out" > /dev/null
done

grade=0
for i in $(seq 1 $(($no_tests))); do
	if [[ -z $(diff "output/test"$i".out" "ref/test"$i".ref") ]]; then 
		grade=$(($grade+1));
		echo ""
		echo "test"$i"............. OK"
	else
		echo ""
		echo "test"$i"............. X"
		diff "output/test"$i".out" "ref/test"$i".ref"
	fi
done

echo ""
echo "GRADE.................................$((grade))/$((no_tests))";
