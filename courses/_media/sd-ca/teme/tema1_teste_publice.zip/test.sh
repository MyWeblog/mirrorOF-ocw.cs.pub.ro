#!/bin/bash

make clean
make build

mkdir output

no_tests=10

for i in $(seq 1 $(($no_tests))); do
	./tema1 "input/test"$i".in" &> "output/test"$i".out"
done

grade=0
for i in $(seq 1 $(($no_tests))); do
	if [[ -z $(diff "output/test"$i".out" "ref/test"$i".ref") ]]; then 
		grade=$(($grade+10));
		echo "test"$i".............$(tput setaf 2)10$(tput sgr0)"
	else
		echo "test"$i"............. $(tput setaf 1)0$(tput sgr0)"
		diff "output/test"$i".out" "ref/test"$i".ref"
	fi
done


# valgrind
no_leaks=0;
for file in input/*; do
	valgrind -q --leak-check=full --log-file=a.out ./tema1 $file > /dev/null; 
	if [[ -z $(cat a.out) ]]; then
		no_leaks=$(($no_leaks+1));
	fi
rm -rf a.out
done

if [ $no_leaks -eq $no_tests ]; then	
	grade=$(($grade+10));
else 
	echo "Homework has leaks => no bonus :(";
fi

#end valgrind

echo ""
if [ $grade -ge 100 ]; then
	echo "GRADE.................................$(tput setaf 2)$grade$(tput sgr0)";
elif [ $grade -eq 0 ]; then 
	echo "GRADE.................................$(tput setaf 1)$grade$(tput sgr0)";
else
	echo "GRADE.................................$grade";
fi;
