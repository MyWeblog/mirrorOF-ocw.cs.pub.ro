#include "graph.h"
#include <fstream>
#include <iostream>

using namespace std;


int main()
{
	std::ifstream in("graf.in");
	int n,m,nNodeStartBfs,nNodeStartDfs;

	in >> n >> m;
	in >> nNodeStartBfs >> nNodeStartDfs;

	Graph g(n);
	// citire muchii
	for (int i = 0; i < m; i++)
	{
		int u, v;
		in >> u >> v;
		g.addEdge(u,v,BIDIRECTIONAL);
	}
	in.close();

	//sortam vecinii nodurilor in ordine crescatoare
	g.sortNeigh();
	g.printPretty();

	// apelare BFS
	g.bfs(nNodeStartBfs);

	// apelare DFS
	g.dfs(nNodeStartBfs);

	return 0;
}
