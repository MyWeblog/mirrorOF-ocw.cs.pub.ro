#ifndef __BINARY_SEARCH_TREE__H
#define __BINARY_SEARCH_TREE__H

#include <iostream>

template <typename T>
class BinarySearchTree
{
private:
  BinarySearchTree<T> *leftNode;
  BinarySearchTree<T> *rightNode;
  BinarySearchTree<T> *parent;
  T *pData;

public:
	BinarySearchTree() {
		//TODO 1
	}
	~BinarySearchTree() {
		//TODO 2
	}

	bool isEmpty() {
		return (pData == NULL);
	}

	void insertKey(T x) {
		//TODO 3
	}

	BinarySearchTree<T>* searchKey(T x) {
		//TODO 4
		return NULL;
	}

	void inOrderDisplay() {
		//TODO 5
	}

	BinarySearchTree<T>* removeKey(T x) {
		//TODO 6
		return this;
	}


};

#endif // __BINARY_SEARCH_TREE_H
