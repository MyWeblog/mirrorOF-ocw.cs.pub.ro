#include <openssl/sha.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>

/* We want a collision in the first 4 bytes = 2^16 attempts */
#define N_BITS  16

int raw2int4(unsigned char * digest) {
    int i;
    int sum = 0;

    for (i = 0; i < 3; i++) {
        sum += sum * 256 + digest[i];
    }

    return sum;
}

void hexdump(unsigned char * string, int length) {
    int i;
    for (i = 0; i < length; i++) {
        printf("%02x", string[i]);
    }
}

int main(int argc, char * argv[]) {
    uint32_t attempt;     /* Iterate through 16 bits of the 32; use the rest to run different attacks */
    unsigned char md[20]; /* SHA-1 outputs 160-bit digests */

    /* Try to find a collision on the first 4 bytes (32 bits) */

    /* Step 1. Generate 2^16 different random messages */

    /* Step 2. Compute hashes */

    /* Step 3. Check if there exist two hashes that match in the first four bytes */

    /* Step 3a. If a match is found, print the messages and hashes */

    /* Step 3b. If no match is found, repeat the attack with a new set of random messages */

    return 0;
}
