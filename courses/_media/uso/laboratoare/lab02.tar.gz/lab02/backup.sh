#!/bin/bash

zip -r facultate.zip facultate/
mv facultate.zip ~/backupdir/
