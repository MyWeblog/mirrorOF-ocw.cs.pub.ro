
#include <stdio.h>

#define _MAX_N 8


int sol[_MAX_N], used[_MAX_N + 1], n;

void print_solution()
{
    int i;

    for (i = 0; i < n; i ++) {
        printf("%d ", sol[i]);
    }
    printf("\n");
}

void bkt(int pos)
{
    int i;

    if (pos == n) {
        print_solution();
        return;
    }

    for (i = 1; i <= n; i ++) {
        if (!used[i]) {
            sol[pos] = i;
            used[i] = 1;

            bkt(pos + 1);
            used[i] = 0;
        }
    }
}

int main()
{
    printf("Please enter the number of digits for permutation:\n");
    scanf("%d", &n);
    bkt(0);

    return 0;
}
