echo $race Rush!!
