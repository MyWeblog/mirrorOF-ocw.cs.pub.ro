#!/bin/bash

ls /tmp
ls -l /tmp
file /tmp/*
ls /etc
ls -l /etc
file /etc/*
ls /home
ls -l /home
file /home/*
ls /var
ls -l /var
file /var/*
ls /var/log
ls -l /var/log
file /var/log/*
ls /dev
ls -l /dev
file /dev/*
ls /proc
ls -l /proc
file /proc/*

