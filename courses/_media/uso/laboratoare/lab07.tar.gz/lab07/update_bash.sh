#!/bin/bash

cat >> ~/.bashrc << END
#=========== Added by update_bash.sh

vi_all() {
    echo "Looking for files named *.$1"
    vi -p $(for i in `find . -name "*.$1"`; do echo -n $i " "; done)
}

alias ls_size='ls -lh | tail -n +2 | tr -s " " | cut -d" " -f5,9'
END

