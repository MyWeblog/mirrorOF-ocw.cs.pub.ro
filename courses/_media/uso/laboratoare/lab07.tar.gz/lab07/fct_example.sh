#!/bin/bash

f () {
    echo "f apelata cu" $# "argumente"
}

f 1 2 3 4
f 2
f 3

