#! /bin/bash

echo "Proces curent:" '$$ =' $$
echo

echo "Un sleep in fundal."
sleep 10 &
echo "PID proces sleep:" '$! =' $!
echo

echo "Comanda 'false' eșuează mereu."
false
echo "Rezultatul comenzii false:" '$? =' $?
echo

echo "Comanda 'true' se termină cu succes mereu."
true
echo "Rezultatul comenzii true:" '$? =' $?
echo

echo "Scriptul a primit" '$# =' $# "parametri."
echo "Lista parametrilor este" '$@ =' $@
echo "Scriptul se cheamă" '$0 =' $0
echo "Primul parametru este" '$1 =' $1
echo "Al 4-lea parametru este" '$4 =' $4
echo "Al 6-lea parametru este" '$6 =' $6
echo "Al 2-lea parametru este" '$2 =' $2

