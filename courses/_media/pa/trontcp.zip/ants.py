#!/usr/bin/env python

from random import randrange, choice, shuffle, randint, seed, random
from math import sqrt
from collections import deque, defaultdict

from fractions import Fraction
import operator
from game import Game
from copy import deepcopy
try:
    from sys import maxint
except ImportError:
    from sys import maxsize as maxint

# possible directions of movement
AIM = {'UP': (-1, 0),
       'RIGHT': (0, 1),
       'LEFT': (0, -1),
       'DOWN': (1, 0)}

class Ants(Game):
    def __init__(self, options=None):
        # setup options
        map_text = options['map']
        self.turntime = int(options['turntime'])

        map_data = self.parse_map(map_text)

        self.turn = 0
        self.num_players = map_data['num_players']
        self.killed = [False for _ in range(self.num_players)]

        # initialize size
        self.rows, self.cols = map_data['rows'], map_data['cols']

        # initialize map
        self.map = map_data['map']
        self.starters = map_data['starters']
        self.map[self.starters[0][0]][self.starters[0][1]] = 'r'
        self.map[self.starters[1][0]][self.starters[1][1]] = 'g'

        # the engine may kill players before the game starts and this is needed to prevent errors
        self.orders = [[] for i in range(self.num_players)]

    def parse_map(self, map_text):
        """ Parse the map_text into a more friendly data structure """
        starters = []
        cols = None
        rows = None
        num_players = None
        lines = []

        for line in map_text.split('\n'):
            line = line.strip()

            if not line.startswith('#'):
                num_players = int(line.split()[0])
                rows = int(line.split()[1])
                cols = int(line.split()[2])
                r1 = int(line.split()[3])
                c1 = int(line.split()[4])
                r2 = int(line.split()[5])
                c2 = int(line.split()[6])
                starters = [[r1, c1], [r2, c2]]
            else:
                lines.append(list(line))

        return {
            'rows':        rows,
            'num_players': num_players,
            'cols':        cols,
            'map':         lines,
            'starters':    starters,
        }

    def do_orders(self):
        bnewx = -1
        bnewy = -1
        for i,move in enumerate(self.orders):
            if not self.is_alive(i):
                continue
            x = self.starters[i][0]
            y = self.starters[i][1]
            color = 'r' if i == 0 else 'g'
            newx = x + AIM[move][0]
            newy = y + AIM[move][1]
            if self.map[newx][newy] == '-':
                self.map[newx][newy] = color
                self.starters[i][0] = newx
                self.starters[i][1] = newy
            else:
                self.killed[i] = True
            if (bnewx, bnewy) == (newx, newy):
                self.killed[0] = True
                self.map[newx][newy] = 'X'
            bnewx = newx
            bnewy = newy

    def remaining_players(self):
        """ Return the players still alive """
        return [p for p in range(self.num_players) if self.is_alive(p)]

    def game_over(self):
        if len(self.remaining_players()) < 1:
            return True
        if len(self.remaining_players()) == 1:
            return True
        return False

    def kill_player(self, player):
        """ Used by engine to signal that a player is out of the game """
        self.killed[player] = True

    def start_game(self):
        pass

    def finish_game(self):
        pass

    def start_turn(self):
        """ Called by engine at the start of the turn """
        self.turn += 1
        self.orders = [None for _ in range(self.num_players)]

    def finish_turn(self):
        """ Called by engine at the end of the turn """
        self.do_orders()

    def get_player_state(self, player):    
        state = 'r' if player == 0 else 'g'
        state += '\n'
        state += str(self.starters[0][0]) + ' ' + str(self.starters[0][1]) + ' ' + str(self.starters[1][0]) + ' ' + str(self.starters[1][1]) + '\n'
        state += str(self.rows) + ' ' + str(self.cols) + '\n'
        for row in range(self.rows):
            for col in range(self.cols):
                state += self.map[row][col]
            state += '\n'
        return state

    def is_alive(self, player):
        return not self.killed[player]

    def do_moves(self, player, moves):
        self.orders[player] = moves
