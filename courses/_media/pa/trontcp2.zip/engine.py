#!/usr/bin/env python
#~ from __future__ import print_function
import time
import traceback
import os
import random
import sys
import json
import io
if sys.version_info >= (3,):
    def unicode(s):
        return s

import logging

def run_game(game, bots, options):
    turntime = float(options['turntime']) / 1000
    location = options.get('location', 'localhost')
    game_id = options.get('game_id', 0)

    error = ''

    try:
        #~ # create bot sandboxes
        for b, bot in enumerate(bots):
            # ensure it started
            if not bot.sock:
                if verbose_log:
                    verbose_log.write('bot %s did not start\n' % b)
                print('ERR : bot %s did not start\n' % b)
                game.kill_player(b)

        for turn in range(10000000):
            #~ print turn, bots
            if turn == 0:
                game.start_game()
            else:
                game.start_turn()

            # send game state to each player
            for b, bot in enumerate(bots):
                state = game.get_player_state(b)
                state += 'go\n'
                bot.write(state)

            # get moves from each player
            time_limit = turntime

            simul_num = len(bots)

            bot_moves = [[] for b in bots]
            bot_list = [(b, bot) for b, bot in enumerate(bots)]
            random.shuffle(bot_list)
            for group_num in range(0, len(bot_list), simul_num):
                pnums, pbots = zip(*bot_list[group_num:group_num + simul_num])
                moves = get_moves(game, pbots, pnums, time_limit)
                for p, b in enumerate(pnums):
                    bot_moves[b] = moves[p]
            # process all moves
            bot_alive = [game.is_alive(b) for b in range(len(bots))]
            if not game.game_over():
                for b, moves in enumerate(bot_moves):
                    if game.is_alive(b):
                        game.do_moves(b, moves)
            if not game.game_over():
                game.finish_turn()
            if game.game_over():
                if game.is_alive(0) and not game.is_alive(1):
                    result = "red won"
                elif game.is_alive(1) and not game.is_alive(0):
                    result = "green won"
                else:
                    result = "tie"
                for b in bots:
                    state = game.get_player_state(b)
                    state += 'end %s\n' % result
                    b.write(state)
                for b in bots:
                    b.kill()
                break
        game.finish_game()

    except Exception as e:
        error = traceback.format_exc()
        print error
    finally:
        for bot in bots:
            if bot.is_alive:
                bot.kill()
            bot.release()

def get_moves(game, bots, bot_nums, time_limit):
    bot_finished = [False for b in range(len(bots))]
    bot_moves = [[] for b in bots]
    start_time = time.time()

    # resume all bots
    for bot in bots:
        if bot.is_alive:
            bot.resume()

    # loop until received all bots send moves or are dead
    #   or when time is up
    while (sum(bot_finished) < len(bot_finished) and
            time.time() - start_time < time_limit):
        time.sleep(0.01)
        for b, bot in enumerate(bots):
            if bot_finished[b]:
                continue # already got bot moves
            if not bot.is_alive:
                game.kill_player(bot_nums[b])
                continue # bot is dead

            # read a maximum of 100 lines per iteration
            for x in range(100):
                line = bot.read_line()
                if line is None:
                    # stil waiting for more data
                    break
                line = line.strip()
                bot_finished[b] = True
                bot_moves[b] = line

            for x in range(100):
                line = bot.read_error()
                if line is None:
                    break
    # pause all bots again
    for bot in bots:
        if bot.is_alive:
            bot.pause()

    # kill timed out bots
    for b, finished in enumerate(bot_finished):
        if not finished:
            bot = bots[b]
            for x in range(100):
                line = bot.read_error()
                if line is None:
                    break
            game.kill_player(bot_nums[b])
            bots[b].kill()

    return bot_moves
