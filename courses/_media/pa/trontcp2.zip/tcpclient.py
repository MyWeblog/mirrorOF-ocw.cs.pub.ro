#!/usr/bin/env python

import time
import sys
import threading
import re
import string
import random
import subprocess
from socket import socket, AF_INET, SOCK_STREAM

try:
    from io import BytesIO
except ImportError:
    from StringIO import StringIO as BytesIO

USAGE="""

    tcpclient.py   host_or_ip  port  botpath  player_nick [num_rounds]

    if running on windows or if the botpath contains spaces,
    you have to wrap it with "", eg.: "java /x/y/MyBot", "e:\\ai\\bots\\mybot.exe"

    player_nick may only contain ascii_letters, '_', and numbers

"""


def readline(sock):
    s = BytesIO()
    while sock:
        c = sock.recv(1)
        if not c:
            break
        elif c==b'\r':
            continue
        elif c==b'\n':
            break
        else:
            s.write(c)
    return s.getvalue()


def tcp(host, port, bot_command, user):
    # Start up the network connection
    sock = socket(AF_INET, SOCK_STREAM)
    sock.settimeout(240)
    sock.connect((host, port))
    if sock:
        sys.stderr.write('\n\nconnected to %s:%d as %s\n' % (host,port,user))
    else:
        sys.stderr.write('\n\nfailed to connect to %s:%d as %s\n' % (host,port,user))
        return

    # send greetz
    sock.sendall(('USER %s\n' % (user)).encode('utf-8'))

    # start bot
    while True:
        input = ''

        finish = False
        # get input, send it to bot
        while sock:            
            try:
                line = readline(sock)
            except:
                break

            if not line:
                continue # bad connection, keep on trying

            if line.startswith(b'INFO'):
                print(line.decode('ascii', 'replace'))
                continue
            if line.startswith(b'go'):
                break
            print(line.decode('ascii', 'replace'))                
            input += line.decode('ascii', 'replace') + '\n'

            if line.startswith(b'end'):
                finish = True
                break

        if finish or not sock:
            break
        bot = subprocess.Popen(
            bot_command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            shell=True,
        )
        c = input.encode('ascii', 'replace')
        if not finish:
            try:
                bot.stdin.write(c)
                bot.stdin.flush()
            except:
                # if they are not reading, let them not read
                pass



        # get bot output, send to serv
        answer = bot.stdout.readline()
        # if there's no orders, send at least an empty line
        if not answer:
            answer = b'\r\n'
        print(answer.decode('ascii', 'replace'))
        sock.sendall(answer)

        try:
            bot.kill()
            time.sleep(0.5)
            bot.wait()
        except:
            pass

            
    try:
        bot.kill()
        time.sleep(0.5)
        bot.wait()
    except:
        pass

    try:
        sock.close()
        sock = None
    except:
        pass

def main():
    if len(sys.argv) < 5:
        print(USAGE)
        return

    host = sys.argv[1]
    port = int(sys.argv[2])
    botpath = sys.argv[3]
    pname = sys.argv[4]

    try:
        rounds = int(sys.argv[5])
    except:
        rounds = 1

    for i in range(rounds):
        tcp(host, port, botpath, pname)


if __name__ == "__main__":
    main()
