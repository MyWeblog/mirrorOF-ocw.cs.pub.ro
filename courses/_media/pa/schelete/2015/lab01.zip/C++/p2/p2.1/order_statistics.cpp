#include <iostream>
#include <fstream>
#include <vector>

#include "vector_io.h"



void qsort(std::vector<int> &v, int lower, int upper)
{
    //TODO Completati codul pentru a realiza quicksort
    
}

int find_kth_min(std::vector<int> &v, int lower, int upper, int k)
{
    // TODO Completati codul pentru a afla al k-lea minim din vectorul v
    
}

int main(void)
{
    std::ifstream f("date.in");
    std::vector<int> v1, v2;
    f >> v1;
    f >> v2;
    std::cout << "v1: " << v1 << std::endl;
    for (unsigned int i = 0; i < v1.size(); i++) {
        std::cout << "Al " << i << "-lea minim din v1 este: ";
        std::cout << find_kth_min(v1, 0, v1.size() - 1, i) << std::endl;
    }
    qsort(v1, 0, v1.size() - 1);
    qsort(v2, 0, v2.size() - 1);
    std::cout << "Vectorii sortati:\n";
    std::cout << v1 << std::endl;
    std::cout << v2 << std::endl;
    f.close();
}
