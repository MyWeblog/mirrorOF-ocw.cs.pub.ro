/**
 * Proiectarea Algoritmilor, 2014
 * Lab 10: Flux Maxim
 * Andrei Parvu, andrei.parvu@cti.pub.ro
 */

#include <iostream>
#include <vector>
#include <queue>
#include <fstream>
#include <cstring>
#include <algorithm>

#include "FlowGraph.h"

using namespace std;

const unsigned int NONE = -1;

vector<unsigned int> bfs(FlowGraph& graph,
                         unsigned int source,
                         unsigned int sink) {
  /* Ne vom folosi de vectorul de parinti pentru a spune daca un nod a fost
   * adaugat sau nu in coada. */
  vector<unsigned int> parent(graph.size(), NONE);

  deque<unsigned int> q;
  q.push_back(source);

  while (parent[sink] == NONE && q.size() > 0) {
    unsigned int node = q.front();
    q.pop_front();

    for (unsigned int i = 0; i < graph.size(); ++i) {
      if (graph[node][i] > 0 && parent[i] == NONE) {
        parent[i] = node;
        q.push_back(i);
      }
    }
  }

  /* Daca nu s-a atins destinatia, atunci nu mai exista drumuri de crestere. */
  if (parent[sink] == NONE) {
    return vector<unsigned int>();
  }

  /* Reconstituim drumul de la destinatie spre sursa. */
  vector<unsigned int> path;
  for (unsigned int node = sink; true; node = parent[node]) {
    /* TODO - Adaugati nodul la drumul curent si verificati
     * conditia de oprire */
    
  }

  /* Inversam drumul pentru a incepe cu sursa si a se termina cu destinatia. */
  reverse(path.begin(), path.end());
  return path;
}

unsigned int saturate_path(FlowGraph& graph,
                           vector<unsigned int>& path) {
  /* Niciodata nu ar trebui sa se intample asta pentru ca sursa si destinatia
   * sunt noduri distincte si cel putin unul dintre ele se afla in path. */
  if (path.size() < 2) {
    return 0;
  }

  /* Determinam fluxul maxim prin drum. */
  unsigned int flow = graph[path[0]][path[1]];
  for (unsigned int i = 0; i < path.size() - 1; ++i) {
    unsigned int u = path[i];
    unsigned int v = path[i + 1];

    /* TODO - Determinati fluxul in functie de capacitata muchiei (u, v) */
    
  }

  /* Si il saturam in graf. */
  for (unsigned int i = 0; i < path.size() - 1; ++i) {
    unsigned int u = path[i];
    unsigned int v = path[i + 1];

    /* TODO - Modificati fluxul in functie de capacitatea muchiei (u, v) */
    
  }

  /* Raportam fluxul cu care am saturat graful. */
  return flow;
}

unsigned int maximum_flow(FlowGraph &graph,
                          unsigned int source,
                          unsigned int sink) {
  unsigned int maxFlow = 0;

  /* Vom incerca in mod repetat sa determinam drumuri de crestere folosind
   * BFS si sa le saturam pana cand nu mai putem determina un astfel de drum in
   * graf. */
  while (true) {
    /* Determina drum de crestere. */
    vector<unsigned int> new_path = bfs(graph, source, sink);

    /* TODO - In functie de new_path determinati daca fluxul trebuie
     * marit sau trebuie iesit din while */
    
  }

  return maxFlow;
}

void min_cut(FlowGraph& graph,
             vector<pair<unsigned int, unsigned int> > &edge_set,
             unsigned int source) {
  /* Facem o parcurgere BFS din nodul sursa si punem nodurile atinse de
   * parcurgere in source_set. Toate celelalte noduri se vor afla in
   * sink_set. */
  vector<bool> in_queue(graph.size(), false);
  deque<unsigned int> q;
  q.push_back(source);
  in_queue[source] = true;

  /* Rulam BFS din sursa si marcam nodurile atinse. */
  while (q.size()) {
    unsigned int node = q.front();
    q.pop_front();

    for (unsigned int i = 0; i < graph.size(); ++i) {
      if (in_queue[i] == false && graph[node][i] > 0) {
          in_queue[i] = true;
          q.push_back(i);
      }
    }
  }

  /* TODO - In functie de marcajele obtinute de la BFS-ul anterior determinati
   * muchiile ce fac parte din taietura minima */

  
}

void compute_path(FlowGraph& graph,
                  unsigned int cur_node,
                  vector<vector<bool> > &used_edge,
                  vector<unsigned int> &path) {
  path.push_back(cur_node);

  /* TODO - Selctati o posibila urmatoare muchie care sa faca parte din
   * drumul curent si apelati recursiv compute_path */
  
}

void disjoint_paths(FlowGraph& graph,
                    unsigned int source,
                    vector<vector<unsigned int> > &paths) {
  vector<vector<bool> > used_edge(graph.size(),
                                  vector<bool>(graph.size(), false));

  for (unsigned int i = 0; i < graph.size(); ++i) {
    if (graph.is_saturated(source, i) && used_edge[source][i] == false) {
      vector<unsigned int> new_path;
      new_path.push_back(source);

      /* Incercam sa determinam un drum ce pleaca catre sink pe directia
       * (source, i) */
      compute_path(graph, i, used_edge, new_path);
      paths.push_back(new_path);
    }
  }
}

int main() {
  /* Deschidem fisierul de intrare si citim un graf din el. */
  ifstream pb1file("GraphBinary.in");
  FlowGraph graph;
  pb1file >> graph;
  pb1file.close();

  unsigned int source = 0;
  unsigned int sink = 12;

  /* Calculam fluxul maxim de date care poate fi suportat de retea
   * intre nodurile 0 si 12. */
  unsigned int flow = maximum_flow(graph, source, sink);

  /* Calculam si afisam o taietura minimala a grafului. */
  vector<pair<unsigned int, unsigned int> > edge_set;
  min_cut(graph, edge_set, source);
  cout << "The minimum cut associated with the flow yields:" << endl;
  for (unsigned int i = 0; i < edge_set.size(); ++i) {
    cout << edge_set[i].first << ' ' << edge_set[i].second << endl;
  }

  /* Printam un numar maximal de drumuri disjuncte intre aceleasi doua noduri
   * din graf. */
  vector<vector<unsigned int> > paths;
  disjoint_paths(graph, source, paths);

  cout << "Maximum number of disjoint paths from source to sink " << flow <<
    endl;
  cout << "A list a maximum number of disjoint paths from source to sink" <<
    endl;

  for (unsigned int i = 0; i < paths.size(); ++i) {
    cout << "Path " << i + 1 << ":";

    for (unsigned int j = 0; j < paths[i].size(); ++j) {
      cout << " " << paths[i][j];
    }
    cout << endl;
  }


  /* Deschidem un fisier din care sa incarcam restrictiile pentru problem a
   * doua. */
  ifstream pb2file("GraphDegree.in");

  unsigned int nr_nodes;
  pb2file >> nr_nodes;

  /* Vom forma urmatorul graf:
               o1       i1
               o2       i2
               .        .
     source    .        .     sink
               .        .
               on       in

    In partea stanga vom controla gradul de iesire al fiecarui nod -
    capacitatea de la source la oi va fi numarul maxim de muchii ce pot iesi
    din oi, adica exact gradul de iesire pe care acel nod il poate avea

    In partea stanga vom controla gradul de intrare al fiecarui nod -
    capacitatea de la ii la sink va fi numarul maxim de muchii ce pot intra
    in ii, adica exact gradul de intrare pe care acel nod il poate avea.

    Pompand flux maxim, vom umple capacitatile, deci vom satisface conditiile
    pentru gradele de intrare si de iesire.
  */


  /* TODO - Creati-va structura de graph cu un numar de noduri corespunzatoare */
  // FlowGraph ...
  

  for (unsigned int i = 1; i <= nr_nodes; ++i) {
    int in_degree, out_degree;

    pb2file >> in_degree >> out_degree;

    /* TODO - Adaugati muchiile corespunzatoare care sa reliefeze gradul de
     * intrare si de iesire al nodului curent */
    
  }

  for (unsigned int i = 1; i <= nr_nodes; ++i) {
    for (unsigned int j = 1; j <= nr_nodes; ++j) {
      /* TODO - Adaugati muchiile corespunzatoare intre noduri */
      
    }
  }

  /* TODO - Calculati fluxul maxim in graful creat */
  

  cout << "List of possible edges: " << endl;

  for (unsigned int i = 1; i <= nr_nodes; ++i) {
    for (unsigned int j = 1; j <= nr_nodes; ++j) {
      /* TODO - Afisati muchiile gasite in urma algoritmului de flux */
      
    }
  }

  return 0;
}
