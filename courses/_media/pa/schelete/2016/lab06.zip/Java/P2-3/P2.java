import java.util.ArrayList;
import java.util.List;

/**
 * Proiectarea Algoritmilor
 * Lab 3:  Parcurgerea Grafurilor. Sortare Topologica
 * Task 2 & 3: Planificarea studierii materiilor
 *
 * @author adinu
 * @email  mandrei.dinu@gmail.com
 *
 */

public class P2 {

	/* Use to read, parse and write the output of the problem */
	private ReaderWriter rw;

	/* Holds the final order of subjects to be studied */
	private List<Integer> solution;

	/* The graph of dependencies between subjects */
	private GraphT graph;

	public P2(String fileName) {
		rw = new ReaderWriter(fileName);
		solution = new ArrayList<>();
		graph = rw.parseInput();
	}

	/**
	 * Apply a topological sort algorithm to find the correct order
	 * of subjects to be studied
	 */
	void topologicalSort() {
		// TODO
		// use the GraphT graph data structre
		// perform a dfs algorithm on it
		// save the finalizing times for each node
	}

	/**
	 * Apply a topological sort algorithm to find the correct order
	 * of subjects to be studied
	 */
	void topologicalSortByKahn() {
		// TODO BONUS
		// use the GraphT graph data structure
		// apply the kahn algorithm
	}

	void printSolution() {
		// TODO
		// use the corresponding method from ReaderWriter
	}

	public static void main(String[] argv) {
		// TODO
		// create an object of type P2 and use it to solve our problem
	}
}
