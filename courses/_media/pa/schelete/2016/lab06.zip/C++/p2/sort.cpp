#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <assert.h>

using namespace std;

struct subject {

  int index;
  string name;
  vector<subject *> before;

  subject(int _index, string _name)
    : index(_index)
    , name(_name) {}

};

vector<subject> subjects;

int get_index( string & name ) {

  for ( int i = 0; i < (int) subjects.size(); ++ i )
    if ( subjects[i].name == name )
      return i;

  int index = subjects.size();

  subjects.push_back( subject(index, name) );
  return subjects.size() - 1;
}

void add( string &first, string &second ) {

  int index_first = get_index(first);
  int index_second = get_index(second);

  subjects[index_first]
    .before
    .push_back( &subjects[index_second] );
}

void solve( vector<subject> & subjects, vector<subject> & sol ) {

  // TODO

}

int main() {

  ifstream fin("sort.in");
  ofstream fout("sort.out");

  string line;

  assert(fin.is_open());
  assert(fout.is_open());

  int subjectsNum;
  fin >> subjectsNum;
  subjects.reserve(subjectsNum);
  
  while ( getline( fin, line ) ) {

    size_t pos = line.find("->");

    if ( pos == string::npos )
      continue;


    string first = line.substr(0, pos - 1);
    string second = line.substr(pos + 3);

    add( first, second );

  }

  vector<subject> sol;
  solve( subjects, sol );

  for ( int i = 0; i < (int) sol.size(); ++ i )
    cout << sol[i].name << endl;

  return 0;
}
