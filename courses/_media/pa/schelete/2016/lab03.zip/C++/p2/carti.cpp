#include <stdio.h>
#include <vector>
#define NMax 110

// TODO: adaugare vector/matrice pentru Dinamica

int solve( const std::vector<int> & carti ) {

    return -666;
}

int main() {

    int N = 0;
    std::vector<int> carti;

    FILE * fin = fopen("carti.in", "r");
    FILE * fout = fopen("carti.out", "w");

    fscanf( fin, "%d", &N );
    carti.resize(N);

    for ( int i = 1; i <= N; ++ i )
        fscanf( fin, "%d\n", &carti[i] );

    fprintf( fout, "%d\n", solve(carti) );

    fclose(fin);
    fclose(fout);

    return 0;
}
