#include <stdio.h>
#include <vector>
#include <string.h>
#define LMax 100010

int Len;
char exp[LMax];

int num_words;
size_t words[LMax];

char * nth_word( char * exp, size_t n ) {
  return exp + words[n];
}

int solve( char * exp ) {

  // TODO

  return -666;
}

int main() {

  FILE * fin = fopen("parantezare.in", "r");
  FILE * fout = fopen("parantezare.out", "w");

  fgets(exp, LMax, fin);

  Len = strlen(exp);

  int index = 1;
  for ( int i = 1; i < Len; ++ i )
    if ( exp[i - 1] == ' ' )
      words[index ++] = i;
  num_words = index - 1;

  fprintf( fout, "%d\n", solve(exp) );

  fclose(fin);
  fclose(fout);

  return 0;
}
