/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>


int main(int argc, char ** argv)
{
	int sock = socket(PF_INET, SOCK_STREAM, 0);

	struct sockaddr_in addr;
	struct hostent *host;

	if(argc < 2) {
		fprintf(stderr, "Run as: %s <port>\n", argv[0]);
		return 1;
	}

	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = inet_addr("127.0.0.1");
	addr.sin_port = htons(atoi(argv[1]));

	if (connect(sock, (struct sockaddr*) &addr, sizeof(addr))) {
		fprintf(stderr, "Connection failed\n");
		return 1;
	}

	fd_set sfds;
	FD_ZERO(&sfds);
	FD_SET(0, &sfds);
	FD_SET(sock, &sfds);

	char buf[255];
	int n;
	while (1) {
		select(sock, &sfds, NULL, NULL, NULL);
		if (FD_ISSET(0, &sfds)) {
			n = read(0, buf, 255);
			write(sock, buf, n);
		} else if (FD_ISSET(sock, &sfds)) {
			n = read(sock, buf, 255);
			write(1, buf, n);
		}
	}

}



