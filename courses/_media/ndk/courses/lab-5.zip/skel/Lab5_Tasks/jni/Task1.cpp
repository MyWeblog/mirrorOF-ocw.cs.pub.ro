/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <jni.h>
#include <stdlib.h>
#include <android/log.h>
#include "ndk_lab5_tasks_MainActivity.h"

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task1
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_ndk_lab5_tasks_MainActivity_task1
  (JNIEnv *env, jobject obj) {

}

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task2
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_ndk_lab5_tasks_MainActivity_task2
  (JNIEnv *env, jobject obj) {

}

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task3
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_ndk_lab5_tasks_MainActivity_task3
  (JNIEnv *env, jobject obj, jint i) {

}

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task4
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_ndk_lab5_tasks_MainActivity_task4
  (JNIEnv *env, jobject obj) {

}

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task5
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_ndk_lab5_tasks_MainActivity_task5
  (JNIEnv *env, jobject obj) {
	return 0;
}

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task6
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_ndk_lab5_tasks_MainActivity_task6
  (JNIEnv *env, jobject obj, jint i) {

}

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task7
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_ndk_lab5_tasks_MainActivity_task7
  (JNIEnv *env, jobject obj) {

}

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task8
 * Signature: ()Z
 */
JNIEXPORT jboolean JNICALL Java_ndk_lab5_tasks_MainActivity_task8
  (JNIEnv *env, jobject obj) {
	return JNI_FALSE;
}
