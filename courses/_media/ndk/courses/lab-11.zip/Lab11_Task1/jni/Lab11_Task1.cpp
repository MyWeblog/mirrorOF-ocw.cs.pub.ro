/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <jni.h>
#include <cpu-features.h>
#include <android/log.h>
#include "ndk_lab11_task1_MainActivity.h"

#define LOGI(...) ((void)__android_log_print(ANDROID_LOG_INFO, "activity", __VA_ARGS__))

JNIEXPORT void JNICALL Java_ndk_lab11_task1_MainActivity_print_1cpu_1features
(JNIEnv *Env, jobject obj) {
	AndroidCpuFamily family = android_getCpuFamily();
	int64_t features = android_getCpuFeatures();
	if (family == ANDROID_CPU_FAMILY_X86) {
		LOGI("ANDROID_CPU_FAMILY_X86\n");
		if (features & ANDROID_CPU_X86_FEATURE_SSSE3)
			LOGI("ANDROID_CPU_X86_FEATURE_SSSE3\n");
		if (features & ANDROID_CPU_X86_FEATURE_MOVBE)
			LOGI("ANDROID_CPU_X86_FEATURE_MOVBE\n");
		if (features & ANDROID_CPU_X86_FEATURE_POPCNT)
			LOGI("ANDROID_CPU_X86_FEATURE_POPCNT\n");

	} else if (family == ANDROID_CPU_FAMILY_ARM) {
		LOGI("ANDROID_CPU_FAMILY_ARM\n");
		if (features & ANDROID_CPU_ARM_FEATURE_ARMv7)
			LOGI("ANDROID_CPU_ARM_FEATURE_ARMv7");
		if (features & ANDROID_CPU_ARM_FEATURE_VFPv3)
			LOGI("ANDROID_CPU_ARM_FEATURE_VFPv3");
		if (features & ANDROID_CPU_ARM_FEATURE_NEON)
			LOGI("ANDROID_CPU_ARM_FEATURE_NEON");
		if (features & ANDROID_CPU_ARM_FEATURE_LDREX_STREX)
			LOGI("ANDROID_CPU_ARM_FEATURE_LDREX_STREX");
	}
}

JNIEXPORT void JNICALL Java_ndk_lab11_task1_MainActivity_timing_1test
  (JNIEnv *Env, jobject obj) {
	int i, j;
	for (i = 0; i < 10000; i++)
		for (j = 0; j < 1000; j++)
			asm volatile("nop;");
}
