#ifdef __cplusplus
extern "C" {
#endif

extern void optimized_print(void);

#ifdef __cplusplus
}
#endif

