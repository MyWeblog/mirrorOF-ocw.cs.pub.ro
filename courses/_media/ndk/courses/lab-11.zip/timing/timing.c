/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "timing.h"
#include <time.h>

#define NANO 1000000000LL
#define MICRO 1000000LL
#define MILI 1000LL
struct timespec ts;

void init_timer(void) {
	clock_gettime(CLOCK_MONOTONIC, &ts);
}

long long get_elapsed_nsec(void) {
	struct timespec ts_current;
	clock_gettime(CLOCK_MONOTONIC, &ts_current);
	time_t dif_sec = ts_current.tv_sec - ts.tv_sec;
	long dif_nsec = ts_current.tv_nsec - ts.tv_nsec;
	long long dif = dif_sec * NANO + dif_nsec;
	return dif;
}

long long get_elapsed_usec(void) {
	struct timespec ts_current;
	clock_gettime(CLOCK_MONOTONIC, &ts_current);
	time_t dif_sec = ts_current.tv_sec - ts.tv_sec;
	long dif_nsec = ts_current.tv_nsec - ts.tv_nsec;
	long long dif = dif_sec * MICRO + dif_nsec / MILI;
	return dif;
}

long long get_elapsed_msec(void) {
	struct timespec ts_current;
	clock_gettime(CLOCK_MONOTONIC, &ts_current);
	time_t dif_sec = ts_current.tv_sec - ts.tv_sec;
	long dif_nsec = ts_current.tv_nsec - ts.tv_nsec;
	long long dif = dif_sec * MILI + dif_nsec / MICRO;
	return dif;
}

long long reset_time(void) {
	long long dif = get_elapsed_nsec();
	init_timer();
	return dif;
}
