/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package ndk.lab11.task3;

import java.nio.ByteBuffer;

import ndk.lab11.task3.R;

import android.os.Bundle;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends Activity {
	ByteBuffer bb;
	Bitmap bitmap;
	ImageView im;
	
	static {
		System.loadLibrary("Lab11_Task3");
	}
	
	Thread t1 = new Thread(new Runnable() {
		@Override
		public void run() {
			if (bb == null)
				return;
			synchronized (bb) {
				bitmap.copyPixelsToBuffer(bb);
			}
		}
	});
	
	Runnable r2 = new Runnable() {
		@Override
		public void run() {
			if (bb == null)
				return;
			synchronized (bb) {
				greyScale(bitmap.getWidth(), bitmap.getHeight());
				bb.flip();
				bitmap.copyPixelsFromBuffer(bb);
				im.postInvalidate();
			}
		}
	};
	
	native ByteBuffer getBuffer(int size);
	native void greyScale(int w, int h);
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		im = (ImageView) findViewById(R.id.imageView1);


		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inPreferredConfig = Bitmap.Config.ARGB_8888;
		options.inScaled = false;
		
		bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.sviatihory, options);
		im.setImageBitmap(bitmap);
		bb = (ByteBuffer) getBuffer(bitmap.getByteCount());
		t1.start();
		
		Button b1 = (Button) findViewById(R.id.button1);
		b1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Thread t = new Thread(r2);
				t.start();
			}
		});
		
	}

}
