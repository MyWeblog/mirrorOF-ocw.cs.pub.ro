
int libTask1();

int libTask2(int a, int b);
