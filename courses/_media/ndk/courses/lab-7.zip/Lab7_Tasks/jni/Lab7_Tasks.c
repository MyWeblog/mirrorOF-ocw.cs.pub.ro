/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <jni.h>
#include <stdlib.h>
#include "nlib.h"


JNIEXPORT void JNICALL Java_ndk_lab7_tasks_MainActivity_task1(JNIEnv * env, jobject obj) {
	libTask1();
}

JNIEXPORT void JNICALL Java_ndk_lab7_tasks_MainActivity_task2(JNIEnv * env, jobject obj) {
	libTask2(20, 20);
}

