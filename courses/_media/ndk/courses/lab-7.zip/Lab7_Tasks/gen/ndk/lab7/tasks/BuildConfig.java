/** Automatically generated file. DO NOT MODIFY */
package ndk.lab7.tasks;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}