/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package ndk.lab6.tasks1;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;

public class MainActivity extends Activity {

	static {
		System.loadLibrary("Lab6_Tasks1");
	}
	
	int[] a;
	String[] b;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		a = getIntArray();
		b = getStringArray();
		
		if (a != null)
			for(int i : a)
				Log.e("Int array", Integer.toString(i));
		
		if (b != null)
			for(String s : b)
				Log.e("String array", s);
		
		if (a != null) {
			updateArray();
		
			for(int i : a)
				Log.e("Updated Int array", Integer.toString(i));
		}
	}

	native int[] getIntArray();
	native String[] getStringArray();
	native void updateArray();
	
}
