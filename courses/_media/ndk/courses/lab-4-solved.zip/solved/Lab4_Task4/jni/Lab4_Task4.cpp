/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <jni.h>
#include "ndk_lab4_task4_MainActivity.h"
#include <pthread.h>
#include <android/log.h>

#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, __func__, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, __func__, __VA_ARGS__)

pthread_t thread;

JavaVM *pVM;

jint JNI_OnLoad(JavaVM *vm, void *reserved) {
	pVM = vm;
	return JNI_VERSION_1_6;
}

void *thread_task(void *params) {
	LOGI("Thread started");

	JNIEnv *env;
	pVM->AttachCurrentThread(&env, NULL);

	jclass exception = env->FindClass("java/lang/RuntimeException");
	env->ThrowNew(exception, "Exception from a POSIX thread!");

	pVM->DetachCurrentThread();
}

JNIEXPORT void JNICALL Java_ndk_lab4_task4_MainActivity_start_1thread
  (JNIEnv *env, jobject obj) {
	if (pthread_create(&thread, NULL, thread_task, NULL) != 0) {
		LOGW("Thread could not be created");
	}
}
