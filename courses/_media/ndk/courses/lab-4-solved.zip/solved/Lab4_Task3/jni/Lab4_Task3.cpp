/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <jni.h>
#include <stdio.h>
#include <unistd.h>
#include <android/log.h>
#include "ndk_lab4_task3_MainActivity.h"

#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, __func__, __VA_ARGS__)

JNIEXPORT jstring JNICALL Java_ndk_lab4_task3_MainActivity_listfiles
  (JNIEnv *env, jobject obj, jstring filename) {
	char buf[1024];
	FILE *f;
	const char *filename_str = env->GetStringUTFChars(filename, NULL);
	if (!filename_str) {
		LOGW("Unable to get filename string");
		return NULL;
	}
	snprintf(buf, sizeof(buf), "ls %s", filename_str);
	f = popen(buf, "r");
	if (!f) {
		LOGW("Unable to list files in %s", filename_str);
		env->ReleaseStringUTFChars(filename, filename_str);
		return NULL;
	}
	memset(buf, 0, sizeof(buf));
	fread(buf, sizeof(buf), 1, f);
	fclose(f);
	env->ReleaseStringUTFChars(filename, filename_str);
	return env->NewStringUTF(buf);
}
