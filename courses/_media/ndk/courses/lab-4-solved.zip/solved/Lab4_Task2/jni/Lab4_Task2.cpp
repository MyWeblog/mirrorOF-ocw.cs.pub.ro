/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <jni.h>
#include <stdio.h>
#include <unistd.h>
#include <android/log.h>
#include "ndk_lab4_task2_MainActivity.h"

#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, __func__, __VA_ARGS__)

JNIEXPORT void JNICALL Java_ndk_lab4_task2_MainActivity_write
  (JNIEnv *env, jobject obj, jstring filename, jstring text) {
	FILE * f;
	const char *text_str;
	const char *filename_str = env->GetStringUTFChars(filename, NULL);

	if (!filename_str) {
		LOGW("Unable to get filename string");
		return;
	}
	text_str = env->GetStringUTFChars(text, NULL);
	if (!text_str) {
		LOGW("Unable to get text string");
		goto out1;
	}

	f = fopen(filename_str, "w");
	if (!f) {
		LOGW("Unable to open file %s", filename_str);
		goto out2;
	}
	fwrite(text_str, strlen(text_str), 1,f);
	fclose(f);

out2:
	env->ReleaseStringUTFChars(text, text_str);
out1:
	env->ReleaseStringUTFChars(filename, filename_str);
}

JNIEXPORT jstring JNICALL Java_ndk_lab4_task2_MainActivity_read
  (JNIEnv *env, jobject obj, jstring filename) {
	char buf[1024];
	FILE *f;
	const char *filename_str = env->GetStringUTFChars(filename, NULL);
	if (!filename_str) {
		LOGW("Unable to get filename string");
		return NULL;
	}
	f = fopen(filename_str, "r");
	if (!f) {
		LOGW("Unable to open file %s", filename_str);
		env->ReleaseStringUTFChars(filename, filename_str);
		return NULL;
	}
	fread(buf, sizeof(buf), 1, f);
	fclose(f);
	env->ReleaseStringUTFChars(filename, filename_str);
	return env->NewStringUTF(buf);
}
