/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <jni.h>
#include <stdlib.h>
#include <android/log.h>
#include "ndk_lab6_tasks_MainActivity.h"

unsigned char *buffer;

JNIEXPORT jobject JNICALL Java_ndk_lab6_tasks_MainActivity_getBuffer
  (JNIEnv *env, jobject obj, jint length) {
	buffer = (unsigned char*) malloc(length);
	jobject directBuffer = env->NewDirectByteBuffer(buffer, length);
	return directBuffer;
}

JNIEXPORT jobject JNICALL Java_ndk_lab6_tasks_MainActivity_applyFilter
  (JNIEnv *env, jobject obj, jfloatArray filter, jfloat factor, jint w , jint h) {
	float * filterBuffer = env->GetFloatArrayElements(filter, NULL);
	unsigned char * newBuffer = (unsigned char*) malloc(w * h * 4);
	jobject directBuffer = env->NewDirectByteBuffer(newBuffer, w * h * 4);
	int i, j, c;
	float aux;
	/* copy first and last line */
	for (j = 0; j < 4; j++) {
		 newBuffer[j] = buffer[j];
	}
	for (j = 0; j < 4; j++) {
			 newBuffer[(h-1) * w * 4 + j] = buffer[(h-1) * w * 4 + j];
	}
	for (i = 1; i < (h - 1); i++) {
		/* copy first and last pixel on line */
		newBuffer[i * w * 4 + 0] = buffer[i * w * 4 + 0];
		newBuffer[i * w * 4 + 1] = buffer[i * w * 4 + 1];
		newBuffer[i * w * 4 + 2] = buffer[i * w * 4 + 2];
		newBuffer[i * w * 4 + 3] = buffer[i * w * 4 + 3];

		newBuffer[(i + 1) * w * 4 - 4] = buffer[(i + 1) * w * 4 - 4];
		newBuffer[(i + 1) * w * 4 - 3] = buffer[(i + 1) * w * 4 - 3];
		newBuffer[(i + 1) * w * 4 - 2] = buffer[(i + 1) * w * 4 - 2];
		newBuffer[(i + 1) * w * 4 - 1] = buffer[(i + 1) * w * 4 - 1];
		for (j = 4; j < (w - 1) * 4; j++) {
			for (c  = 0; c < 3; c++, j++) {
				aux = 0;
				aux += buffer[(i - 1)* w * 4 + j - 4] * filterBuffer[0];
				aux += buffer[(i - 1)* w * 4 + j + 0] * filterBuffer[1];
				aux += buffer[(i - 1)* w * 4 + j + 4] * filterBuffer[2];
				aux += buffer[i * w * 4 + j - 4] * filterBuffer[3];
				aux += buffer[i * w * 4 + j + 0] * filterBuffer[4];
				aux += buffer[i * w * 4 + j + 4] * filterBuffer[5];
				aux += buffer[(i + 1)* w * 4 + j - 4] * filterBuffer[6];
				aux += buffer[(i + 1)* w * 4 + j + 0] * filterBuffer[7];
				aux += buffer[(i + 1)* w * 4 + j + 4] * filterBuffer[8];
				newBuffer[i * w * 4 + j + 0] = aux * factor;
			}
		}
	}
	return env->NewDirectByteBuffer(newBuffer, w * h * 4);
}

JNIEXPORT void JNICALL Java_ndk_lab6_tasks_MainActivity_greyScale
  (JNIEnv *env, jobject obj, jint w, jint h) {
	int i, j;
	float r, g, b;
	for (i = 0; i < h; i++) {
		for (j = 0; j < w * 4; j+=4) {
			r = buffer[i * w * 4 + j + 0] * 0.21;
			g = buffer[i * w * 4 + j + 1] * 0.71;
			b = buffer[i * w * 4 + j + 2] * 0.07;
			buffer[i * w * 4 + j + 0] = buffer[i * w * 4 + j + 1] =
					buffer[i * w * 4 + j + 2] = r + g + b;
		}
	}
}
