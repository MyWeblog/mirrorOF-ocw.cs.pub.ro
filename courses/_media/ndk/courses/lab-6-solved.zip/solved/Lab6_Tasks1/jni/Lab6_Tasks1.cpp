/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <jni.h>
#include <stdlib.h>
#include <android/log.h>
#include "ndk_lab6_tasks1_MainActivity.h"

#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, __func__, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, __func__, __VA_ARGS__)

jobject globalIntArrayRef;

JNIEXPORT jintArray JNICALL Java_ndk_lab6_tasks1_MainActivity_getIntArray
  (JNIEnv *env, jobject obj) {
	jintArray javaArray = env->NewIntArray(5);
	if (!javaArray) {
		LOGW("Could not allocate array");
		return NULL;
	}
	globalIntArrayRef = env->NewGlobalRef(javaArray);
	jint array[] = {1, 2, 3, 4, 5};
	env->SetIntArrayRegion(javaArray, 0, 5, array);
	return javaArray;
}


JNIEXPORT jobjectArray JNICALL Java_ndk_lab6_tasks1_MainActivity_getStringArray
  (JNIEnv *env, jobject obj) {
	jclass stringClass= env->FindClass("java/lang/String");
	if (!stringClass) {
		LOGW("Could not find String class");
		return NULL;
	}
	jobjectArray javaArray = env->NewObjectArray(5, stringClass, NULL);
	if (!javaArray) {
		LOGW("Could not allocate array");
		return NULL;
	}
	env->SetObjectArrayElement(javaArray, 0, env->NewStringUTF("one"));
	env->SetObjectArrayElement(javaArray, 1, env->NewStringUTF("two"));
	env->SetObjectArrayElement(javaArray, 2, env->NewStringUTF("three"));
	env->SetObjectArrayElement(javaArray, 3, env->NewStringUTF("four"));
	env->SetObjectArrayElement(javaArray, 4, env->NewStringUTF("five"));
	return javaArray;
}


JNIEXPORT void JNICALL Java_ndk_lab6_tasks1_MainActivity_updateArray
  (JNIEnv *env, jobject obj) {
	/* Task 2 */
	/*
	jint array[5];
	env->GetIntArrayRegion((jintArray)globalIntArrayRef, 0, 5, array);
	for (int i = 0; i < 5; i++)
		array[i]++;
	env->SetIntArrayRegion((jintArray)globalIntArrayRef, 0, 5, array);
	*/
	/* Task 3 & 4*/
	if (env->MonitorEnter(globalIntArrayRef) == 0) {
		jint *directArray = env->GetIntArrayElements((jintArray)globalIntArrayRef, NULL);
		for (int i = 0; i < 5; i++)
			directArray[i]++;
		env->ReleaseIntArrayElements((jintArray)globalIntArrayRef, directArray, 0);
	   if (env->MonitorExit(globalIntArrayRef) != 0) {
		   LOGW("Could not acquire Monitor");
	   }
	} else {
		LOGW("Could not release Monitor");
	}

}
