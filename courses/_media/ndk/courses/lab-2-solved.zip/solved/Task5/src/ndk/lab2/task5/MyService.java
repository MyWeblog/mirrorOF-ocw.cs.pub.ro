/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package ndk.lab2.task5;

import java.util.ArrayList;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;

public class MyService extends Service {
	public MyService() {
	}

	final static int REGISTER = 1;
	final static int UNREGISTER = 2;
	final static int REPLY = 3;
	final static int REQUEST_ACTION_GLOBAL = 4;
	final static int REQUEST_ACTION_LOCAL = 5;
	
	
	
	private static class MessageHandler extends Handler {
		
		ArrayList<Messenger> clients = new ArrayList<Messenger>();
		
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
				case REQUEST_ACTION_LOCAL:
					Log.d("handleMessage", "Reply to one client");
					try {
						Message reply = Message.obtain(null, REPLY);
						if (msg.replyTo != null)
							msg.replyTo.send(reply);
					} catch (RemoteException e) {
						clients.remove(msg.replyTo);
					}
					break;
				case REQUEST_ACTION_GLOBAL:
					Log.d("handleMessage", "Reply to all clients");
					for (Messenger m : clients) {
						Message reply = Message.obtain(null, REPLY);
						try {
							m.send(reply);
						} catch (RemoteException e) {
							clients.remove(msg.replyTo);
						}
					}
					break;
				case REGISTER:
					Log.d("handleMessage", "Register client");
					if (msg.replyTo != null && !clients.contains(msg.replyTo))
						clients.add(msg.replyTo);
					break;
				case UNREGISTER:
						Log.d("handleMessage", "Unregister client");
						clients.remove(msg.replyTo);
					break;
				default:
					super.handleMessage(msg);
			}
		}
	}
	
	Messenger mService = new Messenger(new MessageHandler());
	
	@Override
	public IBinder onBind(Intent intent) {
		return mService.getBinder();
	}
}
