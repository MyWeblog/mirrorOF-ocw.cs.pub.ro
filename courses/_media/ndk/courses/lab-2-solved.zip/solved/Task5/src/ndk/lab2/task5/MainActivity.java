/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package ndk.lab2.task5;

import ndk.lab2.task5.R;

import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.app.Activity;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {

	Messenger messenger = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		Button b1 = (Button) findViewById(R.id.button1);
		Button b2 = (Button) findViewById(R.id.button2);
		Button b3 = (Button) findViewById(R.id.button3);
		Button b4 = (Button) findViewById(R.id.button4);
		
		b1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (serviceMessenger != null) {
					Message m = Message.obtain(null, MyService.REGISTER);
					m.replyTo = messenger;
					try {
						serviceMessenger.send(m);
					} catch (RemoteException e) {
						serviceMessenger = null;
					}
				}
			}
		});
		
		b2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (serviceMessenger != null) {
					Message m = Message.obtain(null, MyService.UNREGISTER);
					m.replyTo = messenger;
					try {
						serviceMessenger.send(m);
					} catch (RemoteException e) {
						serviceMessenger = null;
					}
				}
			}
		});
		
		b3.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (serviceMessenger != null) {
					Message m = Message.obtain(null, MyService.REQUEST_ACTION_LOCAL);
					m.replyTo = messenger;
					try {
						serviceMessenger.send(m);
					} catch (RemoteException e) {
						serviceMessenger = null;
					}
				}
			}
		});
		
		b4.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (serviceMessenger != null) {
					Message m = Message.obtain(null, MyService.REQUEST_ACTION_GLOBAL);
					m.replyTo = messenger;
					try {
						serviceMessenger.send(m);
					} catch (RemoteException e) {
						serviceMessenger = null;
					}
				}
			}
		});
	}
	
	Messenger serviceMessenger = null;
	
	ServiceConnection mServiceConnection = new ServiceConnection() {
		
		@Override
		public void onServiceDisconnected(ComponentName name) {
			serviceMessenger = null;
		}
		
		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			serviceMessenger = new Messenger(service);
		}
	};
	
	private static class ActivityMessageHandler extends Handler {
		
		@Override
		public void handleMessage(Message msg) {
			if (msg.what == MyService.REPLY) {
				Log.d("ActivityMessagehandler", "got reply");
			} else {
				super.handleMessage(msg);
			}
		}
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		if (messenger == null)
			messenger = new Messenger(new ActivityMessageHandler());
		Log.d("onResume", "messenger: " + messenger);
		bindService(new Intent(this, MyService.class), mServiceConnection, Service.BIND_AUTO_CREATE);
	}
	
	 protected void onPause() {
		unbindService(mServiceConnection);
		serviceMessenger = null;
	}
}
