/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package ndk.lab2.task4;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;

public class MyContentProvider extends ContentProvider {
	
	static DatabaseHelper dbHelper;
	private static final UriMatcher sUriMatcher;
	
	final static int TABLE = 1;
	final static int ROW = 2;
	
	public final static String uriRoot = "ndk.lab2.task3.MyContentProvider";
	public final static String tableUri = "content://" + uriRoot + "/menu/";
	
	
	
	static {
		sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
		// first parameter should be the one in the manifest
		sUriMatcher.addURI(uriRoot, "menu", TABLE);
		sUriMatcher.addURI(uriRoot, "menu/#", TABLE);		
	}
	
	
	static class DatabaseHelper extends SQLiteOpenHelper {

		DatabaseHelper(Context context) {
			super(context, "sample.db", null, 1);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL("CREATE TABLE IF NOT EXISTS menu ("
					+ "id INTEGER PRIMARY KEY,"
					+ "name TEXT,"
					+ "desc TEXT,"
					+ "price INTEGER"
					+ ");");
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			//This should move the old table to the new database
			db.execSQL("DROP TABLE IF EXISTS menu");
			onCreate(db);
		}
	}
	
	public MyContentProvider() {
	}

	@Override
	public boolean onCreate() {
		dbHelper = new DatabaseHelper(getContext());
		return true;
	}
	
	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// Implement this to handle requests to delete one or more rows.
		throw new UnsupportedOperationException("Not yet implemented");
	}

	@Override
	public String getType(Uri uri) {
		// TODO: Implement this to handle requests for the MIME type of the data
		// at the given URI.
		throw new UnsupportedOperationException("Not yet implemented");
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		
		if (sUriMatcher.match(uri) != TABLE) {
			throw new IllegalArgumentException("Should insert to menu table");
		}
		//You should check that correct values go into the table and add missing values
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		long rowID = db.insert("menu", null, values);
		if (rowID >= 0) {
            Uri noteUri = ContentUris.withAppendedId(Uri.parse(tableUri), rowID);
            getContext().getContentResolver().notifyChange(noteUri, null);
            return noteUri;
		} else {
			throw new SQLException("Failed to insert row into " + uri);
		}
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		
		SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
		qb.setTables("menu");

		switch (sUriMatcher.match(uri)) {
			case TABLE:
				break;
			case ROW:
				qb.appendWhereEscapeString("id = " + uri.getLastPathSegment());
				break;
			default:
				throw new IllegalArgumentException("Wrong URI: " + uri);
		}
		
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		
		Cursor c = qb.query(db, projection, selection, selectionArgs, null, null, sortOrder);
		
		return c;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO: Implement this to handle requests to update one or more rows.
		throw new UnsupportedOperationException("Not yet implemented");
	}
}
