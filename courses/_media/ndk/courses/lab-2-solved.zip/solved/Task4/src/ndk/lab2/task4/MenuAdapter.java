/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package ndk.lab2.task4;

import java.util.ArrayList;
import java.util.List;

import ndk.lab2.task4.MyReceiver;

import ndk.lab2.task4.R;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class MenuAdapter extends BaseAdapter {

	private List<MenuItem> content;
	private Context context;

	public MenuAdapter(Context context) {
		super();
		this.content = new ArrayList<MenuItem>();
		this.context = context;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		/* 
		 * In Android displayed items are created by the system from Views.
		 * A View can contain other Views.
		 * The purpose of an adapter is to create the Views displayed in a list or spinner.
		 * A ListView must be given the adapter that builds each View the list might display.
		 * The ListView then calls the getView method of the adapter for each item that might
		 * be on the screen.
		 */

		/*
		 * The parameters getView receives are as follows:
		 * position = the index of the item to be displayed
		 * convertView = the previous View displayed in this position, can be null
		 * parent = reference to the ListView or Spinner the created view will be attached to
		 */

		/* LayoutInflater is a system service that builds Views from layouts */
		LayoutInflater inflater = (LayoutInflater)context.getSystemService
				(Context.LAYOUT_INFLATER_SERVICE);
		convertView = inflater.inflate(R.layout.list_item, null);

		/* After the view is built, update the layout TextViews to display the correct text */
		TextView name = (TextView) convertView.findViewById(R.id.Name);
		TextView desc = (TextView) convertView.findViewById(R.id.Description);
		TextView price = (TextView) convertView.findViewById(R.id.Price);
		name.setText(getItem(position).getName());
		desc.setText(getItem(position).getDesc());
		price.setText(getItem(position).getPrice());


		convertView.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent i = new Intent(context, MyReceiver.class);
				i.putExtra("name", getItem(position).getName());
				context.sendBroadcast(i);
			}
		});

		return convertView;
	}

	public void add(MenuItem item) {
		content.add(item);
	}

	@Override
	public int getCount() {
		return content.size();
	}

	@Override
	public MenuItem getItem(int position) {
		if (position < content.size())
			return content.get(position);
		return null;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
}
