/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <jni.h>
#include <stdlib.h>
#include <android/log.h>
#include "ndk_lab5_tasks_MainActivity.h"

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task1
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_ndk_lab5_tasks_MainActivity_task1
  (JNIEnv *env, jobject obj) {
	jclass cls = env->FindClass("ndk/lab5/tasks/MainActivity");
	if (!cls) {
		__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Class not found");
		return;
	}
	jmethodID mID = env->GetMethodID(cls, "setText", "()V");
	if (!mID) {
			__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Method not found");
			return;
	}
	env->CallVoidMethod(obj, mID);
}

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task2
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_ndk_lab5_tasks_MainActivity_task2
  (JNIEnv *env, jobject obj) {
	jclass cls = env->FindClass("ndk/lab5/tasks/MainActivity");
	if (!cls) {
		__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Class not found");
		return;
	}
	jmethodID mID = env->GetMethodID(cls, "setText", "(Ljava/lang/String;)V");
	if (!mID) {
			__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Method not found");
			return;
	}

	jstring str = env->NewStringUTF("OK");
	env->CallVoidMethod(obj, mID, str);
	env->ReleaseStringUTFChars(str, env->GetStringUTFChars(str, NULL));
}

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task3
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_ndk_lab5_tasks_MainActivity_task3
  (JNIEnv *env, jobject obj, jint i) {
	jclass cls = env->FindClass("ndk/lab5/tasks/MainActivity");
	if (!cls) {
		__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Class not found");
		return;
	}
	jmethodID mID1 = env->GetMethodID(cls, "getInput", "()Ljava/lang/String;");
	if (!mID1) {
			__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Method not found");
			return;
	}
	jstring str = (jstring) env->CallObjectMethod(obj, mID1);

	jmethodID mID2 = env->GetMethodID(cls, "setText", "(Ljava/lang/String;I)V");
	if (!mID2) {
			__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Method not found");
			return;
	}

	env->CallVoidMethod(obj, mID2, str, i);
	env->ReleaseStringUTFChars(str, env->GetStringUTFChars(str, NULL));
}

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task4
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_ndk_lab5_tasks_MainActivity_task4
  (JNIEnv *env, jobject obj) {
	jclass cls = env->FindClass("ndk/lab5/tasks/MainActivity");
	if (!cls) {
		__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Class not found");
		return;
	}
	jmethodID mID1 = env->GetStaticMethodID(cls, "getInt", "()I");
	if (!mID1) {
			__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Method not found");
			return;
	}
	jint res = env->CallStaticIntMethod(cls, mID1);

	jmethodID mID2 = env->GetStaticMethodID(cls, "checkInt", "(I)V");
	if (!mID2) {
			__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Method not found");
			return;
	}

	env->CallStaticVoidMethod(cls, mID2, res);
}

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task5
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_ndk_lab5_tasks_MainActivity_task5
  (JNIEnv *env, jobject obj) {
	jclass cls = env->FindClass("ndk/lab5/tasks/MainActivity");
	if (!cls) {
		__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Class not found");
		return 0;
	}

	jfieldID fID = env->GetFieldID(cls, "field", "I");
	if (!fID) {
			__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Field not found");
			return 0;
	}
	jint i = env->GetIntField(obj, fID);

	return i;
}

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task6
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_ndk_lab5_tasks_MainActivity_task6
  (JNIEnv *env, jobject obj, jint i) {
	jclass cls = env->FindClass("ndk/lab5/tasks/MainActivity");
	if (!cls) {
		__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Class not found");
		return;
	}

	jfieldID fID = env->GetFieldID(cls, "field", "I");
	if (!fID) {
			__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Field not found");
			return;
	}
	env->SetIntField(obj, fID, i);

}

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task7
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_ndk_lab5_tasks_MainActivity_task7
  (JNIEnv *env, jobject obj) {
	jclass exception = env->FindClass("java/lang/RuntimeException");
	env->ThrowNew(exception, "JNI Generated Exception");
}

/*
 * Class:     ndk_lab5_tasks_MainActivity
 * Method:    task8
 * Signature: ()Z
 */
JNIEXPORT jboolean JNICALL Java_ndk_lab5_tasks_MainActivity_task8
  (JNIEnv *env, jobject obj) {
	jclass cls = env->FindClass("ndk/lab5/tasks/MainActivity");
	if (!cls) {
		__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Class not found");
		return JNI_FALSE;
	}
	jmethodID mID = env->GetMethodID(cls, "generateException", "()V");
	if (!mID) {
			__android_log_print(ANDROID_LOG_ERROR, "TASK1", "Method not found");
			return JNI_FALSE;
	}

	env->CallVoidMethod(obj, mID);
	jboolean ex = env->ExceptionCheck();
	if (ex) {
		env->ExceptionClear();
	}
	return ex;
}

