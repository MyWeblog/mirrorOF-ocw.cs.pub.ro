/*
 * Copyright 2014 Petre Eftime
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// OpenGL ES 2.0 code

#include <jni.h>
#include <android/log.h>

#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define  LOG_TAG    "libgl2jni"
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)

static const char gVertexShader[] = 
	"uniform mat4 p_matrix;\n"
	"uniform mat4 mv_matrix;\n"
	"attribute vec4 vPosition;\n"
	"attribute vec4 vColor;\n"
	"void main() {\n"
    "  gl_Position = p_matrix * mv_matrix * vPosition;\n"
    "}\n";

static const char gFragmentShader[] = 
    "precision mediump float;\n"
	"void main() {\n"
    "  gl_FragColor = vec4(1, 0, 0, 1);\n"
    "}\n";

GLfloat p_matrix[16], mv_matrix[16];

#define FOV_R 0.6f
#define NEAR 0.5f
#define FAR 16.0f

//camera to screen matrix
static void
update_p_matrix (GLfloat * matrix, GLfloat w, GLfloat h)
{
  GLfloat r_xy_factor = fminf (w, h) / FOV_R;
  GLfloat r_x = r_xy_factor / w, r_y = r_xy_factor / h;
  GLfloat r_zw_factor = 1.0f / (FAR - NEAR);
  GLfloat r_z = (NEAR + FAR) * r_zw_factor;
  GLfloat r_w = -2.0f * NEAR * FAR * r_zw_factor;

  matrix[0] = r_x;
  matrix[1] = 0.0f;
  matrix[2] = 0.0f;
  matrix[3] = 0.0f;

  matrix[4] = 0.0f;
  matrix[5] = r_y;
  matrix[6] = 0.0f;
  matrix[7] = 0.0f;

  matrix[8] = 0.0f;
  matrix[9] = 0.0f;
  matrix[10] = r_z;
  matrix[11] = 1.0f;

  matrix[12] = 0.0f;
  matrix[13] = 0.0f;
  matrix[14] = r_w;
  matrix[15] = 0.0f;
}

GLfloat eye_position[3] = { 0, 0, 2 };

// rotation on different axis
GLfloat rx = 0, ry = 0, rz = 0;
// world to camera matrix
static void
update_mv_matrix (GLfloat * matrix)
{

  GLfloat sinx = sin (rx);
  GLfloat cosx = cos (rx);

  GLfloat siny = sin (ry);
  GLfloat cosy = cos (ry);

  GLfloat sinz = sin (rz);
  GLfloat cosz = cos (rz);

  matrix[0] = cosx * cosy;
  matrix[1] = sinx * cosy;
  matrix[2] = -siny;
  matrix[3] = 0.0f;

  matrix[4] = cosx * siny * sinz - sinx * cosz;
  matrix[5] = cosx * cosz + sinx * siny * sinz;
  matrix[6] = sinz * cosy;
  matrix[7] = 0.0f;

  matrix[8] = cosx * siny * cosz + sinx * sinz;
  matrix[9] = sinx * siny * cosz - cosx * sinz;
  matrix[10] = cosy * cosz;
  matrix[11] = 0.0f;

  matrix[12] = eye_position[0];
  matrix[13] = eye_position[1];
  matrix[14] = eye_position[2];
  matrix[15] = 1.0f;
}


GLuint loadShader(GLenum shaderType, const char* pSource) {
    GLuint shader = glCreateShader(shaderType);
    if (shader) {
        glShaderSource(shader, 1, &pSource, NULL);
        glCompileShader(shader);
        GLint compiled = 0;
        glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
        if (!compiled) {
            GLint infoLen = 0;
            glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &infoLen);
            if (infoLen) {
                char* buf = (char*) malloc(infoLen);
                if (buf) {
                    glGetShaderInfoLog(shader, infoLen, NULL, buf);
                    LOGE("Could not compile shader %d:\n%s\n",
                            shaderType, buf);
                    free(buf);
                }
                glDeleteShader(shader);
                shader = 0;
            }
        }
    }
    return shader;
}

GLuint createProgram(const char* pVertexSource, const char* pFragmentSource) {
    GLuint vertexShader = loadShader(GL_VERTEX_SHADER, pVertexSource);
    if (!vertexShader) {
        return 0;
    }

    GLuint pixelShader = loadShader(GL_FRAGMENT_SHADER, pFragmentSource);
    if (!pixelShader) {
        return 0;
    }

    GLuint program = glCreateProgram();
    if (program) {
        glAttachShader(program, vertexShader);

        glAttachShader(program, pixelShader);
        glLinkProgram(program);
        GLint linkStatus = GL_FALSE;
        glGetProgramiv(program, GL_LINK_STATUS, &linkStatus);
        if (linkStatus != GL_TRUE) {
            GLint bufLength = 0;
            glGetProgramiv(program, GL_INFO_LOG_LENGTH, &bufLength);
            if (bufLength) {
                char* buf = (char*) malloc(bufLength);
                if (buf) {
                    glGetProgramInfoLog(program, bufLength, NULL, buf);

                    free(buf);
                }
            }
            glDeleteProgram(program);
            program = 0;
        }
    }
    return program;
}

GLuint gProgram;
GLuint gvPositionHandle;
GLuint gvColorHandle;
GLuint gPmatrix;
GLuint gMVmatrix;


bool setupGraphics(int w, int h) {

    gProgram = createProgram(gVertexShader, gFragmentShader);
    if (!gProgram) {
        return false;
    }

    gPmatrix  = glGetUniformLocation(gProgram, "p_matrix");
    gMVmatrix = glGetUniformLocation(gProgram, "mv_matrix");
    gvPositionHandle = glGetAttribLocation(gProgram, "vPosition");
    gvColorHandle = glGetAttribLocation(gProgram, "vColor");

    update_mv_matrix(mv_matrix);
    update_p_matrix(p_matrix, w, h);

    glViewport(0, 0, w, h);
    return true;
}

const GLfloat gTriangleVertices[] = { -0.5f, -0.5f,
									-0.5f, 0.5f,
									0.5f, -0.5f};

void renderFrame() {
	rx += 0.03;
	ry += 0.02;
	rz += 0.01;

	update_mv_matrix(mv_matrix);
    glClearColor(0, 0, 0, 1.0f);
    glClear( GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);

    glUseProgram(gProgram);

    glUniformMatrix4fv (gPmatrix,
  		      1, GL_FALSE, p_matrix);

    glUniformMatrix4fv (gMVmatrix,
  		      1, GL_FALSE, mv_matrix);

    glVertexAttribPointer(gvPositionHandle, 2, GL_FLOAT, GL_FALSE, 0, gTriangleVertices);
    glEnableVertexAttribArray(gvPositionHandle);


    glDrawArrays(GL_TRIANGLES, 0, 3);
}

extern "C" {
    JNIEXPORT void JNICALL Java_com_android_gl2jni_GL2JNILib_init(JNIEnv * env, jobject obj,  jint width, jint height);
    JNIEXPORT void JNICALL Java_com_android_gl2jni_GL2JNILib_step(JNIEnv * env, jobject obj);
};

JNIEXPORT void JNICALL Java_com_android_gl2jni_GL2JNILib_init(JNIEnv * env, jobject obj,  jint width, jint height)
{
    setupGraphics(width, height);
}

JNIEXPORT void JNICALL Java_com_android_gl2jni_GL2JNILib_step(JNIEnv * env, jobject obj)
{
    renderFrame();
}

