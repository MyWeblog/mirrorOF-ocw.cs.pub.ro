/*
 * Copyright 2014 Laura Gheorghe
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package ndk.lab10.task1;

import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	
		//Create the source data, and a destination for the filtered results
		Bitmap inputBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.cat);
		Bitmap outputBitmap = inputBitmap.copy(inputBitmap.getConfig(), true);
		
		//Set original image
		ImageView normalImage = (ImageView) findViewById(R.id.original);
		normalImage.setImageBitmap(outputBitmap.copy(outputBitmap.getConfig(), false));
		 
		final RenderScript mRS;
		//TODO - create the RenderScript context
		mRS = RenderScript.create(this);
		
		Allocation input;
		//TODO - create input Allocation from input bitmap
        input = Allocation.createFromBitmap(mRS, inputBitmap);
        
        Allocation output;
        //TODO - create output Allocation from output bitmap
        output = Allocation.createFromBitmap(mRS, outputBitmap); 
		
		final ScriptIntrinsicBlur script;
		//TODO - load blur script
		script = ScriptIntrinsicBlur.create(mRS, Element.U8_4(mRS));
		
		//TODO - set the radius of the blur - 0 < radius <= 25
		script.setRadius((float)24.5);
		
		//TODO - set input
		script.setInput(input);
		
		//TODO - execute script
		script.forEach(output);
		
		//TODO - copy the output into the outBitmap
		output.copyTo(outputBitmap);
		
		//Set blurred image
		ImageView blurredImage = (ImageView) findViewById(R.id.blurred);
		blurredImage.setImageBitmap(outputBitmap.copy(outputBitmap.getConfig(), false));
	}
}