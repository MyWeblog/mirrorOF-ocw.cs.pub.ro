#include <jni.h>
#include <string>

extern "C"
jstring
Java_com_example_user_test_MainActivity_stringFromJNI(JNIEnv *env, jobject instance) {

        // TODO
}
extern "C"
JNIEXPORT void JNICALL
Java_com_example_user_test_MainActivity_task1(JNIEnv *env, jobject instance) {

    // TODO


}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_user_test_MainActivity_task2(JNIEnv *env, jobject instance) {

    // TODO

}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_user_test_MainActivity_task3(JNIEnv *env, jobject instance,
                                       jint i) {

    // TODO

}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_user_test_MainActivity_task4(JNIEnv *env, jobject instance) {

    // TODO

}

extern "C"
JNIEXPORT jint JNICALL
Java_com_example_user_test_MainActivity_task5(JNIEnv *env, jobject instance) {

    // TODO

}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_user_test_MainActivity_task6(JNIEnv *env, jobject instance,
                                       jint i) {

    // TODO

}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_user_test_MainActivity_task7(JNIEnv *env, jobject instance) {

    // TODO

}

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_example_user_test_MainActivity_task8(JNIEnv *env, jobject instance) {

    // TODO

}
