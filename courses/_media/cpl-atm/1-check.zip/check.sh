#!/bin/bash

NUM_TESTS=9
for i in $(seq 0 $(($NUM_TESTS - 1))); do
	cp input/in_$i.txt input.txt
	node main.js > output.txt
	diff output.txt output/out_ref_$i.txt &> /dev/null
	if [ $? -eq 0 ]; then
		echo "Test $i ................ PASSED"
	else
		echo "Test $i .................FAILED"
	fi
	rm input.txt
done

