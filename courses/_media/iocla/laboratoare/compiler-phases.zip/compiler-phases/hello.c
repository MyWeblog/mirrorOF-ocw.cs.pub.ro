#include <stdio.h>

#define MESSAGE		"Hello, World!"

int main(void)
{
	puts(MESSAGE);

	return 0;
}
