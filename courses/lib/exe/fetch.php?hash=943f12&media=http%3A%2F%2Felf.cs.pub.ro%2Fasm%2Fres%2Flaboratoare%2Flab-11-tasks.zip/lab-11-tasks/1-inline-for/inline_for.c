#include <stdio.h>

#define NUM	100

int main(void)
{
	size_t n = NUM;
	size_t sum = 0;

//	size_t i = 0;
//	for (i = 1; i <= n; i++)
//		sum += i;

	__asm {
		xor eax, eax	; collect sum in eax
		; use ecx to go through items, start from n
		mov ecx, n
	add_to_sum:
		add eax, ecx
		loopnz add_to_sum

		mov sum, eax	; place sum in sum variable
	}

	printf("sum(%u): %u\n", n, sum);

	return 0;
}
