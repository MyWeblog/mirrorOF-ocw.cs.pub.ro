#!/bin/bash

/c/Program\ Files\ \(x86\)/SASM/NASM/nasm.exe -f win32 data_buffer.asm
/c/Program\ Files\ \(x86\)/SASM/MinGW/bin/gcc -Wall -g -o data_buffer data_buffer.obj
